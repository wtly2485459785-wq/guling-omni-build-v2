const fs = require('node:fs');
const path = require('node:path');

const pluginFile = path.join(__dirname, '..', 'android', 'app', 'src', 'main', 'assets', 'capacitor.plugins.json');
const plugins = JSON.parse(fs.readFileSync(pluginFile, 'utf8'));
const nativePlugin = {
  pkg: '@guling/native',
  classpath: 'com.guling.omni.GulingNativePlugin'
};

if (!plugins.some(plugin => plugin.classpath === nativePlugin.classpath)) {
  plugins.push(nativePlugin);
}

fs.writeFileSync(pluginFile, `${JSON.stringify(plugins, null, 2)}\n`);
