'use strict';
const assert = require('node:assert/strict');
const fflate = require('fflate');
const { extractZipTextFromBytes } = require('../www/zip-reader.js');

async function main() {
    const regular = fflate.zipSync({
        'src/main.js': fflate.strToU8('console.log("zip works");'),
        'README.md': fflate.strToU8('# archive text'),
        'node_modules/dependency.js': fflate.strToU8('must be ignored'),
        'assets/icon.png': new Uint8Array([1, 2, 3, 4])
    }, { level: 6 });
    const result = await extractZipTextFromBytes(regular);
    assert.equal(result.files.length, 2);
    assert.match(result.files.find(file => file.name === 'src/main.js').content, /zip works/);
    assert.ok(result.skipped >= 2, 'binary and ignored dependency entries should be skipped');

    const oversizedText = 'A'.repeat(1_200_000);
    const forged = new Uint8Array(fflate.zipSync({ 'bomb.txt': fflate.strToU8(oversizedText) }, { level: 6 }));
    const view = new DataView(forged.buffer, forged.byteOffset, forged.byteLength);
    let centralOffset = -1;
    for (let i = 0; i + 46 <= forged.length; i++) {
        if (view.getUint32(i, true) === 0x02014b50) { centralOffset = i; break; }
    }
    assert.notEqual(centralOffset, -1, 'test ZIP central directory must exist');
    // 伪造 local/central directory 中声明的解压大小；运行时仍必须按实际输出字节数中止。
    view.setUint32(22, 1, true);
    view.setUint32(centralOffset + 24, 1, true);
    await assert.rejects(
        extractZipTextFromBytes(forged),
        /没有可读取的文本文件/,
        'actual decompressed bytes must be limited even when ZIP metadata lies'
    );

    await assert.rejects(
        extractZipTextFromBytes(new Uint8Array(10 * 1024 * 1024 + 1)),
        /超过 10MB/,
        'compressed archive size must be bounded before parsing'
    );
    console.log('PASS ZIP stream reader regression tests');
}

main().catch(error => {
    console.error(error);
    process.exitCode = 1;
});
