'use strict';
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const failures = [];
function read(rel) { return fs.readFileSync(path.join(root, rel), 'utf8'); }
function check(label, condition) {
  if (condition) console.log(`PASS ${label}`);
  else { console.error(`FAIL ${label}`); failures.push(label); }
}
const app = read('www/app.js');
const providers = read('www/providers.js');
const zipReader = read('www/zip-reader.js');
const html = read('www/index.html');
const manifest = read('android/app/src/main/AndroidManifest.xml');
const nativePlugin = read('android/app/src/main/java/com/guling/omni/GulingNativePlugin.java');
const accessService = read('android/app/src/main/java/com/guling/omni/OmniAccessibilityService.java');
const accessXml = read('android/app/src/main/res/xml/omni_accessibility_service.xml');
const pluginRegistry = JSON.parse(read('android/app/src/main/assets/capacitor.plugins.json'));
check('ZIP 流式解压在实际输出上施加文件/总量限额', zipReader.includes('file.ondata =') && zipReader.includes('nextFile > LIMITS.perFileBytes') && zipReader.includes('nextTotal > LIMITS.totalBytes'));
check('ZIP 条目、压缩包和耗时上限存在', zipReader.includes('entries: 5000') && zipReader.includes('archiveBytes: 10 * 1024 * 1024') && zipReader.includes('timeoutMs: 30000'));
check('会话选项通过 DOM API 创建而非拼接导入 ID', app.includes('sessionSelect.replaceChildren()') && app.includes('option.value = String(session?.id') && !app.includes('value="${x.id}"'));
const config = read('www/config.js');
check('版本更新不会删除旧记忆存储键', !config.includes('localStorage.removeItem(k)') && !config.includes('forEach(k=>{try{localStorage.removeItem'));
check('旧版记忆存储键存在安全迁移逻辑', app.includes("const legacyKeys = ['guling_omni_v15', 'guling_final_vision_v14', 'guling_final_vision_v1']") && app.includes('原始数据仍保留'));
check('二进制附件绑定到最后一条用户消息', app.includes("find(m => m.role === 'user')"));
check('空白回复保护存在', app.includes('模型返回了空回答'));
check('自动模型数受限且超时/空回复会停止重试', app.includes('return all.slice(0, 3)') && app.includes("'timeout', 'empty'") && providers.includes('ms = 45000'));
check('补丁功能已彻底移除', !html.includes('patchInput') && !app.includes('applyPatch') && !app.includes('data-patch-action') && (app.match(/delete (?:parsed|state)\.cfg\.patches/g) || []).length === 1);
check('主人验证密码已改为 010', config.includes("const MASTER_PASSWORD = '010'") && !config.includes('211305') && !html.includes('211305'));
check('底部导航为 7 项且包含数据与连接', (html.match(/<button data-tab=/g) || []).length === 7 && html.includes('data-tab="capsule"') && html.includes('数据') && html.includes('data-tab="connection"') && html.includes('连接'));
check('成本统计已移动到数据页顶部', /<section id="tab-capsule"[^>]*>\s*<div class="card"><h3>成本统计<\/h3>/.test(html));
check('设置页不再包含成本统计和模型连接配置', !html.slice(html.indexOf('<section id="tab-settings"')).includes('成本统计') && !html.slice(html.indexOf('<section id="tab-settings"')).includes('id="apiKey"'));
check('全知中枢页已删除记忆检索卡片', !html.includes('记忆检索'));
check('上传的项目 ZIP 通过 IndexedDB 永久保存并在启动时恢复', app.includes('indexedDB.open(PROJECT_DB_NAME') && app.includes('async function restorePersistedProject') && app.includes('await restorePersistedProject()') && config.includes("PROJECT_DB_NAME = 'guling_omni_project_db_v1'"));
check('模型探测并发 2、单次 1 token、8 秒超时', config.includes('MODEL_PROBE_CONCURRENCY = 2') && config.includes('MODEL_PROBE_TIMEOUT_MS = 8000') && app.includes('max_tokens: 1') && app.includes('maxOutputTokens: 1'));
check('模型下拉默认只显示可用/限流并保留显示全部开关与筛选', app.includes("showAll || status === 'ok' || status === 'rate'") && html.includes('id="showAllModelsSwitch"') && html.includes('id="modelSearchInput"') && app.includes("status === 429"));
check('最近任务默认折叠且可展开收起', html.includes('tool-approval-history collapsed') && app.includes("classList.toggle('collapsed', !toolHistoryExpanded)") && app.includes("$('#toggleHistoryBtn').onclick"));
check('自我更新改为分析建议后生成新版本', html.includes('② 让古灵分析项目并提出功能建议') && html.includes('③ 按建议生成新版本并由 GitHub 构建 APK') && app.includes('async function runProjectAnalysis') && app.includes('async function generateNewVersionAndBuild') && app.includes('parseProjectFiles') && app.includes('applyProjectFilesToZip'));
check('本地自检界面和函数存在', html.includes('id="runSelfCheck"') && app.includes('async function runLocalSelfCheck'));
check('MCP 服务器配置与 Streamable HTTP 客户端存在', html.includes('id="addMcpServer"') && html.includes('id="mcpServerList"') && app.includes('async function mcpPost') && app.includes('notifications/initialized') && app.includes("'tools/list'") && app.includes("'tools/call'"));
check('MCP 工具接入审批队列且可被解析调用', app.includes('function isApprovableTool') && app.includes('startsWith(\'mcp__\')') && app.includes('async function callMcpTool') && app.includes('function mcpToolsPrompt'));
check('MCP 令牌不进入导出与自动备份', app.includes("mcpServers = (data.cfg.mcpServers || []).map(server => ({ ...server, token: '' }))") && app.includes("mcpServers = (cfgCopy.mcpServers || []).map(server => ({ ...server, token: '' }))"));
check('工具提示禁止照抄占位示例', app.includes('禁止照抄示例') && !app.includes('[[TOOL:工具名{"key":"value"}]]'));
check('原生插件在 Capacitor 注册表', pluginRegistry.some(x => x.classpath === 'com.guling.omni.GulingNativePlugin'));
check('Android Manifest 声明无障碍服务', manifest.includes('.OmniAccessibilityService') && manifest.includes('BIND_ACCESSIBILITY_SERVICE'));
check('无障碍服务仅请求窗口状态事件', accessXml.includes('typeWindowStateChanged'));
check('屏幕动作需校验工具名称与批准状态路径', nativePlugin.includes('screen_read') && nativePlugin.includes('screen_tap') && accessService.includes('isScreenActionCancelled'));
check('Termux 命令仅经审批队列调用并回传结果', app.includes("'termux_exec'") && app.includes('批准并调用 Termux') && nativePlugin.includes('queueTermuxCommand') && nativePlugin.includes('pollTermuxCommand') && manifest.includes('com.termux.permission.RUN_COMMAND') && fs.existsSync(path.join(root, 'android/app/src/main/java/com/guling/omni/TermuxResultReceiver.java')));
check('项目 ZIP 上传与 GitHub Actions 构建界面存在', html.includes('termuxProjectZipInput') && html.includes('termuxBuildApkBtn') && html.includes('githubToken') && html.includes('githubUser') && html.includes('githubRepo') && app.includes('buildApkViaGitHub') && app.includes('saveApkToDownloads') && app.includes('GITHUB_WORKFLOW_YML') && nativePlugin.includes('saveApkToDownloads'));
check('本地永久记忆可导出为 ZIP', html.includes('exportMemoryZip') && app.includes('window.fflate.zipSync') && app.includes('guling-memory.json'));
check('附近信号扫描原生方法与权限齐备', nativePlugin.includes('scanNearbySignals') && nativePlugin.includes('getScanResults') && nativePlugin.includes('BluetoothLeScanner') && manifest.includes('ACCESS_FINE_LOCATION') && manifest.includes('BLUETOOTH_SCAN') && manifest.includes('ACCESS_WIFI_STATE'));
check('附近信号扫描返回可分析字段（距离/加密/信道/频段）', nativePlugin.includes('distanceMeters') && nativePlugin.includes('parseSecurity') && nativePlugin.includes('frequencyToChannel') && nativePlugin.includes('bandFromFrequency') && nativePlugin.includes('crowdedChannels'));
check('附近信号扫描前端界面与渲染存在', html.includes('scanSignalsBtn') && html.includes('signalSummary') && app.includes('renderSignalScanResult') && app.includes('signalQualityLabel'));
check('网页资源与 APK 内置资源同步', app === read('android/app/src/main/assets/public/app.js') && providers === read('android/app/src/main/assets/public/providers.js') && zipReader === read('android/app/src/main/assets/public/zip-reader.js') && html === read('android/app/src/main/assets/public/index.html'));
if (failures.length) {
  console.error(`\n${failures.length} check(s) failed.`);
  process.exitCode = 1;
} else console.log('\nAll static integrity checks passed. This is not an Android build or device test.');
