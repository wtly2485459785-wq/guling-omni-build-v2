# 古灵 OMNI

这是古灵 OMNI 的 Capacitor Android 工程，包含网页前端和 Android 原生扩展。

## 已实现

- 全知中枢中的工具审批队列：模型请求的工具先显示为待审批任务；逐项允许或拒绝；没有自动放行选项。
- `web_search`、`web_fetch`、`memory_search`、`calc` 和 `code_run_js` 仅在明确允许后执行。网页读取只发起 GET；JavaScript 在隔离沙箱运行，不能访问网络或写入应用文件。
- Android 悬浮球和前台常驻服务由用户手动启动，并提供显式停止按钮。
- 屏幕读取和控件点击必须先在古灵任务列表中批准，再由用户点击 Android 系统通知中的“执行”。无障碍服务不持续采集屏幕内容；只使用当前窗口中可访问的文字和控件，不录屏。
- 屏幕点击仅支持刚读取到的可访问控件序号，并校验控件文字；不支持坐标点击或后台自动操作。
- 历史版本中的自动工具确认设置不会恢复为自动执行。

## Android 构建

需要 Node.js、pnpm、JDK 17 和 Android SDK（Android 34 平台及 Build Tools 34.0.0）。

```sh
pnpm install
pnpm android:copy
pnpm android:debug
```

调试 APK 生成于 `android/app/build/outputs/apk/debug/app-debug.apk`。该 APK 使用 Android 调试签名，适合本地安装测试，不是发布商店用的正式签名包。

## 首次启用原生能力

1. 安装后打开应用，在“全知中枢”中按需启动悬浮球服务。
2. 按系统提示授权悬浮窗和通知权限。无障碍服务必须由用户自行进入 Android 无障碍设置并启用“古灵屏幕助手”。
3. 屏幕工具每次都会先等待古灵界面审批；批准后，还要在目标应用中点击系统通知的“执行”。拒绝、忽略通知或停止常驻服务都不会触发屏幕操作。
4. 可随时使用应用内或常驻通知中的“停止”关闭悬浮球与前台服务。

无障碍读取范围受 Android 和目标应用可访问性节点限制。某些应用不提供可访问文字或可点击控件，届时操作会失败并返回原因。

## OMNI-V16 修复更新（2026-10-21）

- ZIP 上传：使用内置 fflate 流式读取 ZIP 中的文本源码/配置/文档；无需 Android WebView 提供 `DecompressionStream('deflate-raw')`。只读文本、不执行压缩包代码，并跳过二进制文件、依赖目录和构建产物。限制压缩包 10MB、5,000 个条目、250 个文本文件、单文件解压 1MB、累计实际解压文本 4MB、解析 30 秒；RAR/7Z/TAR/GZ 暂不支持。
- ZIP 解析期间附件会立即显示“解析中”；点击发送时会等待解析完成，避免用户消息先发出、压缩包随后才加入而造成漏传。
- 修复导入/备份中的会话 ID 被拼接进下拉菜单 HTML 的注入风险；会话选项改为 DOM API 创建。
- 附件归属：二进制附件现在明确追加到最后一条用户消息，不再错误地追加到历史记录的最后一条（可能是助手消息）。
- 响应优化：自动模式优先使用最近成功模型，最多尝试 3 个候选；云端请求默认 45 秒超时，OpenRouter 60 秒。空回复或超时会明确提示并停止切换模型，避免多次长等或重复请求。
- 更新记录：设置页显示 V16/V15 发行说明，并在本地记录本机检测到的升级版本和时间。
- Android `versionCode` 升至 2、`versionName` 升至 1.1.0；网页版本标识为 OMNI-V16。Android 内置网页资源与 `www/` 同步。

安全提示：ZIP 内容仍应视为不可信输入。4MB 是解压文本上限，不代表模型服务一定接受这么大的请求；大项目建议只上传相关源码。构建和真机验证需在具备 Android SDK/Gradle 依赖的环境中完成。

## Android Debug APK 构建

### 云端免费构建（推荐当前环境无法下载 Gradle 时使用）

仓库包含 `.github/workflows/android-debug-apk.yml`。将项目推送到 GitHub 的 `main` 或 `master` 分支后，会自动安装 Java 17、Android SDK 和 npm 依赖，运行 `npm test`，同步 Capacitor 资源并构建 Debug APK。也可以在 GitHub 仓库的 **Actions → Build Android Debug APK → Run workflow** 手动触发。

构建成功后，在该次 workflow 的 **Artifacts** 区域下载 `guling-omni-debug-apk`，其中的 `app-debug.apk` 是用于测试安装的 Debug APK。此流程不会生成已签名的正式发布 APK。

### 本机构建

需要安装 Java 17、Android SDK（Android 34 / Build Tools 34.0.0）并确保网络可下载 Gradle 8.2.1 和 Maven 依赖，然后执行：

```bash
npm install
npm test
npm run android:debug
```

APK 输出路径：`android/app/build/outputs/apk/debug/app-debug.apk`。

## 记忆与升级保留说明

- 版本更新不再主动删除旧版本的 localStorage 数据键。
- 如果新版主存储键不存在，会尝试从 `guling_omni_v15`、`guling_final_vision_v14`、`guling_final_vision_v1` 读取并迁移可识别的旧状态；迁移不会删除旧键。
- Android 更新时请直接覆盖安装，并保持相同的 `applicationId`（`com.guling.omni`）；不要先卸载旧版，也不要清除应用存储。卸载应用或清除存储仍可能导致 Android WebView 本地数据丢失。
- 重要记忆建议定期使用应用内的数据导出/备份功能，将备份文件保存到手机应用目录之外。


## OMNI-V17：Termux 本地构建与记忆 ZIP

- 设置页新增“自我更新：通过本地 Termux 构建 APK”：选择项目 ZIP 后，通过 Android MediaStore 写入 `Download/GulingBuild/guling-project.zip`，再由用户确认调用 Termux 解压、安装 npm 依赖、同步 Capacitor 并执行 `assembleDebug`。
- 构建产物目标位置为 `Download/GulingBuild/guling-omni-debug.apk`。APK 安装仍须由 Android 系统安装器和用户确认，应用不能静默安装自身。
- 首次使用前，在 F-Droid Termux 执行 `termux-setup-storage` 并授权共享存储；需要 Node.js、JDK 17、Gradle 可访问的网络和 Android SDK Platform 34。项目会尝试安装 `unzip`、`nodejs-lts` 和 `openjdk-17`，但不会假装 Android SDK 已自动安装。
- 记忆页新增“导出记忆 ZIP”，只打包本地永久记忆，不包含 API Key。导出的 ZIP 可通过聊天附件上传给 AI 或保存到其他位置。
- 更新仍保留原来的本地存储；卸载应用或清除应用数据仍可能丢失 WebView 本地数据，请定期导出备份。
- 修复补充：聊天输入区不再被顶部架构横幅裁切；网页版本标识统一为 OMNI-V17；文本/二进制附件与 ZIP 一样，发送前会等待读取完成；重复上传项目 ZIP 会覆盖 `Download/GulingBuild/guling-project.zip`，避免构建旧包；发布说明中的默认规则数量改为按实际条数动态显示。

## MCP 工具服务器（0 元扩展）

连接页新增“MCP 工具服务器（免费扩展）”。填写名称、MCP 地址和可选 Bearer Token 后，应用会通过 JSON-RPC 完成 `initialize`、`notifications/initialized` 和 `tools/list`，并把发现的工具注入全知模式提示词。

- 传输方式：仅支持 Streamable HTTP（`POST`，响应可为 JSON 或 SSE）；旧版纯 SSE 传输端点不在此版本支持范围内。
- 工具命名：`mcp__<服务器ID>__<工具名>`。模型必须使用提示词中列出的真实别名，调用仍会进入全知中枢的逐项审批队列。
- 安全：MCP 服务器地址只允许 http/https；令牌保存在本机 localStorage，导出数据和自动备份时会清空令牌；每次工具调用都需要主人批准。
- 网页版：跨域请求受浏览器 CORS 限制，服务器需要返回 `Access-Control-Allow-Origin` 等响应头。
- Android 安装版：项目已启用 CapacitorHttp，请求走原生 HTTP，通常不受 CORS 限制；但 http 明文地址仍可能被 Android 网络安全策略拦截，建议使用 HTTPS 或反向代理。
- 自动连接：启动时会对已启用的服务器做一次工具发现；失败不会影响聊天，可在连接页点“刷新工具”重试。
- 上限：最多 10 个服务器、每个服务器最多 100 个工具；提示词最多注入 50 个工具条目。
