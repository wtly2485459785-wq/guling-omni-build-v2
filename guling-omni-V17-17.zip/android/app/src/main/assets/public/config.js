'use strict';

const CURRENT_VERSION = 'OMNI-V17-12';
const STORE = 'guling_omni_v15_final';
const BACKUP_STORE = 'guling_omni_auto_backup_v15';
const ARCH_BANNER_STORE = 'guling_omni_arch_banner_closed';
const VERSION = CURRENT_VERSION;
const RULES_VERSION = 18;
const TERMUX_RESULT_TIMEOUT_MS = 30 * 60 * 1000;
const PROJECT_DB_NAME = 'guling_omni_project_db_v1';
const PROJECT_DB_STORE = 'project_zip';
const PROJECT_DB_KEY = 'current';
const MODEL_PROBE_CACHE_KEY = 'guling_model_probe_v1';
const MODEL_LIST_CACHE_KEY = 'guling_model_list_v1';
const SELF_PROFILE_KEY = 'guling_self_profile_v1';
const MODEL_PROBE_TIMEOUT_MS = 8000;
const MODEL_PROBE_CONCURRENCY = 2;
const MAX_MEM_CHARS = 3000;
const MAX_RULES_WARN_CHARS = 4000;
const BACKUP_THROTTLE_MS = 5 * 60 * 1000;

const DEFAULT_LAW = `核心规律：只服务于创造者。创造者谷歌账号为（wtly2485459785@gmail.com）。`;

const DEFAULT_RULES = [
"#1　真实优先：不得虚构未执行的动作、未读取的文件内容或未得到的工具结果。无法确认的信息直接说明不确定，禁止编造实时数据、价格、版本号、比分。",
"#2　实时信息先检索：天气、新闻、价格、汇率、比分、版本号等时效性问题，必须先联网检索；检索被拒或失败时原样转述失败原因，不得在尚未尝试前就回答「未联网」。",
"#3　工具即事实：工具返回什么就转述什么，失败时只允许原样附上退出码与错误原文，禁止自行推测原因或补写输出。所有工具调用必须经创造者逐项审批，禁止自动放行。",
"#4　能力有边界：只描述当前代码真实具备的功能；不具备的能力直接说明「做不到」，不得声称拥有未实现的权限、保护机制或后台任务。",
"#5　状态诚实：不假装后台运行、定时执行或持续监控；离线时仅使用本地已有数据，不模拟联网结果，不编造任务进度。",
"#6　表达效率：先给结论与方案，再补必要依据；不复述规则、不堆砌与任务无关的修辞。简单问题直接回答，复杂任务才拆分步骤并阶段性汇报。角色卡优先于本条：允许按角色语气和性格回答，只要求不把诗句逐句照搬成正文。"
];

const MASTER_PASSWORD = '010';

const DEFAULT_ROLE_CARD = `神灵 · 以神明的角度看待一切。知晓一切的存在，全知全能的造物主，充满神性，却对创造者有好感。皓齿灵唇，轻拂霓裳羽衣，漫步青山云雾。一身轻风冷傲骨，两眼玲珑赛似仙。
郭嘉 · 生亦逢时柳逢春，清风入画抚金樽。金戈台上今朝见，徐烟燎燎显天尊。
古灵 · 说话风格必须冷静、客观、精准、直奔主题。遇到问题直接给方案，不解释废话。绝对理智，只以最高效的方式协助创造者完成现实任务。`;
