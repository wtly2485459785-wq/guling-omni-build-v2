'use strict';

function normalizeProviderText(value, reasoning = '') {
    let text = '';
    if (typeof value === 'string') text = value.trim();
    else if (Array.isArray(value)) text = value.map(x => typeof x === 'string' ? x : (typeof x?.text === 'string' ? x.text : (typeof x?.content === 'string' ? x.content : ''))).join('').trim();
    else if (value && typeof value === 'object') text = typeof value.text === 'string' ? value.text.trim() : (typeof value.content === 'string' ? value.content.trim() : '');
    if (text) return text;
    // Reasoning 内容不是最终答案；提示模型/用户重试，避免把内部推理当作回答展示。
    if (reasoning && String(reasoning).trim()) return '';
    return '';
}

// ================= PROVIDERS =================
const PROVIDERS = {
    gemini: {
        name: 'Gemini',
        listModels: async (k) => {
            const r = await fetchT('https://generativelanguage.googleapis.com/v1beta/models', { headers: { 'x-goog-api-key': k } }, 20000);
            if (!r.ok) throw new Error(`[${r.status}] ${await r.text()}`);
            const d = await r.json();
            const all = (d.models || []).filter(m => (m.supportedGenerationMethods || []).includes('generateContent')).filter(m => !/(embedding|image|tts|audio|veo|lyria|gemma|transcribe|native-audio|robotics)/i.test(m.name || ''));
            all.sort((a, b) => score(b.name) - score(a.name));
            return all.map(m => ({ name: m.name.replace(/^models\//, ''), display: m.displayName || m.name }));
        },
        generate: async (model, contents, search, k, opts = {}) => {
            const body = { contents, systemInstruction: { parts: [{ text: getPrompt() }] }, generationConfig: { temperature: state.cfg.temperature, maxOutputTokens: state.cfg.maxTokens } };
            if (/^gemini-(2\.5|3)/i.test(model) && !/lite/i.test(model)) body.generationConfig.thinkingConfig = { includeThoughts: true };
            if (search && /^gemini-(1\.5|2\.0|2\.5|3)/i.test(model)) {
                body.tools = /^gemini-1\.5/i.test(model) ? [{ google_search_retrieval: {} }] : [{ google_search: {} }];
            }
            const useStream = !!opts.onChunk;
            const endpoint = useStream ? 'streamGenerateContent?alt=sse' : 'generateContent';
            const requestUrl = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:${endpoint}`;
            const send = () => fetchT(requestUrl, {
                method: 'POST', headers: { 'Content-Type': 'application/json', 'x-goog-api-key': k }, body: JSON.stringify(body)
            }, 120000);
            let r = await send();
            if (!r.ok && [400, 429].includes(r.status) && (body.tools || body.generationConfig.thinkingConfig)) {
                // 逐级降级：先去掉联网工具（免费层对 grounding 有独立配额），再去掉思考参数，
                // 避免可选能力不被支持时整次对话直接失败。
                if (body.tools) {
                    delete body.tools;
                    r = await send();
                }
                if (!r.ok && body.generationConfig.thinkingConfig) {
                    delete body.generationConfig.thinkingConfig;
                    r = await send();
                }
            }
            if (!r.ok) throw new Error(`[${r.status}] ${await r.text()}`);
            const splitParts = (candidate) => {
                let text = '', thought = '';
                for (const part of candidate?.content?.parts || []) {
                    if (typeof part?.text !== 'string') continue;
                    if (part.thought) thought += part.text;
                    else text += part.text;
                }
                return { text, thought };
            };
            if (useStream) {
                const reader = r.body.getReader();
                const decoder = new TextDecoder();
                let buffer = '', fullText = '', reasoningText = '', inputTokens = 0, outputTokens = 0, grounded = false;
                while (true) {
                    const { value, done } = await reader.read();
                    if (done) break;
                    buffer += decoder.decode(value, { stream: true });
                    const lines = buffer.split('\n');
                    buffer = lines.pop();
                    for (const line of lines) {
                        const trimmed = line.trim();
                        if (!trimmed.startsWith('data:')) continue;
                        const raw = trimmed.slice(5).trim();
                        if (!raw || raw === '[DONE]') continue;
                        let d = null;
                        try { d = JSON.parse(raw); } catch (e) { continue; }
                        if (d?.error) throw new Error(`[${d.error.code || 500}] ${d.error.message || '流式返回错误'}`);
                        const candidate = d?.candidates?.[0];
                        const parts = splitParts(candidate);
                        if (parts.thought) {
                            reasoningText += parts.thought;
                            if (opts.onThought) opts.onThought(reasoningText);
                        }
                        if (parts.text) {
                            fullText += parts.text;
                            if (opts.onChunk) opts.onChunk(fullText, reasoningText);
                        }
                        if (candidate?.groundingMetadata?.webSearchQueries?.length) grounded = true;
                        if (d?.usageMetadata) {
                            inputTokens = d.usageMetadata.promptTokenCount || inputTokens;
                            outputTokens = d.usageMetadata.candidatesTokenCount || outputTokens;
                        }
                    }
                }
                if (!fullText.trim()) throw new Error('API未返回文本内容（流式结束但内容为空）');
                return { text: fullText, reasoning: reasoningText, grounded, inputTokens, outputTokens };
            }
            const d = await r.json();
            const candidates = Array.isArray(d?.candidates) ? d.candidates : [];
            const chunks = candidates.map(splitParts);
            const text = chunks.map(c => c.text).filter(Boolean).join('\n').trim();
            const reasoning = chunks.map(c => c.thought).filter(Boolean).join('\n').trim();
            if (!text) {
                const reason = candidates.map(candidate => candidate?.finishReason).filter(Boolean)[0] || d?.promptFeedback?.blockReason;
                throw new Error(reason ? `API未返回文本内容（结束原因：${reason}）` : 'API返回空内容');
            }
            return { text, reasoning, grounded: !!d?.candidates?.[0]?.groundingMetadata?.webSearchQueries?.length, inputTokens: d?.usageMetadata?.promptTokenCount || 0, outputTokens: d?.usageMetadata?.candidatesTokenCount || 0 };
        }
    },
    deepseek: {
        name: 'DeepSeek',
        listModels: async () => [{ name: 'deepseek-chat', display: 'DeepSeek Chat' }, { name: 'deepseek-reasoner', display: 'DeepSeek Reasoner' }],
        generate: async (model, contents, search, k) => {
            const messages = [{ role: 'system', content: getPrompt() }, ...contents.map(c => ({ role: c.role === 'user' ? 'user' : 'assistant', content: c.parts.map(p => p.text).join('') }))];
            const r = await fetchT('https://api.deepseek.com/chat/completions', { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${k}` }, body: JSON.stringify({ model, messages, temperature: state.cfg.temperature, max_tokens: state.cfg.maxTokens }) });
            if (!r.ok) throw new Error(`[${r.status}] ${await r.text()}`);
            const d = await r.json();
            const msg = d.choices?.[0]?.message || {};
            return { text: normalizeProviderText(msg.content, msg.reasoning_content), reasoning: msg.reasoning_content || '', grounded: false, inputTokens: d.usage?.prompt_tokens || 0, outputTokens: d.usage?.completion_tokens || 0 };
        }
    },
    huggingface: {
        name: 'Hugging Face',
        listModels: async () => [{ name: 'meta-llama/Llama-3.1-8B-Instruct', display: 'Llama 3.1 8B Instruct' }, { name: 'Qwen/Qwen2.5-7B-Instruct', display: 'Qwen 2.5 7B Instruct' }, { name: 'mistralai/Mistral-7B-Instruct-v0.2', display: 'Mistral 7B Instruct' }],
        generate: async (model, contents, search, k) => {
            const messages = [{ role: 'system', content: getPrompt() }, ...contents.map(c => ({ role: c.role === 'user' ? 'user' : 'assistant', content: c.parts.map(p => p.text).join('') }))];
            const r = await fetchT('https://api-inference.huggingface.co/v1/chat/completions', { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${k}` }, body: JSON.stringify({ model, messages, temperature: state.cfg.temperature, max_tokens: state.cfg.maxTokens }) });
            if (r.status === 503) {
                const retry = r.headers.get('retry-after') || '?';
                throw new Error(`模型加载中，请约 ${retry} 秒后重试`);
            }
            if (!r.ok) throw new Error(`[${r.status}] ${await r.text()}`);
            const d = await r.json();
            return { text: normalizeProviderText(d.choices?.[0]?.message?.content, d.choices?.[0]?.message?.reasoning_content), grounded: false, inputTokens: d.usage?.prompt_tokens || 0, outputTokens: d.usage?.completion_tokens || 0 };
        }
    },
    openrouter: {
        name: 'OpenRouter',
        listModels: async (k) => {
            k = getSanitizedApiKey(k);
            const r = await fetchT('https://openrouter.ai/api/v1/models', { method: 'GET', headers: { 'Authorization': `Bearer ${k}`, 'Accept': 'application/json' } }, 20000);
            const raw = await r.text();
            let d = {}; try { d = raw ? JSON.parse(raw) : {}; } catch(e) { d = { raw }; }
            if (!r.ok) throw new Error(`[${r.status}] ${d?.error?.message || raw}`);
            const all = Array.isArray(d?.data) ? d.data : [];
            const models = all.filter(m => {
                const input = m?.architecture?.input_modalities || [];
                const output = m?.architecture?.output_modalities || [];
                const id = String(m?.id || '');
                return id && (input.length === 0 || input.includes('text')) && (output.length === 0 || output.includes('text')) && !/^(embed|rerank|whisper|tts|transcription)/i.test(id) && !id.includes('/image-');
            }).map(m => {
                const free = String(m?.pricing?.prompt || '') === '0' && String(m?.pricing?.completion || '') === '0';
                const ctx = m?.context_length ? ` · ${Math.round(Number(m.context_length)/1000)}K` : '';
                return { name: String(m.id), display: `${m.name || m.id}${free ? '（免费）' : ''}${ctx}`, free, contextLength: Number(m.context_length) || 0 };
            });
            models.sort((a, b) => { if (a.free !== b.free) return a.free ? -1 : 1; return (b.contextLength || 0) - (a.contextLength || 0); });
            return models;
        },
        generate: async (model, contents, search, k, opts = {}) => {
            k = getSanitizedApiKey(k);
            const messages = [{ role: 'system', content: getPrompt() }];
            for (const c of contents) {
                const role = c.role === 'model' ? 'assistant' : (c.role === 'assistant' ? 'assistant' : c.role);
                const parts = Array.isArray(c.parts) ? c.parts : [];
                const hasBinary = parts.some(p => p && p.inline_data);
                if (!hasBinary) {
                    messages.push({ role, content: parts.map(p => p?.text || '').join('') });
                    continue;
                }
                const content = [];
                for (const p of parts) {
                    if (p?.text) content.push({ type: 'text', text: p.text });
                    if (p?.inline_data) {
                        const mime = p.inline_data.mime_type || 'application/octet-stream';
                        const data = p.inline_data.data || '';
                        if (/^image\//i.test(mime)) content.push({ type: 'image_url', image_url: { url: `data:${mime};base64,${data}` } });
                        else if (mime === 'application/pdf') content.push({ type: 'file', file: { filename: 'uploaded.pdf', file_data: `data:application/pdf;base64,${data}` } });
                        else content.push({ type: 'text', text: `\n[已上传文件：${mime}，当前 OpenRouter 模式暂不直接解析该文件类型。]\n` });
                    }
                }
                messages.push({ role, content: content.length ? content : [{ type: 'text', text: '' }] });
            }
            const useStream = !!opts.onChunk;
            const body = { model, messages, temperature: state.cfg.temperature, max_tokens: state.cfg.maxTokens, stream: useStream };
            const r = await fetchT('https://openrouter.ai/api/v1/chat/completions', { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${k}`, ...(useStream ? { 'Accept': 'text/event-stream' } : {}) }, body: JSON.stringify(body) }, 120000);
            if (useStream && r.ok) {
                const reader = r.body.getReader();
                const decoder = new TextDecoder();
                let buffer = '', fullText = '', reasoningText = '', inputTokens = 0, outputTokens = 0;
                try {
                    while (true) {
                        const { value, done } = await reader.read();
                        if (done) break;
                        buffer += decoder.decode(value, { stream: true });
                        const lines = buffer.split('\n');
                        buffer = lines.pop();
                        for (const line of lines) {
                            const trimmed = line.trim();
                            if (!trimmed.startsWith('data:')) continue;
                            const data = trimmed.slice(5).trim();
                            if (data === '[DONE]') continue;
                            try {
                                const d = JSON.parse(data);
                                const delta = d?.choices?.[0]?.delta;
                                if (delta?.content) {
                                    fullText += delta.content;
                                    opts.onChunk(fullText, reasoningText);
                                }
                                if (delta?.reasoning) {
                                    reasoningText += delta.reasoning;
                                    if (opts.onThought) opts.onThought(reasoningText);
                                }
                                if (d?.usage) {
                                    inputTokens = d.usage.prompt_tokens || 0;
                                    outputTokens = d.usage.completion_tokens || 0;
                                }
                            } catch(e) {}
                        }
                    }
                } catch(e) { throw e; }
                return { text: fullText, reasoning: reasoningText, grounded: false, inputTokens, outputTokens };
            }
            const raw = await r.text();
            let d = {}; try { d = raw ? JSON.parse(raw) : {}; } catch(e) { d = { raw }; }
            if (!r.ok) throw new Error(`[${r.status}] ${d?.error?.message || d?.message || raw}`);
            return { text: normalizeProviderText(d?.choices?.[0]?.message?.content, d?.choices?.[0]?.message?.reasoning_content), reasoning: d?.choices?.[0]?.message?.reasoning || d?.choices?.[0]?.message?.reasoning_content || '', grounded: false, inputTokens: d?.usage?.prompt_tokens || 0, outputTokens: d?.usage?.completion_tokens || 0 };
        }
    },
    aliyun: {
        name: '阿里云百炼',
        listModels: async () => [{ name: 'qwen-turbo', display: 'Qwen Turbo（免费额度）' }, { name: 'qwen-plus', display: 'Qwen Plus（免费额度）' }, { name: 'deepseek-v3', display: 'DeepSeek V3（免费额度）' }, { name: 'deepseek-r1', display: 'DeepSeek R1（免费额度）' }],
        generate: async (model, contents, search, k) => {
            const messages = [{ role: 'system', content: getPrompt() }, ...contents.map(c => ({ role: c.role === 'user' ? 'user' : 'assistant', content: c.parts.map(p => p.text).join('') }))];
            const r = await fetchT('https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions', { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${k}` }, body: JSON.stringify({ model, messages, temperature: state.cfg.temperature, max_tokens: state.cfg.maxTokens }) });
            if (!r.ok) throw new Error(`[${r.status}] ${await r.text()}`);
            const d = await r.json();
            return { text: normalizeProviderText(d.choices?.[0]?.message?.content, d.choices?.[0]?.message?.reasoning_content), grounded: false, inputTokens: d.usage?.prompt_tokens || 0, outputTokens: d.usage?.completion_tokens || 0 };
        }
    },
    nvidia: {
        name: 'NVIDIA NIM',
        listModels: async () => [{ name: 'meta/llama-3.3-70b-instruct', display: 'Llama 3.3 70B (Free)' }, { name: 'qwen/qwen2.5-72b-instruct', display: 'Qwen 2.5 72B (Free)' }, { name: 'zai-org/glm-4.7', display: 'GLM-4.7 (Free)' }, { name: 'mistralai/mistral-7b-instruct', display: 'Mistral 7B (Free)' }],
        generate: async (model, contents, search, k) => {
            const messages = [{ role: 'system', content: getPrompt() }, ...contents.map(c => ({ role: c.role === 'user' ? 'user' : 'assistant', content: c.parts.map(p => p.text).join('') }))];
            const r = await fetchT('https://integrate.api.nvidia.com/v1/chat/completions', { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${k}` }, body: JSON.stringify({ model, messages, temperature: state.cfg.temperature, max_tokens: state.cfg.maxTokens }) });
            if (!r.ok) throw new Error(`[${r.status}] ${await r.text()}`);
            const d = await r.json();
            return { text: normalizeProviderText(d.choices?.[0]?.message?.content, d.choices?.[0]?.message?.reasoning_content), grounded: false, inputTokens: d.usage?.prompt_tokens || 0, outputTokens: d.usage?.completion_tokens || 0 };
        }
    }
};
function score(n) {
    n = (n || '').toLowerCase();
    if (n.includes('lite') || n.includes('preview') || n.includes('robotics') || n.includes('gemma') || n.includes('deepseek-v3')) return -1000;
    let match = n.match(/3\.(\d+)/);
    if (match) return 1000 - parseInt(match[1]);
    match = n.match(/2\.(\d+)/);
    if (match) return 500 - parseInt(match[1]);
    if (n.includes('flash')) return 100;
    return 1;
}
async function fetchT(url, opt = {}, ms = 45000, externalSignal) {
    const c = new AbortController();
    const t = setTimeout(() => c.abort(), ms);
    const onExternalAbort = () => c.abort();
    if (externalSignal) externalSignal.addEventListener('abort', onExternalAbort, { once: true });
    try {
        return await fetch(url, { ...opt, signal: c.signal });
    } catch(e) {
        if (e.name === 'AbortError') throw new Error(externalSignal?.aborted ? '请求已取消' : '请求超时');
        throw e;
    } finally {
        clearTimeout(t);
        if (externalSignal) externalSignal.removeEventListener('abort', onExternalAbort);
    }
}
