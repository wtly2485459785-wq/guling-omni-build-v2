// 古灵 APP 原生桥接脚本
(function () {
    function log() {}
    if (!window.Capacitor) { log('not native'); return; }

    // 启动时请求通知权限
    document.addEventListener('deviceready', init, false);
    if (document.readyState !== 'loading') init();

    let inited = false;
    async function init() {
        if (inited) return; inited = true;
        try {
            const LN = Capacitor.Plugins.LocalNotifications;
            if (LN) {
                await LN.requestPermissions();
                // 监听通知点击（预留）
                await LN.registerActionTypes({
                    actions: [{ id: 'open', title: '打开古灵' }]
                }).catch(() => {});
            }
        } catch (e) { console.warn('通知初始化失败', e); }

        // 监听聊天区：出现新的古灵回复时，如果 APP 在后台，弹本地通知
        const box = document.getElementById('chatList');
        if (!box) return;
        let lastCount = box.children.length;
        const observer = new MutationObserver(() => {
            const n = box.children.length;
            if (n > lastCount) {
                const last = box.children[n - 1];
                const isAI = last.classList.contains('ai');
                if (isAI && document.hidden) {
                    try {
                        const text = (last.textContent || '').slice(0, 80);
                        Capacitor.Plugins.LocalNotifications.schedule({
                            notifications: [{
                                title: '古灵回复了',
                                body: text || '点击查看',
                                id: Date.now() % 2147483647,
                                schedule: { at: new Date(Date.now() + 300) }
                            }]
                        });
                    } catch (e) {}
                }
            }
            lastCount = n;
        });
        observer.observe(box, { childList: true });
    }

    // ===== 自定义背景图 =====
    function applyBg() {
        let layer = document.getElementById('bgLayer');
        if (!layer) {
            layer = document.createElement('div');
            layer.id = 'bgLayer';
            layer.style.cssText = 'position:fixed;inset:0;z-index:-1;background-size:cover;background-position:center;opacity:0.7;transition:opacity .3s;pointer-events:none';
            document.body.insertBefore(layer, document.body.firstChild);
        }
        const saved = localStorage.getItem('guling_bg_img');
        const opacity = parseInt(localStorage.getItem('guling_bg_opacity') || '70', 10) / 100;
        if (saved) {
            layer.style.backgroundImage = `url(${saved})`;
            layer.style.opacity = opacity;
        } else {
            layer.style.backgroundImage = 'none';
            layer.style.backgroundColor = '#141d2b';
        }
    }
    function bindBg() {
        applyBg();
        const pickBtn = document.getElementById('pickBgBtn');
        const fileInput = document.getElementById('bgFileInput');
        const clearBtn = document.getElementById('clearBgBtn');
        const opacityRange = document.getElementById('bgOpacityRange');
        const opacityVal = document.getElementById('bgOpacityVal');
        if (!pickBtn || !fileInput) return;

        // 恢复已存的透明度
        const savedOp = localStorage.getItem('guling_bg_opacity');
        if (savedOp && opacityRange) opacityRange.value = savedOp;
        if (opacityVal) opacityVal.textContent = (savedOp || '70') + '%';

        pickBtn.onclick = () => fileInput.click();
        fileInput.onchange = (e) => {
            const f = e.target.files[0];
            if (!f) return;
            const reader = new FileReader();
            reader.onload = () => {
                // 压缩图片，避免 localStorage 超限
                const img = new Image();
                img.onload = () => {
                    const canvas = document.createElement('canvas');
                    const maxW = 1080;
                    const scale = Math.min(1, maxW / img.width);
                    canvas.width = img.width * scale;
                    canvas.height = img.height * scale;
                    canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
                    const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
                    try {
                        localStorage.setItem('guling_bg_img', dataUrl);
                        applyBg();
                        toast('背景图已设置');
                    } catch (err) {
                        toast('图片太大，换一张试试');
                    }
                };
                img.src = reader.result;
            };
            reader.readAsDataURL(f);
        };
        if (clearBtn) clearBtn.onclick = () => {
            localStorage.removeItem('guling_bg_img');
            applyBg();
            toast('已恢复默认背景');
        };
        if (opacityRange) opacityRange.oninput = (e) => {
            const v = e.target.value;
            localStorage.setItem('guling_bg_opacity', v);
            if (opacityVal) opacityVal.textContent = v + '%';
            applyBg();
        };
    }
    // DOM 就绪后绑定
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', bindBg);
    } else {
        bindBg();
    }
})();
