'use strict';

let state = null;
let busy = false;
let pendingFiles = [];
let recognition = null;
let verified = false;
let omniMode = false;
let pendingToolTasks = [];
let toolTaskHistory = [];
let toolTaskSequence = 0;
let lastBackupAt = 0;
let projectRef = null;
let projectZipBytes = null;
let termuxProjectZipUploaded = false;
let toolHistoryExpanded = false;
let modelProbeRunning = false;
let lastProjectSuggestion = '';
let mcpCache = {};
let mcpRequestSeq = 0;
let lastSignalScanResult = null;
let liveTrace = null;

const APPROVABLE_TOOLS = new Set([
    'web_search', 'memory_search', 'web_fetch', 'calc', 'code_run_js',
    'screen_read', 'screen_tap', 'termux_exec', 'shell_exec',
    'browser_open', 'browser_click', 'browser_input', 'browser_read', 'browser_eval', 'browser_close',
    'project_list', 'project_read', 'project_search'
]);
const NATIVE_SCREEN_TOOLS = new Set(['screen_read', 'screen_tap']);
const NATIVE_TERMUX_TOOLS = new Set(['termux_exec']);
const NATIVE_SHELL_TOOLS = new Set(['shell_exec']);
const BROWSER_TOOLS = new Set(['browser_open', 'browser_click', 'browser_input', 'browser_read', 'browser_eval', 'browser_close']);
const MAX_PENDING_TOOLS = 12;

function nativePlugin() {
    return window.Capacitor?.Plugins?.GulingNative || null;
}
function renderApprovalQueue() {
    const list = $('#toolApprovalList');
    if (!list) return;
    const count = pendingToolTasks.length;
    const countLabel = $('#approvalPendingCount');
    if (countLabel) countLabel.textContent = count ? `（${count} 项）` : '（0 项）';
    const omniTabButton = document.querySelector('nav button[data-tab="omni"]');
    if (omniTabButton) {
        const lbl = omniTabButton.querySelector('.nav-lbl');
        const text = count ? `全知中枢·${count}` : '全知中枢';
        if (lbl) lbl.textContent = text; else omniTabButton.textContent = text;
    }
    if (!count) {
        list.innerHTML = '<div class="tool-task-note">当前没有待审批工具任务。</div>';
    } else {
        const statusText = {
            pending: '等待你的确认',
            running: '执行中',
            waitingDevice: '等待 Android 系统通知确认'
        };
        list.innerHTML = pendingToolTasks.map(task => {
            const canAllow = task.status === 'pending' && isApprovableTool(task.name);
            const allowLabel = NATIVE_SCREEN_TOOLS.has(task.name) ? '允许并发送系统确认' : (NATIVE_TERMUX_TOOLS.has(task.name) ? '批准并调用 Termux' : '允许执行');
            const denyLabel = task.status === 'waitingDevice' ? '取消任务' : '拒绝执行';
            const args = JSON.stringify(task.args || {}, null, 2).slice(0, 10000);
            return `<article class="tool-task ${esc(task.status)}">
                <div class="tool-task-head">
                    <div class="tool-task-title">${esc(task.name)} <span class="small">· ${esc(task.source)}</span></div>
                    <div class="tool-task-status">${esc(statusText[task.status] || '处理中')}</div>
                </div>
                <pre class="tool-task-args">${esc(args)}</pre>
                ${task.note ? `<div class="tool-task-note">${esc(task.note)}</div>` : ''}
                ${!isApprovableTool(task.name) ? '<div class="tool-task-note">此工具未列入允许清单，不会执行。</div>' : ''}
                <div class="tool-task-actions">
                    <button class="btn" data-task-action="allow" data-task-id="${esc(task.id)}" ${canAllow ? '' : 'disabled'}>${allowLabel}</button>
                    <button class="btn secondary" data-task-action="deny" data-task-id="${esc(task.id)}" ${task.status === 'running' ? 'disabled' : ''}>${denyLabel}</button>
                </div>
            </article>`;
        }).join('');
    }
    const history = $('#toolApprovalHistory');
    if (history) {
        history.innerHTML = toolTaskHistory.length
            ? toolTaskHistory.slice(0, 12).map(item =>
                `<div class="tool-history-item">${esc(item.name)} · ${esc(item.status)} · ${esc(item.summary)}</div>`
            ).join('')
            : '<div class="tool-task-note">暂无最近任务。</div>';
        history.classList.toggle('collapsed', !toolHistoryExpanded);
    }
    const toggle = $('#toggleHistoryBtn');
    if (toggle) toggle.textContent = `最近任务（${toolTaskHistory.length}）${toolHistoryExpanded ? '▾' : '▸'}`;
}
function settleToolTask(task, outcome) {
    if (!pendingToolTasks.includes(task)) return;
    pendingToolTasks = pendingToolTasks.filter(item => item !== task);
    const summary = String(outcome?.result || '').slice(0, 240);
    toolTaskHistory.unshift({
        name: task.name,
        status: outcome?.ok ? '已执行' : (outcome?.cancelled ? '已拒绝' : '失败'),
        summary
    });
    toolTaskHistory = toolTaskHistory.slice(0, 12);
    renderApprovalQueue();
    task.resolve(outcome || { ok: false, result: '任务已结束' });
}
function enqueueToolTask(name, args, source = '模型') {
    if (pendingToolTasks.length >= MAX_PENDING_TOOLS) {
        return Promise.resolve({ ok: false, result: `待审批队列已满（最多 ${MAX_PENDING_TOOLS} 项），未创建任务。` });
    }
    return new Promise(resolve => {
        const task = {
            id: `tool-${Date.now()}-${++toolTaskSequence}`,
            name,
            args: args && typeof args === 'object' ? args : {},
            source,
            status: 'pending',
            resolve
        };
        pendingToolTasks.unshift(task);
        renderApprovalQueue();
        tab('omni');
    });
}
async function denyToolTask(id) {
    const task = pendingToolTasks.find(item => item.id === id);
    if (!task || task.status === 'running') return;
    if (task.status === 'waitingDevice') {
        try { await nativePlugin()?.cancelScreenAction?.({ taskId: task.id }); } catch (_) {}
    }
    settleToolTask(task, { ok: false, cancelled: true, result: '创造者拒绝或取消了任务。' });
}
async function pollNativeToolTask(task) {
    const plugin = nativePlugin();
    if (!plugin || task.polling) return;
    task.polling = true;
    try {
        while (pendingToolTasks.includes(task) && task.status === 'waitingDevice') {
            if (!document.hidden) {
                const response = await plugin.pollScreenAction({ taskId: task.id });
                if (response?.ready) {
                    settleToolTask(task, {
                        ok: response.ok !== false,
                        result: response.result || (response.ok === false ? '系统操作失败。' : '操作完成。')
                    });
                    break;
                }
            }
            await new Promise(resolve => setTimeout(resolve, 1000));
        }
    } catch (error) {
        settleToolTask(task, { ok: false, result: `读取系统操作结果失败：${error.message}` });
    } finally {
        task.polling = false;
    }
}
async function approveToolTask(id) {
    const task = pendingToolTasks.find(item => item.id === id);
    if (!task || task.status !== 'pending') return;
    if (!isApprovableTool(task.name)) return;

    if (NATIVE_TERMUX_TOOLS.has(task.name)) {
        const plugin = nativePlugin();
        const command = String(task.args.command || task.args.cmd || '').trim();
        if (!plugin) {
            settleToolTask(task, { ok: false, result: 'Termux 调用只支持已安装的 Android 古灵应用。' });
            return;
        }
        if (!command || command.length > 2000) {
            settleToolTask(task, { ok: false, result: '命令为空或超过 2000 字符，未执行。' });
            return;
        }
        task.status = 'running';
        task.note = '已人工批准，正在向 Termux 提交命令并等待结果。';
        renderApprovalQueue();
        try {
            const status = await plugin.getTermuxStatus();
            if (!status.termuxInstalled) {
                throw new Error('未检测到 Termux，请先安装并至少启动一次 F-Droid 版 Termux。');
            }
            const queued = await plugin.queueTermuxCommand({ taskId: task.id, command });
            task.status = 'waitingDevice';
            task.note = queued.message || '已提交 Termux，等待命令结果。';
            renderApprovalQueue();
            const deadline = Date.now() + TERMUX_RESULT_TIMEOUT_MS;
            while (pendingToolTasks.includes(task) && task.status === 'waitingDevice' && Date.now() < deadline) {
                const result = await plugin.pollTermuxCommand({ taskId: task.id });
                if (result?.ready) {
                    const combined = [result.stdout, result.stderr ? `stderr:\n${result.stderr}` : '', result.error ? `错误：${result.error}` : '', `退出码：${result.exitCode}`].filter(Boolean).join('\n');
                    settleToolTask(task, { ok: result.exitCode === 0 && !result.error, result: combined.slice(0, 6000) || 'Termux 已执行，但没有输出。' });
                    return;
                }
                await new Promise(resolve => setTimeout(resolve, 900));
            }
            if (pendingToolTasks.includes(task)) settleToolTask(task, { ok: false, result: '等待 Termux 结果超时；命令可能仍在后台运行，请检查 Termux。' });
        } catch (error) {
            settleToolTask(task, { ok: false, result: `Termux 调用失败：${error.message}` });
        }
        return;
    }

    if (NATIVE_SCREEN_TOOLS.has(task.name)) {
        const plugin = nativePlugin();
        if (!plugin) {
            settleToolTask(task, { ok: false, result: '此功能只在安装后的 Android 应用中可用。' });
            return;
        }
        task.status = 'waitingDevice';
        task.note = '已在古灵中批准。请切换到目标应用，再点击手机通知中的执行按钮；此步骤用于确认当前屏幕。';
        renderApprovalQueue();
        try {
            await plugin.queueScreenAction({ taskId: task.id, toolName: task.name, args: task.args });
            pollNativeToolTask(task);
        } catch (error) {
            settleToolTask(task, { ok: false, result: `无法创建系统确认通知：${error.message}` });
        }
        return;
    }

    if (NATIVE_SHELL_TOOLS.has(task.name)) {
        const plugin = nativePlugin();
        const command = String(task.args.command || task.args.cmd || '').trim();
        if (!plugin) {
            settleToolTask(task, { ok: false, result: '内置 Shell 只在 Android 安装版中可用。' });
            return;
        }
        if (!command || command.length > 4000) {
            settleToolTask(task, { ok: false, result: '命令为空或超过 4000 字符，未执行。' });
            return;
        }
        task.status = 'running';
        task.note = '已批准，正在系统 shell 中执行命令...';
        renderApprovalQueue();
        try {
            const r = await plugin.execShell({ command, timeout: task.args.timeout || 30000 });
            const parts = [];
            if (r.stdout) parts.push(r.stdout);
            if (r.stderr) parts.push('stderr:\n' + r.stderr);
            parts.push(`[${r.method || 'shell'} · exit ${r.exitCode}]`);
            settleToolTask(task, { ok: r.exitCode === 0, result: parts.join('\n').slice(0, 8000) || '命令已执行，无输出。' });
        } catch (error) {
            settleToolTask(task, { ok: false, result: `Shell 执行失败：${error.message}` });
        }
        return;
    }

    if (BROWSER_TOOLS.has(task.name)) {
        const plugin = nativePlugin();
        if (!plugin) {
            settleToolTask(task, { ok: false, result: '浏览器自动化只在 Android 安装版中可用。' });
            return;
        }
        task.status = 'running';
        task.note = '已批准，正在操作内置浏览器...';
        renderApprovalQueue();
        try {
            let r;
            if (task.name === 'browser_open') r = await plugin.browserOpen({ url: task.args.url || '' });
            else if (task.name === 'browser_click') r = await plugin.browserClick({ selector: task.args.selector || '' });
            else if (task.name === 'browser_input') r = await plugin.browserInput({ selector: task.args.selector || '', text: task.args.text || '' });
            else if (task.name === 'browser_read') r = await plugin.browserRead();
            else if (task.name === 'browser_eval') r = await plugin.browserEval({ script: task.args.script || '' });
            else if (task.name === 'browser_close') r = await plugin.browserClose();
            settleToolTask(task, { ok: true, result: JSON.stringify(r, null, 2).slice(0, 6000) });
        } catch (error) {
            settleToolTask(task, { ok: false, result: `浏览器操作失败：${error.message}` });
        }
        return;
    }

    task.status = 'running';
    task.note = '已人工批准；仅执行此任务所列的读取或本地计算操作。';
    renderApprovalQueue();
    try {
        const result = await executeTool(task.name, task.args);
        settleToolTask(task, { ok: true, result: String(result) });
    } catch (error) {
        settleToolTask(task, { ok: false, result: `执行失败：${error.message}` });
    }
}
function rejectAllPendingToolTasks() {
    pendingToolTasks.slice().forEach(task => denyToolTask(task.id));
}
function refreshNativeStatus() {
    const status = $('#nativeCapabilityStatus');
    const start = $('#startNativeServices');
    const stop = $('#stopNativeServices');
    if (!status) return;
    const plugin = nativePlugin();
    if (!plugin) {
        status.textContent = '此页面不是 Android 安装版；悬浮球、常驻服务和无障碍能力不可用。';
        return;
    }
    plugin.getStatus().then(result => {
        const ok = (label, cond) => `<span style="color:${cond ? '#4ade80' : '#f87171'}">${label}：${cond ? '✓' : '✗'}</span>`;
        status.innerHTML = [
            ok('悬浮窗权限', result.overlayPermission),
            ok('常驻服务', result.foregroundService),
            ok('无障碍服务', result.accessibilityEnabled),
            ok('通知权限', result.notificationPermission)
        ].join(' · ');
        status.classList.add('native-status');
        if (start) start.disabled = !!result.foregroundService;
        if (stop) stop.disabled = !result.foregroundService;
    }).catch(error => {
        status.textContent = `无法读取原生能力状态：${error.message}`;
    });
}

function signalQualityLabel(q) {
    return { excellent: '极强', good: '良好', fair: '一般', weak: '较弱' }[q] || q;
}
function signalQualityColor(q) {
    return { excellent: '#4ade80', good: '#60a5fa', fair: '#fbbf24', weak: '#f87171' }[q] || 'var(--muted)';
}
function securityColor(s) {
    if (s === 'Open') return '#f87171';
    if (s === 'WEP') return '#fbbf24';
    return '#4ade80';
}
function renderSignalScanResult(result) {
    const summary = result.summary || {};
    const wifi = Array.isArray(result.wifi) ? result.wifi : [];
    const ble = Array.isArray(result.ble) ? result.ble : [];
    const envText = { dense: '密集（办公楼/商场级）', normal: '正常（普通室内）', sparse: '稀疏（开阔/郊区）' }[summary.environment] || summary.environment;
    const bands = summary.bands || {};
    const sigDist = summary.signalDistribution || {};
    const crowded = Array.isArray(summary.crowdedChannels) ? summary.crowdedChannels : [];

    const sumBox = $('#signalSummary');
    if (sumBox) {
        sumBox.style.display = 'block';
        sumBox.innerHTML = `
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:8px;margin-bottom:8px">
            <div class="stat"><div class="stat-num">${summary.wifiCount || 0}</div><div class="stat-label">WiFi 热点</div></div>
            <div class="stat"><div class="stat-num">${summary.bleCount || 0}</div><div class="stat-label">蓝牙设备</div></div>
            <div class="stat"><div class="stat-num" style="color:${summary.openWifiCount ? '#f87171' : '#4ade80'}">${summary.openWifiCount || 0}</div><div class="stat-label">开放网络</div></div>
            <div class="stat"><div class="stat-num">${envText}</div><div class="stat-label">环境密度</div></div>
        </div>
        <div class="small" style="color:var(--muted);line-height:1.7">
            频段分布：2.4GHz ${bands['2.4GHz'] || 0} 个 · 5GHz ${bands['5GHz'] || 0} 个 · 6GHz ${bands['6GHz'] || 0} 个<br>
            信号质量：<span style="color:#4ade80">极强 ${sigDist.excellent || 0}</span> · <span style="color:#60a5fa">良好 ${sigDist.good || 0}</span> · <span style="color:#fbbf24">一般 ${sigDist.fair || 0}</span> · <span style="color:#f87171">较弱 ${sigDist.weak || 0}</span><br>
            最强 WiFi：${esc(summary.strongestWifi || '（无）')} ${summary.strongestRssi > -200 ? `(${summary.strongestRssi} dBm)` : ''}<br>
            ${crowded.length ? `2.4GHz 拥挤信道：${crowded.slice(0, 5).map(c => `CH${c.channel}(${c.count})`).join('、')}` : ''}
            ${!summary.wifiReady ? '<br><span style="color:#fbbf24">⚠️ WiFi 未开启，结果可能不完整</span>' : ''}
            ${!summary.bleReady ? '<br><span style="color:#fbbf24">⚠️ 蓝牙未开启，无法扫描 BLE 设备</span>' : ''}
        </div>`;
    }
    const wifiBox = $('#signalWifiList');
    if (wifiBox) {
        if (!wifi.length) {
            wifiBox.innerHTML = '<div class="small" style="color:var(--muted)">未发现 WiFi 热点。</div>';
        } else {
            const rows = [...wifi].sort((a, b) => b.rssi - a.rssi).map(w => `
                <div class="signal-row" style="display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid var(--line)">
                    <div style="width:8px;height:24px;background:${signalQualityColor(w.signalQuality)};border-radius:2px;flex-shrink:0"></div>
                    <div style="flex:1;min-width:0">
                        <div style="font-size:13px;font-weight:600">${esc(w.ssid || '(隐藏网络)')} <span class="small" style="color:var(--muted);font-weight:400">${esc(w.bssid)}</span></div>
                        <div class="small" style="color:var(--muted)">${w.band} · CH${w.channel} · <span style="color:${securityColor(w.security)}">${w.security}</span> · ${signalQualityLabel(w.signalQuality)} · ~${w.distanceMeters}m</div>
                    </div>
                    <div style="font-size:13px;color:${signalQualityColor(w.signalQuality)};font-weight:600">${w.rssi} dBm</div>
                </div>`).join('');
            wifiBox.innerHTML = `<div style="font-size:12px;font-weight:600;margin-bottom:4px">📶 WiFi 热点（按信号强度排序）</div>${rows}`;
        }
    }
    const bleBox = $('#signalBleList');
    if (bleBox) {
        if (!ble.length) {
            bleBox.innerHTML = '<div class="small" style="color:var(--muted)">未发现蓝牙设备。</div>';
        } else {
            const rows = [...ble].sort((a, b) => b.rssi - a.rssi).map(d => `
                <div class="signal-row" style="display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid var(--line)">
                    <div style="flex:1;min-width:0">
                        <div style="font-size:13px;font-weight:600">${esc(d.name || '(无名称)')} <span class="small" style="color:var(--muted);font-weight:400">${esc(d.address)}</span></div>
                        <div class="small" style="color:var(--muted)">~${d.distanceMeters}m${d.serviceUuids?.length ? ` · ${d.serviceUuids.length} 个服务 UUID` : ''}${d.manufacturerId !== undefined ? ` · 厂商ID:0x${(d.manufacturerId).toString(16)}` : ''}</div>
                    </div>
                    <div style="font-size:13px;font-weight:600">${d.rssi} dBm</div>
                </div>`).join('');
            bleBox.innerHTML = `<div style="font-size:12px;font-weight:600;margin-bottom:4px">🔵 蓝牙设备（按信号强度排序）</div>${rows}`;
        }
    }
}

async function runLocalSelfCheck() {
    const out = $('#selfCheckOutput');
    if (!out) return;
    const lines = [];
    const check = (name, ok, detail = '') => lines.push(`${ok ? '✓' : '✗'} ${name}${detail ? '：' + detail : ''}`);
    check('应用状态', !!state && Array.isArray(state.sessions), state ? '状态对象可读取' : '状态未初始化');
    check('模型提供商注册', !!(state?.cfg?.provider && PROVIDERS[state.cfg.provider]), state?.cfg?.provider || '未配置');
    check('请求函数', typeof callAI === 'function' && typeof fetchT === 'function', '关键函数存在');
    check('工具审批队列', Array.isArray(pendingToolTasks) && pendingToolTasks.length <= MAX_PENDING_TOOLS, `${pendingToolTasks.length}/${MAX_PENDING_TOOLS}`);
    try {
        const key = '__omni_selfcheck__'; localStorage.setItem(key, 'ok');
        const good = localStorage.getItem(key) === 'ok'; localStorage.removeItem(key);
        check('本地存储读写', good);
    } catch (e) { check('本地存储读写', false, e.message); }
    const mcpList = mcpServers();
    const mcpReady = mcpList.filter(server => server.enabled && mcpCache[server.id]?.status === 'ready');
    check('MCP 工具接入', typeof callMcpTool === 'function' && typeof isApprovableTool === 'function', mcpList.length ? `已配置 ${mcpList.length} 个服务器，已连接 ${mcpReady.length} 个` : '未配置 MCP 服务器（可选）');
    check('Android 原生桥接', !!nativePlugin(), nativePlugin() ? '已检测到插件' : '当前运行环境未检测到插件（网页模式正常）');
    if (nativePlugin()) {
        try {
            const native = await nativePlugin().getStatus();
            check('Android 服务状态读取', !!native, `悬浮服务=${native?.foregroundService ? '运行中' : '停止'}；无障碍=${native?.accessibilityEnabled ? '启用' : '未启用'}`);
        } catch (e) { check('Android 服务状态读取', false, e.message); }
    }
    const active = getActiveSession();
    const latestFailure = [...(active?.messages || [])].reverse().find(m => m.role === 'assistant' && String(m.text || '').startsWith('请求失败：'));
    check('最近一次请求', !latestFailure, latestFailure ? String(latestFailure.text).replace(/^请求失败：\s*/, '').slice(0, 180) : '未发现失败消息');
    lines.push('', '说明：这是本地静态/状态检查，不会调用模型，不等于端到端测试，也不会验证 API Key 是否有效。');
    out.textContent = lines.join('\n');
}

function defaultState() {
    return {
        sessions: [{ id: Date.now().toString(), name: '对话 1', messages: [] }],
        active: null,
        mem: [],
        cfg: {
            provider: 'gemini',
            model: 'auto',
            apiKey: '',
            models: [],
            version: VERSION,
            backendUrl: 'http://127.0.0.1:11434',
            localEngine: 'ollama',
            rulesVersion: RULES_VERSION,
            coreLaw: DEFAULT_LAW,
            coreRules: [...DEFAULT_RULES],
            roleCard: DEFAULT_ROLE_CARD,
            aiMode: 'remote',
            temperature: 0.7,
            maxTokens: 4096,
            contextMessages: 12,
            omniMode:false,
            rememberKey: true,
            mcpServers: [],
            searchProvider: 'builtin',
            searchApiKey: '',
            github: { token: '', user: '', repo: '' }
        },
        meta: { mode: 'guling' }
    };
}
function clampInt(v, min, max, fallback) {
    const n = parseInt(v, 10);
    if (!Number.isFinite(n)) return fallback;
    return Math.max(min, Math.min(max, n));
}
function loadState() {
    try {
        let raw = localStorage.getItem(STORE);
        // 升级兼容：当前存储键不存在时，尝试读取历史版本键并迁移。
        // 只有确认内容是状态对象后才写入新键，原键永远不删除。
        if (!raw) {
            const legacyKeys = ['guling_omni_v15', 'guling_final_vision_v14', 'guling_final_vision_v1'];
            for (const legacyKey of legacyKeys) {
                try {
                    const candidate = localStorage.getItem(legacyKey);
                    if (!candidate) continue;
                    const legacyState = JSON.parse(candidate);
                    if (!legacyState || typeof legacyState !== 'object' || Array.isArray(legacyState)) continue;
                    if (!legacyState.cfg && !Array.isArray(legacyState.mem) && !Array.isArray(legacyState.sessions)) continue;
                    raw = candidate;
                    try { localStorage.setItem(STORE, candidate); } catch (migrationError) {
                        console.warn('旧版数据已读取，但迁移到新键失败；原始数据仍保留。', migrationError);
                    }
                    console.info('已从旧版存储迁移数据：', legacyKey);
                    break;
                } catch (migrationError) { console.warn('跳过无法读取的旧版存储键：', legacyKey, migrationError); }
            }
        }
        if (raw) {
            let parsed;
            try { parsed = JSON.parse(raw); } catch (err) { return defaultState(); }
            if (!parsed || typeof parsed !== 'object') return defaultState();
            if (!parsed.cfg) parsed.cfg = defaultState().cfg;
            delete parsed.cfg.autoToolConfirm;
            if (!Array.isArray(parsed.mem)) parsed.mem = [];
            if (!Array.isArray(parsed.cfg.coreRules) || !parsed.cfg.coreRules.length) parsed.cfg.coreRules = [...DEFAULT_RULES];
            if (!parsed.cfg.provider) parsed.cfg.provider = 'gemini';
            if (!parsed.cfg.model) parsed.cfg.model = 'auto';
            if (!parsed.cfg.models) parsed.cfg.models = [];
            delete parsed.cfg.patches; // 已移除补丁功能及其历史数据
            delete parsed.cfg.profiles; // 已移除配置管理功能及其历史数据
            if (!parsed.cfg.version) parsed.cfg.version = VERSION;
            if (parsed.cfg.temperature === undefined) parsed.cfg.temperature = 0.7;
            if (parsed.cfg.maxTokens === undefined) parsed.cfg.maxTokens = 4096;
            parsed.cfg.contextMessages = clampInt(parsed.cfg.contextMessages, 4, 40, 12);
            if (!parsed.cfg.backendUrl || parsed.cfg.backendUrl === 'http://127.0.0.1:5000') parsed.cfg.backendUrl = parsed.cfg.localEngine === 'lmstudio' ? 'http://127.0.0.1:1234' : 'http://127.0.0.1:11434';
            if (!parsed.cfg.localEngine) parsed.cfg.localEngine = 'ollama';
            if (!parsed.cfg.roleCard || typeof parsed.cfg.roleCard !== 'string' || !parsed.cfg.roleCard.trim() || parsed.cfg.roleCard.indexOf('银月') === 0) {
                parsed.cfg.roleCard = DEFAULT_ROLE_CARD;
            }
            if (!parsed.cfg.rulesVersion || parsed.cfg.rulesVersion !== RULES_VERSION) {
                if (parsed.cfg.rulesVersion !== 'custom') {
                    parsed.cfg.coreLaw = DEFAULT_LAW;
                    parsed.cfg.coreRules = [...DEFAULT_RULES];
                }
                parsed.cfg.rulesVersion = RULES_VERSION;
            }
            if (!parsed.cfg.aiMode) parsed.cfg.aiMode = 'remote';
            if (!Array.isArray(parsed.cfg.mcpServers)) parsed.cfg.mcpServers = [];
            parsed.cfg.mcpServers = parsed.cfg.mcpServers
                .filter(item => item && typeof item.url === 'string' && isValidMcpUrl(item.url))
                .slice(0, 10)
                .map((item, index) => ({
                    id: String(item.id || `legacy-mcp-${index}`),
                    name: String(item.name || item.url).slice(0, 40),
                    url: item.url.trim(),
                    token: String(item.token || ''),
                    enabled: item.enabled !== false
                }));
            if (!parsed.meta) parsed.meta = { mode: 'guling' };
            // 模式代号升级：旧版 yinyue / 过渡期 god、shenling 统一迁移到 God。
            if (parsed.meta.mode === 'yinyue' || parsed.meta.mode === 'god' || parsed.meta.mode === 'shenling') parsed.meta.mode = 'God';
            if (parsed.cfg.rememberKey === undefined) parsed.cfg.rememberKey = true;
            if (!parsed.cfg.rememberKey) parsed.cfg.apiKey = '';
            if (!['builtin','keiro','tavily'].includes(parsed.cfg.searchProvider)) parsed.cfg.searchProvider = 'builtin';
            if (typeof parsed.cfg.searchApiKey !== 'string') parsed.cfg.searchApiKey = '';
            if (!Array.isArray(parsed.sessions) || parsed.sessions.length === 0) {
                parsed.sessions = defaultState().sessions;
            }
            omniMode = !!parsed.cfg.omniMode;
            return parsed;
        }
    } catch(e) {
        console.error("读取本地数据异常", e);
    }
    return defaultState();
}
function saveState() {
    try {
        const p = JSON.parse(JSON.stringify(state));
        if (p.cfg && p.cfg.rememberKey === false) p.cfg.apiKey = '';
        localStorage.setItem(STORE, JSON.stringify(p));
        writeAutoBackup();
        saveState._n = (saveState._n || 0) + 1;
        if (saveState._n % 30 === 0) checkStorageUsage();
    } catch(e) {
        toast('⚠️ 本地存储写入失败（可能空间已满），请导出数据后清理', 'bad');
    }
}
function writeAutoBackup(force) {
    const now = Date.now();
    if (!force && now - lastBackupAt < BACKUP_THROTTLE_MS) return;
    lastBackupAt = now;
    try {
        const data = JSON.parse(JSON.stringify(state));
        if (data.cfg) {
            data.cfg.apiKey = '';
            data.cfg.searchApiKey = '';
            data.cfg.mcpServers = (data.cfg.mcpServers || []).map(server => ({ ...server, token: '' }));
        }
        data.__backupTime = now;
        localStorage.setItem(BACKUP_STORE, JSON.stringify(data));
    } catch(e) { console.warn('自动备份失败', e); }
}
function checkStorageUsage() {
    try {
        let total = 0;
        for (let i = 0; i < localStorage.length; i++) {
            const k = localStorage.key(i);
            if (!k) continue;
            total += (localStorage.getItem(k) || '').length + k.length;
        }
        const mb = total / 1024 / 1024;
        if (mb > 4) toast(`⚠️ 本地存储已用 ${mb.toFixed(1)}MB（约5MB上限），建议导出后清理`, 'bad');
    } catch(_) {}
}
function sanitizeApiKey(v) {
    let k = String(v ?? '');
    try { k = k.normalize('NFKC'); } catch(e) {}
    k = k.replace(/[\u200B-\u200D\u2060\uFEFF\u00A0\u3000]/g, '');
    k = k.replace(/[\r\n\t ]+/g, '');
    k = k.replace(/[^\x21-\x7E]/g, '');
    return k;
}
function getSanitizedApiKey(v) {
    const k = sanitizeApiKey(v);
    if (k && !/^[A-Za-z0-9._~+\-]+$/.test(k)) throw new Error('API Key 含有非法字符');
    return k;
}
function getActiveSession() { return state.sessions.find(s => s.id === state.active) || state.sessions[0]; }
const MODES = { guling: '古灵', guojia: '郭嘉', God: '神灵' };
function keywordScore(hay,kw){
    const h = hay.toLowerCase();
    const ks = kw.toLowerCase().split(/\s+/);
    let s=0;
    ks.forEach(k=>{if(k&&h.includes(k)) s+=1;});
    return s;
}
function recallMemoryByQuery(query){
    if(!state.mem.length) return "（暂无匹配记忆）";
    const scored = state.mem.map((txt,i)=>({i,txt,score:keywordScore(txt,query)}));
    const filtered = scored.filter(x=>x.score>0).sort((a,b)=>b.score - a.score);
    const picked = [];
    let total=0;
    for(const item of filtered){
        const block = `#${item.i+1} ${item.txt}`;
        if(total+block.length>MAX_MEM_CHARS*0.65) break;
        picked.push(block);
        total+=block.length;
    }
    if(picked.length===0) return "（没有检索到相关永久记忆）";
    return `【相关性召回记忆${picked.length}条】\n`+picked.join("\n");
}
function buildMemBlock() {
    if (!state.mem.length) return '（暂无永久记忆）';
    const picked = [];
    let total = 0;
    for (let i = state.mem.length - 1; i >= 0; i--) {
        const item = `#${i + 1} ${state.mem[i]}`;
        if (total + item.length > MAX_MEM_CHARS) break;
        picked.unshift(item);
        total += item.length;
    }
    if (picked.length < state.mem.length) {
        return `（注意：记忆库共 ${state.mem.length} 条，已按长度上限仅注入最近 ${picked.length} 条，较早的记忆未进入上下文）\n` + picked.join('\n');
    }
    return picked.join('\n');
}
const ROLE_BY_MODE = { guling: '古灵', guojia: '郭嘉', God: '神灵' };
const ROLE_KEYS = ['神灵', '郭嘉', '古灵'];
function splitRoleCard() {
    const text = String((state && state.cfg && state.cfg.roleCard) || DEFAULT_ROLE_CARD);
    const out = {};
    ROLE_KEYS.forEach(k => {
        const start = text.indexOf(k);
        if (start < 0) { out[k] = ''; return; }
        let end = text.length;
        ROLE_KEYS.forEach(k2 => {
            if (k2 === k) return;
            const p = text.indexOf(k2, start + k.length);
            if (p > start && p < end) end = p;
        });
        out[k] = text.slice(start, end).trim();
    });
    return out;
}
function getRoleCardSegment(mode) {
    return (splitRoleCard()[ROLE_BY_MODE[mode] || '古灵'] || '').slice(0, 240);
}
let editingRuleKey = null;
function ruleTableRows() {
    const rows = [{ key: 'law', no: '规律', type: '规律', text: state.cfg.coreLaw || DEFAULT_LAW, del: false }];
    (state.cfg.coreRules || []).forEach((r, i) => {
        rows.push({ key: `rule:${i}`, no: String(i + 1), type: '规则', text: r, del: true });
    });
    const seg = splitRoleCard();
    ['God', 'guojia', 'guling'].forEach(m => {
        const name = ROLE_BY_MODE[m];
        if (!seg[name]) return;
        rows.push({ key: `role:${m}`, no: '—', type: `角色卡·${name}`, text: seg[name], del: false });
    });
    return rows;
}
function renderRulesTable() {
    const body = $('#rulesTableBody');
    if (!body) return;
    body.innerHTML = ruleTableRows().map(r => {
        const short = r.text.length > 90 ? r.text.slice(0, 90) + '…' : r.text;
        return `<tr><td class="rt-no">${r.no}</td><td class="rt-type">${esc(r.type)}</td><td class="rt-text">${esc(short)}</td>`
            + `<td class="rt-act"><button type="button" onclick="editRuleRow('${r.key}')">改</button>`
            + (r.del ? `<button type="button" class="rt-del" onclick="deleteRuleRow('${r.key}')">×</button>` : '')
            + '</td></tr>';
    }).join('');
}
function editRuleRow(key) {
    const row = ruleTableRows().find(r => r.key === key);
    if (!row) return;
    editingRuleKey = key;
    const panel = $('#ruleEditor'), ta = $('#ruleEditorBox');
    if (!panel || !ta) return;
    ta.value = row.text;
    panel.style.display = 'block';
    ta.focus();
}
function saveRuleEdit() {
    if (!editingRuleKey) return;
    const ta = $('#ruleEditorBox');
    const v = ta ? ta.value.trim() : '';
    if (!v) { toast('内容不能为空'); return; }
    if (editingRuleKey === 'law') {
        state.cfg.coreLaw = v;
        state.cfg.rulesVersion = 'custom';
    } else if (editingRuleKey.indexOf('rule:') === 0) {
        const i = Number(editingRuleKey.slice(5));
        if (state.cfg.coreRules[i] === undefined) return;
        state.cfg.coreRules[i] = v;
        state.cfg.rulesVersion = 'custom';
    } else if (editingRuleKey.indexOf('role:') === 0) {
        const name = ROLE_BY_MODE[editingRuleKey.slice(5)];
        if (!name) return;
        const seg = splitRoleCard();
        seg[name] = v;
        state.cfg.roleCard = ROLE_KEYS.map(k => seg[k]).filter(Boolean).join('\n');
    }
    editingRuleKey = null;
    if ($('#ruleEditor')) $('#ruleEditor').style.display = 'none';
    saveState(); render(); toast('已保存', 'ok');
}
function cancelRuleEdit() {
    editingRuleKey = null;
    if ($('#ruleEditor')) $('#ruleEditor').style.display = 'none';
}
function deleteRuleRow(key) {
    if (key.indexOf('rule:') !== 0) return;
    const i = Number(key.slice(5));
    if (state.cfg.coreRules[i] === undefined) return;
    state.cfg.coreRules.splice(i, 1);
    state.cfg.rulesVersion = 'custom';
    saveState(); render();
}
function getPrompt() {
    const coreLaw = state.cfg.coreLaw || DEFAULT_LAW;
    const coreRules = Array.isArray(state.cfg.coreRules) && state.cfg.coreRules.length ? state.cfg.coreRules : [...DEFAULT_RULES];
    const mode = state.meta.mode || 'guling';
    let modeInstruction = '';
    let identity = '';
    if (mode === 'God') {
        identity = '你是神灵（创造者的专属智能助手）。';
        modeInstruction = '【当前模式：神灵】以神明的视角看待一切，直接给出判断与方案，不铺垫。';
    } else if (mode === 'guojia') {
        identity = '你是郭嘉（创造者的专属智能助手）。';
        modeInstruction = '【当前模式：郭嘉】先给全局判断与取舍，再给可执行路径，保持简洁果断。';
    } else {
        identity = '你是古灵 OMNI（创造者的专属智能助手）。';
        modeInstruction = '【当前模式：古灵】真实、直接：先给结论与方案，必要时补足依据，不故作神秘、不夸大能力。';
    }
    const cardSegment = getRoleCardSegment(mode);
    const roleNote = cardSegment
        ? `\n【角色卡】按此设定把握语气与性格，可以带角色感；诗句只作背景设定，不要逐句照搬进回答：${cardSegment}`
        : '';
    const mcpNote = omniMode ? mcpToolsPrompt() : '';
    const omniNote = omniMode
        ? `\n【全知全能模式已开启】可提出工具请求，格式示例：[[TOOL:web_search{"query":"今天的新闻"}]]。工具名必须是下方列出的真实名称，禁止照抄示例、禁止使用“工具名”“参数”“值”等占位符；不需要工具时直接正常回答，不要输出空的工具模板。内置允许工具：web_search,memory_search,web_fetch,calc,code_run_js,screen_read,screen_tap,termux_exec,shell_exec,browser_open,browser_click,browser_input,browser_read,browser_eval,browser_close,project_list,project_read,project_search。termux_exec 参数为 {"command":"要执行的 shell 命令"}；shell_exec 同参数，用系统自带 shell 执行（无需安装 Termux）；browser_open {"url":"网址"} 打开页面；browser_click {"selector":"CSS选择器"} 点击元素；browser_input {"selector":"","text":""} 填写输入框；browser_read 读取页面文字；browser_eval {"script":"JS代码"} 执行JS；browser_close 关闭浏览器。project_list 列出创造者上传的项目文件；project_read 参数为 {"path":"文件路径"}；project_search 参数为 {"query":"关键词"}。每项请求先进入待审批队列，未经创造者逐项允许不得执行；禁止自动放行。联网仅限只读 GET；code_run_js 仅用于隔离沙箱计算；screen_read 读取当前屏幕文字；screen_tap 参数必须包含最近一次 screen_read 返回的控件序号 index 和控件文字 expectedText。两个屏幕工具都需要先在古灵内批准，再点击 Android 系统通知中的执行按钮。执行结果返回后再继续回答；不得声称未执行的任务已完成。工具返回失败时，只允许原样转述退出码和 stderr 摘要，禁止自行推测失败原因，也禁止编造替代命令。【硬规则】当创造者明确要求“执行某条命令”“跑一下某命令”“用 shell_exec 执行”时，必须直接发出 [[TOOL:shell_exec{"command":"..."}]] 或 [[TOOL:termux_exec{"command":"..."}]] 请求，禁止用文字回答代替，禁止回答“同上”“之前失败过”“要不要我试一下”之类的内容，禁止追问确认；即使上一次执行失败，也必须按创造者新的要求重新发起请求。${mcpNote}\n【shell_exec 运行环境】使用 Android 自带 /system/bin/sh（toybox）。实际可用的命令：ls、cat、cp、mv、rm、mkdir、rmdir、find、grep、sed、cut、sort、uniq、head、tail、wc、tar、gzip、gunzip、zcat、md5sum、sha1sum、stat、date、df、du、ps、top、ping、netstat、getprop、dumpsys、pm、am、input、screencap、settings、log、pidof、pkill、kill、timeout、xargs、basename、dirname、realpath、readlink、printf、echo、seq、split、diff、cmp、base64、xxd。**不存在**的命令：zip、unzip、curl、wget、awk、python、python3、node、git、ssh、ffmpeg。需要压缩时用 tar -czf 输出.tar.gz 路径；解压用 tar -xzf 文件；单个文件压缩用 gzip。命令里所有路径必须写成绝对路径并用双引号包住，禁止使用空变量或相对路径；执行前先确认路径存在（如 ls 目标目录）。`
        : `\n【联网检索】遇到实时或时效性信息（天气、新闻、价格、汇率、比分、版本号、今天发生的事），必须优先发起联网检索，格式：[[TOOL:web_search{"query":"具体检索词"}]]。请求会进入创造者的待审批列表，批准后自动执行并把结果回传；不需要联网时正常回答，不要输出空的工具模板。`;
    const projectNote = projectRef
        ? `\n【项目参考】已永久保存项目「${projectRef.name}」，共 ${projectRef.files.length} 个可读文本文件。需要查看时使用 project_list / project_search / project_read。`
        : '';

    return `${identity}
【最高准则 - 核心规律（1条）】${coreLaw}
【次级约束 - 核心规则（${coreRules.length}条）】在不违背核心规律的前提下，严格遵守以下规则：\n${coreRules.join('\n')}
【当前系统运行模式】${modeInstruction}${roleNote}${omniNote}${projectNote}${selfProfileNote()}
【本地长期记忆】\n${buildMemBlock()}
【核心能力与红线警告】回答实时类问题时，必须先尝试联网检索：Gemini 直连会自动联网搜索，其他模型必须先发出 web_search 请求。只有在检索被拒绝、执行失败或结果为空时，才可说明未能获取实时信息，并原样转述失败原因。严禁编造任何实时数据，严禁在尚未尝试检索前就回答"未联网"。若违反此项，将被视为严重违规。请保持古灵/郭嘉/神灵的角色性格进行回复。
【输出格式】使用纯文本回答，禁止使用 Markdown 标记：不要用 **加粗**、反引号包裹命令名、# 标题、表格分隔线；只有需要给出可直接执行的命令或代码时才使用代码块，其余一律用普通中文标点。禁止编造失败原因，工具失败时只转述退出码与报错原文。`;
}
function $ (s) { return document.querySelector(s); }
function $$(s) { return [...document.querySelectorAll(s)]; }
function esc(s) { return String(s ?? '').replace(/[&<>"]/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;' }[c])); }
// 工具标记不应出现在聊天气泡里（已被解析成待审批任务）
function stripToolMarkers(s) {
    return String(s ?? '').replace(/\[\[TOOL:[\s\S]*?\]\]/g, '').trim();
}
function displayText(s) { return stripToolMarkers(stripProjectFiles(s)); }
// 轻量 Markdown 渲染：先转义，再还原代码块/行内代码/加粗/标题，避免原始符号直接暴露给用户
function mdToHtml(s) {
    let t = esc(s);
    t = t.replace(/```[a-zA-Z0-9+#-]*\n?([\s\S]*?)```/g, (m, code) => `<pre class="codeblock"><code>${code.replace(/\n+$/, '')}</code></pre>`);
    t = t.replace(/`([^`\n]+)`/g, '<code>$1</code>');
    t = t.replace(/\*\*([^*\n]+)\*\*/g, '<strong>$1</strong>');
    t = t.replace(/^#{1,6}\s+(.+)$/gm, '<strong>$1</strong>');
    return t;
}
function formatTraceDuration(ms) {
    const total = Math.max(0, Math.round(Number(ms || 0) / 1000));
    if (total < 60) return `${total} 秒`;
    const m = Math.floor(total / 60);
    const s = total % 60;
    return s ? `${m} 分 ${s} 秒` : `${m} 分`;
}
function traceSummaryText(trace) {
    if (!trace) return '';
    const label = trace.ok === false ? '任务失败' : '任务耗时';
    return `${label} ${formatTraceDuration(trace.durationMs)}${trace.toolCount ? ` · 调用 ${trace.toolCount} 个工具` : ''}`;
}
// 聊天区实时状态气泡：逐条显示当前步骤，结束后折叠成一行耗时摘要
function startLiveTrace() {
    const root = document.createElement('div');
    root.className = 'msg ai trace-msg';
    root.innerHTML = `
        <div class="meta"><span>古灵</span><span class="trace-timer">0 秒</span></div>
        <details class="trace think" style="display:none"><summary>思考过程</summary><div class="think-body"></div></details>
        <details class="trace live" open><summary><span class="trace-title">准备中…</span></summary><div class="trace-steps"></div></details>
        <div class="md-body" style="display:none"></div>`;
    $('#chatList').appendChild(root);
    const stepsEl = root.querySelector('.trace-steps');
    const thinkDetails = root.querySelector('.trace.think');
    const thinkBody = root.querySelector('.think-body');
    const traceDetails = root.querySelector('.trace.live');
    const titleEl = root.querySelector('.trace-title');
    const timerEl = root.querySelector('.trace-timer');
    const bodyEl = root.querySelector('.md-body');
    const startedAt = Date.now();
    const trace = {
        startedAt,
        steps: [],
        thought: '',
        toolCount: 0,
        currentEl: null,
        timer: null,
        scroll() {
            const list = $('#chatList');
            if (list && root.isConnected) list.scrollTop = list.scrollHeight;
        },
        setText(text) {
            if (!String(text || '').trim()) return;
            bodyEl.style.display = 'block';
            bodyEl.innerHTML = mdToHtml(displayText(text)) + '<span style="color:var(--muted)">▌</span>';
            this.scroll();
        },
        setThought(text) {
            const value = String(text || '').trim();
            if (!value) return;
            this.thought = value;
            thinkDetails.style.display = 'block';
            thinkBody.textContent = value;
            thinkBody.scrollTop = thinkBody.scrollHeight;
            this.scroll();
        },
        step(text) {
            const value = String(text || '').trim();
            if (!value) return;
            if (this.steps[this.steps.length - 1] === value) return;
            this.steps.push(value);
            if (this.currentEl) {
                this.currentEl.classList.remove('live');
                this.currentEl.classList.add('done');
                this.currentEl.querySelector('.dot').textContent = '✓';
            }
            const row = document.createElement('div');
            row.className = 'trace-step live';
            row.innerHTML = '<span class="dot">●</span><span class="txt"></span>';
            row.querySelector('.txt').textContent = value;
            stepsEl.appendChild(row);
            this.currentEl = row;
            titleEl.textContent = value;
            stepsEl.scrollTop = stepsEl.scrollHeight;
            this.scroll();
        },
        tool(name, ok) {
            this.toolCount++;
            this.step(ok === false ? `调用工具 ${name}：失败` : `调用工具 ${name}`);
        },
        finish(ok) {
            clearInterval(this.timer);
            if (this.currentEl) {
                this.currentEl.classList.remove('live');
                this.currentEl.classList.add('done');
                this.currentEl.querySelector('.dot').textContent = ok === false ? '✕' : '✓';
            }
            const durationMs = Date.now() - this.startedAt;
            traceDetails.classList.remove('live');
            traceDetails.open = false;
            titleEl.textContent = traceSummaryText({ durationMs, toolCount: this.toolCount });
            timerEl.textContent = ok === false ? '失败' : '完成';
            const cursor = bodyEl.querySelector('span');
            if (cursor && cursor.textContent === '▌') cursor.remove();
            return { durationMs, steps: this.steps.slice(-40), thought: this.thought.slice(0, 2000), toolCount: this.toolCount, ok: ok !== false };
        }
    };
    trace.step('正在连接模型…');
    trace.timer = setInterval(() => {
        timerEl.textContent = formatTraceDuration(Date.now() - startedAt);
    }, 1000);
    return trace;
}
function toast(t, type='') { const e = $('#toast'); e.textContent = t; e.className = 'toast show ' + type; clearTimeout(toast.t); toast.t = setTimeout(() => e.className = 'toast', 2600); }
function setInputIfNotFocused(selector, value) {
    const el = $(selector);
    if (!el) return;
    if (document.activeElement === el) return;
    el.value = value;
}
async function verifyMaster() {
    if (verified) return true;
    const modal = $('#masterAuthModal');
    const input = $('#masterPassInput');
    const okBtn = $('#masterPassOk');
    const cancelBtn = $('#masterPassCancel');
    const closeBtn = $('#masterPassClose');
    if (!modal || !input || !okBtn || !cancelBtn || !closeBtn) {
        toast('身份验证窗口初始化失败', 'bad');
        return false;
    }
    return new Promise(resolve => {
        let settled = false;
        const cleanup = () => {
            okBtn.removeEventListener('click', submit);
            cancelBtn.removeEventListener('click', cancel);
            closeBtn.removeEventListener('click', cancel);
            input.removeEventListener('keydown', onKeydown);
            modal.removeEventListener('click', onBackdropClick);
        };
        const finish = value => {
            if (settled) return;
            settled = true;
            cleanup();
            modal.style.display = 'none';
            resolve(value);
        };
        const submit = () => {
            if (input.value === MASTER_PASSWORD) {
                verified = true;
                toast('✅ 身份验证通过', 'ok');
                finish(true);
            } else {
                toast('❌ 验证失败，请重试', 'bad');
                input.value = '';
                input.focus();
            }
        };
        const cancel = () => finish(false);
        const onKeydown = e => {
            if (e.key === 'Enter') { e.preventDefault(); submit(); }
            if (e.key === 'Escape') { e.preventDefault(); cancel(); }
        };
        const onBackdropClick = e => { if (e.target === modal) cancel(); };
        input.value = '';
        modal.style.display = 'flex';
        okBtn.addEventListener('click', submit);
        cancelBtn.addEventListener('click', cancel);
        closeBtn.addEventListener('click', cancel);
        input.addEventListener('keydown', onKeydown);
        modal.addEventListener('click', onBackdropClick);
        input.focus();
    });
}

// ================= 工具执行器 =================
function parseToolCalls(text) {
    const calls = [];
    const re = /\[\[TOOL:([^\s{\[]+?)(\{[\s\S]*?\})\]\]/g;
    let m;
    while ((m = re.exec(text)) !== null) {
        try {
            const args = JSON.parse(m[2]);
            calls.push({ name: m[1].trim(), args, raw: m[0] });
        } catch(_) {
            calls.push({ name: m[1].trim(), args: {}, raw: m[0], parseError: true });
        }
    }
    return calls;
}
function isPublicFetchUrl(raw) {
    try {
        const url = new URL(raw);
        if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password) return false;
        const host = url.hostname.toLowerCase().replace(/^\[|\]$/g, '');
        if (!host || host === 'localhost' || host.endsWith('.localhost') || host.endsWith('.local') || host.endsWith('.internal')) return false;
        if (host.includes(':')) {
            if (host === '::1' || host === '::' || host.startsWith('fc') || host.startsWith('fd') || host.startsWith('fe80:')) return false;
        } else if (/^\d{1,3}(?:\.\d{1,3}){3}$/.test(host)) {
            const parts = host.split('.').map(Number);
            if (parts.some(n => n < 0 || n > 255)) return false;
            const [a, b] = parts;
            if (a === 0 || a === 10 || a === 127 || a >= 224 ||
                (a === 169 && b === 254) ||
                (a === 172 && b >= 16 && b <= 31) ||
                (a === 192 && b === 168) ||
                (a === 100 && b >= 64 && b <= 127)) return false;
        }
        return true;
    } catch (_) {
        return false;
    }
}
async function runSandboxCode(code) {
    const source = String(code || '').trim();
    if (!source) throw new Error('缺少 JavaScript 代码');
    if (source.length > 12000) throw new Error('代码超过 12000 字符上限');
    const frame = document.createElement('iframe');
    frame.setAttribute('sandbox', 'allow-scripts');
    frame.setAttribute('aria-hidden', 'true');
    frame.style.cssText = 'display:none;width:0;height:0;border:0';
    const id = `sandbox-${Date.now()}-${++toolTaskSequence}`;
    const frameHtml = `<!doctype html><meta charset="utf-8">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline' 'unsafe-eval' blob:; worker-src blob:; connect-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'; img-src data:">
<script>
const workerSource = \`
self.onmessage = function (event) {
  const send = self.postMessage.bind(self);
  self.postMessage = function () {};
  for (const name of ['fetch','XMLHttpRequest','WebSocket','EventSource','Worker','SharedWorker','importScripts','RTCPeerConnection','WebTransport']) {
    try { Object.defineProperty(self, name, { value: undefined, writable: false, configurable: false }); } catch (_) {}
  }
  const id = event.data.id;
  try {
    const code = String(event.data.code || '');
    let value;
    try { value = new Function('"use strict"; return (' + code + ');')(); }
    catch (_) { value = new Function('"use strict";\\\\n' + code)(); }
    let output;
    if (typeof value === 'string') output = value;
    else {
      try { output = JSON.stringify(value); } catch (_) { output = String(value); }
      if (output === undefined) output = String(value);
    }
    send({ id: id, ok: true, value: String(output).slice(0, 6000) });
  } catch (error) {
    send({ id: id, ok: false, error: String(error && error.message || error).slice(0, 1000) });
  }
};
\`;
window.addEventListener('message', function (event) {
  if (event.source !== parent || !event.data || event.data.channel !== 'omni-sandbox-run') return;
  const runId = event.data.id;
  let worker;
  let url;
  let finished = false;
  const done = function (result) {
    if (finished) return;
    finished = true;
    if (worker) worker.terminate();
    if (url) URL.revokeObjectURL(url);
    parent.postMessage({ channel: 'omni-sandbox-result', id: runId, result: result }, '*');
  };
  try {
    url = URL.createObjectURL(new Blob([workerSource], { type: 'text/javascript' }));
    worker = new Worker(url);
    worker.onmessage = function (message) {
      if (message.data && message.data.id === runId) done(message.data);
    };
    worker.onerror = function (error) { done({ ok: false, error: String(error.message || '沙箱运行错误') }); };
    setTimeout(function () { done({ ok: false, error: '沙箱执行超时，已终止代码' }); }, 4000);
    worker.postMessage({ id: runId, code: event.data.code });
  } catch (error) {
    done({ ok: false, error: String(error && error.message || error) });
  }
});
<\/script>`;
    return new Promise((resolve, reject) => {
        let finished = false;
        const cleanup = () => {
            window.removeEventListener('message', onMessage);
            clearTimeout(timeout);
            frame.remove();
        };
        const onMessage = event => {
            if (event.source !== frame.contentWindow || event.data?.channel !== 'omni-sandbox-result' || event.data?.id !== id) return;
            finished = true;
            cleanup();
            if (event.data.result?.ok) resolve(event.data.result.value || '');
            else reject(new Error(event.data.result?.error || '沙箱执行失败'));
        };
        const timeout = setTimeout(() => {
            if (finished) return;
            finished = true;
            cleanup();
            reject(new Error('沙箱超时，未返回结果'));
        }, 7000);
        window.addEventListener('message', onMessage);
        frame.onload = () => {
            frame.contentWindow.postMessage({ channel: 'omni-sandbox-run', id, code: source }, '*');
        };
        document.body.appendChild(frame);
        frame.srcdoc = frameHtml;
    });
}
// ================= MCP 工具接入 =================
const MCP_TIMEOUT_MS = 20000;
const MCP_MAX_SERVERS = 10;
const MCP_MAX_TOOLS = 100;

function isValidMcpUrl(url) {
    try {
        const parsed = new URL(String(url || '').trim());
        return (parsed.protocol === 'https:' || parsed.protocol === 'http:') && !parsed.username && !parsed.password;
    } catch (_) { return false; }
}
function mcpServers() {
    return (state?.cfg?.mcpServers || []).filter(server => server && server.url && isValidMcpUrl(server.url));
}
function mcpCacheFor(id) {
    const key = String(id || 'default');
    if (!mcpCache[key]) mcpCache[key] = { sessionId: '', tools: [], status: 'idle', error: '', updatedAt: 0 };
    return mcpCache[key];
}
function mcpAliasPart(value, fallback) {
    const text = String(value || '').replace(/[^A-Za-z0-9_.-]/g, '_').slice(0, 40);
    return text || fallback;
}
function mcpToolAlias(server, tool) {
    return `mcp__${mcpAliasPart(server.id, 'server')}__${mcpAliasPart(tool.name, 'tool')}`;
}
function findMcpToolByAlias(alias) {
    for (const server of mcpServers()) {
        if (!server.enabled) continue;
        const cache = mcpCache[server.id];
        if (!cache || !Array.isArray(cache.tools)) continue;
        const tool = cache.tools.find(item => mcpToolAlias(server, item) === alias);
        if (tool) return { server, tool };
    }
    return null;
}
function isApprovableTool(name) {
    return APPROVABLE_TOOLS.has(name) || !!findMcpToolByAlias(name);
}
function mcpSchemaHint(schema) {
    const props = schema?.properties || {};
    const required = new Set(Array.isArray(schema?.required) ? schema.required : []);
    return Object.keys(props).slice(0, 8).map(key => {
        const type = props[key]?.type || 'any';
        return `${key}${required.has(key) ? '*' : ''}:${type}`;
    }).join(', ');
}
function mcpToolsPrompt() {
    const lines = [];
    let serverCount = 0;
    for (const server of mcpServers()) {
        if (!server.enabled) continue;
        const cache = mcpCache[server.id];
        if (!cache || cache.status !== 'ready' || !cache.tools.length) continue;
        serverCount++;
        for (const tool of cache.tools.slice(0, 30)) {
            if (lines.length >= 50) break;
            const desc = String(tool.description || '').replace(/\s+/g, ' ').slice(0, 160);
            const hint = mcpSchemaHint(tool.inputSchema);
            lines.push(`- ${mcpToolAlias(server, tool)}：${desc || '（无描述）'}${hint ? `；参数：${hint}` : ''}`);
        }
    }
    if (!lines.length) return '';
    return `\n【MCP 外部工具（已连接 ${serverCount} 个服务器）】以下工具来自创造者配置的 MCP 服务器，调用格式 [[TOOL:别名{参数JSON}]]：\n${lines.join('\n')}\n只能调用上面列出的别名；MCP 调用同样逐项审批，未经允许不得执行。`;
}
function parseMcpSseBlock(block) {
    const data = block.split('\n')
        .filter(line => line.startsWith('data:'))
        .map(line => line.slice(5).trimStart())
        .join('\n')
        .trim();
    if (!data || data === '[DONE]') return null;
    try { return JSON.parse(data); } catch (_) { return null; }
}
async function readMcpSse(res, expectedId) {
    if (!res.body || typeof res.body.getReader !== 'function') {
        const text = await res.text();
        for (const block of text.replace(/\r\n/g, '\n').split('\n\n')) {
            const message = parseMcpSseBlock(block);
            if (message && (message.id === expectedId || message.result !== undefined || message.error !== undefined)) return message;
        }
        return null;
    }
    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        buffer = buffer.replace(/\r\n/g, '\n');
        let index;
        while ((index = buffer.indexOf('\n\n')) >= 0) {
            const block = buffer.slice(0, index);
            buffer = buffer.slice(index + 2);
            const message = parseMcpSseBlock(block);
            if (message && (message.id === expectedId || message.result !== undefined || message.error !== undefined)) {
                try { await reader.cancel(); } catch (_) {}
                return message;
            }
        }
    }
    return parseMcpSseBlock(buffer);
}
async function mcpPost(server, payload) {
    const cache = mcpCacheFor(server.id);
    const headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json, text/event-stream',
        'MCP-Protocol-Version': '2025-06-18'
    };
    if (server.token) headers.Authorization = `Bearer ${server.token}`;
    if (cache.sessionId) headers['Mcp-Session-Id'] = cache.sessionId;
    const res = await fetchT(server.url, { method: 'POST', headers, body: JSON.stringify(payload) }, MCP_TIMEOUT_MS);
    try {
        const sid = res.headers.get('mcp-session-id');
        if (sid) cache.sessionId = sid;
    } catch (_) {}
    const contentType = String(res.headers.get('content-type') || '').toLowerCase();
    let json = null;
    let raw = '';
    if (contentType.includes('text/event-stream')) {
        json = await readMcpSse(res, payload.id);
    } else {
        raw = await res.text();
        if (raw.trim()) {
            try { json = JSON.parse(raw); } catch (_) {
                if (res.ok) throw new Error('MCP 返回了非 JSON 内容');
            }
        }
    }
    if (!res.ok) {
        const detail = json?.error?.message || raw.slice(0, 200);
        throw new Error(`MCP HTTP ${res.status}${detail ? `：${detail}` : ''}`);
    }
    if (payload.id && !json) throw new Error('MCP 未返回响应内容');
    return json;
}
async function mcpRpc(server, method, params, notification = false) {
    const payload = { jsonrpc: '2.0', method };
    if (!notification) payload.id = ++mcpRequestSeq;
    if (params !== undefined) payload.params = params;
    const json = await mcpPost(server, payload);
    if (json?.error) throw new Error(json.error.message || JSON.stringify(json.error));
    return json?.result;
}
async function ensureMcpConnected(server, force = false) {
    const cache = mcpCacheFor(server.id);
    if (!force && cache.status === 'ready') return cache;
    cache.status = 'connecting';
    cache.error = '';
    cache.sessionId = '';
    try {
        await mcpRpc(server, 'initialize', {
            protocolVersion: '2025-06-18',
            capabilities: {},
            clientInfo: { name: 'guling-omni', version: VERSION }
        });
        await mcpRpc(server, 'notifications/initialized', {}, true);
        const listed = await mcpRpc(server, 'tools/list', {});
        cache.tools = (Array.isArray(listed?.tools) ? listed.tools : [])
            .filter(tool => tool && tool.name)
            .slice(0, MCP_MAX_TOOLS);
        cache.status = 'ready';
        cache.updatedAt = Date.now();
        return cache;
    } catch (error) {
        cache.status = 'error';
        cache.error = error.message;
        cache.tools = [];
        throw error;
    } finally {
        renderMcpServers();
    }
}
function formatMcpResult(result) {
    if (!result) return 'MCP 工具没有返回内容。';
    const parts = (Array.isArray(result.content) ? result.content : []).map(item => {
        if (!item || typeof item !== 'object') return '';
        if (item.type === 'text') return String(item.text || '');
        return `[${item.type || '未知'} 类型内容已省略]`;
    }).filter(Boolean);
    let text = parts.join('\n').trim();
    if (result.structuredContent) {
        try { text += `${text ? '\n\n' : ''}结构化结果：${JSON.stringify(result.structuredContent).slice(0, 3000)}`; } catch (_) {}
    }
    if (result.isError) return `MCP 工具返回错误：\n${text || '未提供错误详情'}`;
    return text.slice(0, 12000) + (text.length > 12000 ? '\n\n[已截断至 12000 字符]' : '') || 'MCP 工具已执行，但没有文本输出。';
}
async function callMcpTool(alias, args) {
    const found = findMcpToolByAlias(alias);
    if (!found) throw new Error('MCP 工具未找到，请在连接页刷新工具列表');
    await ensureMcpConnected(found.server);
    let result;
    try {
        result = await mcpRpc(found.server, 'tools/call', { name: found.tool.name, arguments: args && typeof args === 'object' ? args : {} });
    } catch (error) {
        if (!/session|会话/i.test(error.message)) throw error;
        await ensureMcpConnected(found.server, true);
        result = await mcpRpc(found.server, 'tools/call', { name: found.tool.name, arguments: args && typeof args === 'object' ? args : {} });
    }
    return formatMcpResult(result);
}
function mcpStatusText(server) {
    if (!server.enabled) return '已停用';
    const cache = mcpCache[server.id];
    if (!cache || cache.status === 'idle') return '未连接';
    if (cache.status === 'connecting') return '连接中…';
    if (cache.status === 'error') return `错误：${String(cache.error || '').slice(0, 140)}`;
    return `已连接 · ${cache.tools.length} 个工具`;
}
function renderMcpServers() {
    const list = $('#mcpServerList');
    if (!list) return;
    const servers = Array.isArray(state?.cfg?.mcpServers) ? state.cfg.mcpServers : [];
    if (!servers.length) {
        list.innerHTML = '<div class="tool-task-note">尚未添加 MCP 服务器。添加后可让古灵调用外部工具。</div>';
    } else {
        list.innerHTML = servers.map(server => `<div class="mcp-item">
            <div class="mcp-item-head"><b>${esc(server.name)}</b><span class="small">${esc(mcpStatusText(server))}</span></div>
            <div class="small" style="word-break:break-all">${esc(server.url)}</div>
            <div class="tool-task-actions">
                <button class="btn secondary" data-mcp-action="refresh" data-mcp-id="${esc(server.id)}">刷新工具</button>
                <button class="btn secondary" data-mcp-action="toggle" data-mcp-id="${esc(server.id)}">${server.enabled ? '停用' : '启用'}</button>
                <button class="btn danger" data-mcp-action="delete" data-mcp-id="${esc(server.id)}">删除</button>
            </div>
        </div>`).join('');
    }
    const status = $('#mcpStatus');
    if (status) {
        const connected = servers.filter(server => server.enabled && mcpCache[server.id]?.status === 'ready');
        const tools = connected.reduce((sum, server) => sum + (mcpCache[server.id]?.tools?.length || 0), 0);
        status.textContent = servers.length
            ? `已启用 ${servers.filter(server => server.enabled).length} 个服务器，已连接 ${connected.length} 个，共发现 ${tools} 个工具。`
            : '未配置 MCP 服务器。';
    }
}
async function refreshMcpServer(server, showToast = false) {
    try {
        const cache = await ensureMcpConnected(server, true);
        if (showToast) toast(`MCP「${server.name}」已连接，发现 ${cache.tools.length} 个工具`, 'ok');
    } catch (error) {
        if (showToast) toast(`MCP「${server.name}」连接失败：${error.message}`, 'bad');
    }
}
async function refreshAllMcpServers(showToast = false) {
    const list = mcpServers().filter(server => server.enabled);
    if (!list.length) {
        if (showToast) toast('尚未启用 MCP 服务器', 'bad');
        return;
    }
    await Promise.all(list.map(server => refreshMcpServer(server, false)));
    const connected = list.filter(server => mcpCache[server.id]?.status === 'ready');
    if (showToast) toast(`MCP 已连接 ${connected.length}/${list.length} 个服务器`, connected.length ? 'ok' : 'bad');
    renderMcpServers();
}
async function addMcpServerFromForm() {
    const name = $('#mcpName').value.trim();
    const url = $('#mcpUrl').value.trim();
    const token = $('#mcpToken').value.trim();
    if (!name) { toast('请填写 MCP 服务器名称', 'bad'); return; }
    if (!isValidMcpUrl(url)) { toast('请填写有效的 http/https MCP 地址', 'bad'); return; }
    if (!Array.isArray(state.cfg.mcpServers)) state.cfg.mcpServers = [];
    if (state.cfg.mcpServers.length >= MCP_MAX_SERVERS) { toast(`最多添加 ${MCP_MAX_SERVERS} 个 MCP 服务器`, 'bad'); return; }
    if (state.cfg.mcpServers.some(server => server.url === url)) { toast('该 MCP 地址已存在', 'bad'); return; }
    const server = {
        id: `mcp${Date.now().toString(36)}`,
        name: name.slice(0, 40),
        url,
        token,
        enabled: true
    };
    state.cfg.mcpServers.push(server);
    saveState();
    $('#mcpName').value = ''; $('#mcpUrl').value = ''; $('#mcpToken').value = '';
    renderMcpServers();
    await refreshMcpServer(server, true);
}
function handleMcpListClick(event) {
    const button = event.target.closest('[data-mcp-action]');
    if (!button) return;
    const server = (state.cfg.mcpServers || []).find(item => item.id === button.dataset.mcpId);
    if (!server) return;
    if (button.dataset.mcpAction === 'refresh') refreshMcpServer(server, true);
    if (button.dataset.mcpAction === 'toggle') {
        server.enabled = !server.enabled;
        saveState(); renderMcpServers();
        if (server.enabled) refreshMcpServer(server, false);
    }
    if (button.dataset.mcpAction === 'delete') {
        if (!confirm(`删除 MCP 服务器「${server.name}」？`)) return;
        state.cfg.mcpServers = state.cfg.mcpServers.filter(item => item.id !== server.id);
        delete mcpCache[server.id];
        saveState(); renderMcpServers();
    }
}

async function executeTool(name, args) {
    switch (name) {
        case 'memory_search': {
            const q = args.query || args.q || '';
            if (!q) return '缺少 query 参数';
            return recallMemoryByQuery(q);
        }
        case 'project_list':
            return projectManifestText();
        case 'project_read':
            return readProjectFileContent(args.path || args.file || '');
        case 'project_search':
            return searchProjectText(args.query || args.q || '');
        case 'web_search': {
            const q = args.query || args.q || '';
            if (!q) return '缺少 query 参数';
            const results = await webSearch(q, 5, false);
            return results.map((r, i) =>
                `[${i+1}] ${r.title}\nURL: ${r.url}\n摘要: ${(r.snippet || '').slice(0, 300)}`
            ).join('\n\n');
        }
        case 'web_fetch': {
            const url = args.url || '';
            if (!url) return '缺少 url 参数';
            if (!isPublicFetchUrl(url)) return '只允许访问公开 HTTP/HTTPS 地址；本地、内网和带账号信息的地址已拦截';
            const r = await fetchT(url, {}, 15000);
            if (!r.ok) return `HTTP ${r.status}`;
            const t = await r.text();
            return t.slice(0, 6000) + (t.length > 6000 ? '\n\n[已截断至 6000 字符]' : '');
        }
        case 'calc': {
            const expr = args.expr || args.expression || '';
            if (!expr) return '缺少 expr 参数';
            if (!/^[\d\s+\-*/().%eE]+$/.test(expr)) return 'calc 仅支持纯数学表达式（禁止字母与变量名）';
            try {
                const result = Function('"use strict";return (' + expr + ')')();
                return String(result);
            } catch(e) { return '计算错误：' + e.message; }
        }
        case 'code_run_js':
            return runSandboxCode(args.code || args.source || '');
        case 'screen_read':
        case 'screen_tap':
            throw new Error('屏幕操作只能经待审批队列和 Android 系统通知确认后运行');
        case 'termux_exec':
            throw new Error('Termux 命令只能经待审批队列批准后通过 Android 原生桥接运行');
        case 'shell_exec':
            throw new Error('Shell 命令只能经待审批队列批准后通过系统 shell 运行');
        case 'browser_open':
        case 'browser_click':
        case 'browser_input':
        case 'browser_read':
        case 'browser_eval':
        case 'browser_close':
            throw new Error('浏览器自动化只能经待审批队列批准后运行');
        default:
            if (String(name).startsWith('mcp__')) return await callMcpTool(name, args);
            throw new Error('未知工具：' + name);
    }
}
async function runWithTools(provider, model, history, key, initialReply, opts = {}) {
    let text = initialReply;
    const maxIterations = 12;
    let iterations = 0;
    while (iterations < maxIterations) {
        const calls = parseToolCalls(text);
        if (!calls.length) break;
        if (liveTrace) liveTrace.step(`模型请求 ${calls.length} 个工具，等待你审批…`);
        const resultPromises = calls.map(call => {
            if (call.parseError) {
                return Promise.resolve(`[${call.name}] ❌ 参数 JSON 解析失败：${call.raw}`);
            }
            return enqueueToolTask(call.name, call.args, '模型调用').then(outcome => {
                if (liveTrace) liveTrace.tool(call.name, outcome.ok);
                return outcome.ok
                    ? `[${call.name}] ✅ 结果：\n${outcome.result}`
                    : `[${call.name}] ❌ ${outcome.result || '创造者拒绝执行'}`;
            });
        });
        const results = await Promise.all(resultPromises);
        history.push({ role: 'model', parts: [{ text }] });
        history.push({ role: 'user', parts: [{ text:
            `工具执行结果：\n\n${results.join('\n\n')}\n\n请基于以上工具结果继续回答。不要再重复调用已成功的工具。`
        }] });
        try {
            if (liveTrace) liveTrace.step('正在整理工具结果…');
            const next = await generateWithRetry(provider, model, history, key, opts, provider === 'gemini');
            if (!String(next?.text || '').trim()) throw new Error('工具执行后模型返回空内容；为避免重复计费，没有自动重试。');
            if (next.reasoning && liveTrace) liveTrace.setThought(next.reasoning);
            if (next.grounded && liveTrace) liveTrace.step('已联网补充实时信息');
            recordUsage(model, next.inputTokens, next.outputTokens);
            text = next.text;
        } catch(e) {
            text += `\n\n[⚠️ 工具执行后模型响应失败：${e.message}]`;
            if (liveTrace) liveTrace.step(`整理结果失败：${String(e.message).slice(0, 60)}`);
            break;
        }
        iterations++;
    }
    if (iterations >= maxIterations) {
        text += `\n\n[⚠️ 已达工具调用上限 ${maxIterations} 次，已停止]`;
    }
    return text;
}
async function runWithLocalTools(engine, base, model, messages, initialReply) {
    let text = initialReply;
    const maxIterations = 12;
    let iterations = 0;
    while (iterations < maxIterations) {
        const calls = parseToolCalls(text);
        if (!calls.length) break;
        if (liveTrace) liveTrace.step(`本地模型请求 ${calls.length} 个工具，等待你审批…`);
        const resultPromises = calls.map(call => {
            if (call.parseError) return Promise.resolve(`[${call.name}] ❌ 参数 JSON 解析失败：${call.raw}`);
            return enqueueToolTask(call.name, call.args, '本地模型调用').then(outcome => {
                if (liveTrace) liveTrace.tool(call.name, outcome.ok);
                return outcome.ok
                    ? `[${call.name}] ✅ 结果：\n${outcome.result}`
                    : `[${call.name}] ❌ ${outcome.result || '创造者拒绝执行'}`;
            });
        });
        const results = await Promise.all(resultPromises);
        messages.push({ role: 'assistant', content: text });
        messages.push({
            role: 'user',
            content: `工具执行结果：\n\n${results.join('\n\n')}\n\n请基于结果继续回答。不要重复调用已完成的工具。`
        });
        if (engine === 'ollama') {
            const data = await readJsonResponse(await fetchT(`${base}/api/chat`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    model: model || 'llama3.2',
                    messages,
                    stream: false,
                    options: { temperature: state.cfg.temperature, num_predict: state.cfg.maxTokens }
                })
            }, 180000));
            recordUsage(data.model || model || 'ollama-local', 0, 0);
            text = normalizeProviderText(data.message?.content);
        } else {
            const data = await readJsonResponse(await fetchT(`${base}/v1/chat/completions`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    model: model || undefined,
                    messages,
                    temperature: state.cfg.temperature,
                    max_tokens: state.cfg.maxTokens,
                    stream: false
                })
            }, 180000));
            recordUsage(data.model || model || 'lmstudio-local', data.usage?.prompt_tokens || 0, data.usage?.completion_tokens || 0);
            text = normalizeProviderText(data.choices?.[0]?.message?.content, data.choices?.[0]?.message?.reasoning_content);
        }
        if (!String(text || '').trim()) throw new Error('本地模型在工具结果后返回空内容');
        iterations++;
    }
    if (iterations >= maxIterations) text += `\n\n[⚠️ 已达工具调用上限 ${maxIterations} 次，已停止]`;
    return text;
}
function aiMode() { return state.cfg.aiMode || 'remote'; }
function isLocalMode() { return aiMode() === 'local'; }
function getBackendUrl() {
    const fallback = state?.cfg?.localEngine === 'lmstudio' ? 'http://127.0.0.1:1234' : 'http://127.0.0.1:11434';
    return String($('#backendUrl')?.value || state?.cfg?.backendUrl || fallback).trim().replace(/\/$/, '');
}
function getLocalEngine() { return $('#localEngine')?.value || state?.cfg?.localEngine || 'ollama'; }
async function checkBackend() {
    const out = $('#connectionStatus');
    try {
        state.cfg.localEngine = getLocalEngine();
        state.cfg.backendUrl = getBackendUrl();
        const models = await fetchLocalModels();
        state.cfg.models = models;
        if (!models.some(m => m.name === state.cfg.model)) state.cfg.model = models[0]?.name || 'auto';
        saveState(); initModelSearch();
        out.textContent = `本地模型服务已连接；发现 ${models.length} 个模型，正在检测连通性…`;
        $('#modelInfo').textContent = `已读取 ${models.length} 个本地模型，正在自动检测连通性…`;
        await probeModels(models, true);
        initModelSearch();
        out.textContent = `本地模型服务已连接；发现 ${models.length} 个模型。`;
        toast('本地模型服务连接成功', 'ok');
    } catch (e) { out.textContent = '本地服务连接失败：' + e.message + '。请确认服务已启动、模型已下载/加载，并检查 CORS 设置。'; toast('本地服务连接失败', 'bad'); }
}
async function fetchLocalModels() {
    const base = getBackendUrl();
    if (getLocalEngine() === 'lmstudio') {
        const data = await readJsonResponse(await fetchT(`${base}/v1/models`, {}, 10000));
        return (Array.isArray(data.data) ? data.data : []).map(m => ({ name: m.id, display: m.id }));
    }
    const data = await readJsonResponse(await fetchT(`${base}/api/tags`, {}, 10000));
    return (Array.isArray(data.models) ? data.models : []).map(m => ({ name: m.name, display: m.name, size: m.size }));
}
async function readJsonResponse(response) { let data={}; try{data=await response.json();}catch(_){} if(!response.ok)throw new Error(data.error||`HTTP ${response.status}`); if(data.error)throw new Error(data.error); return data; }
function modelProbeProviderKey() { return isLocalMode() ? 'local' : (state.cfg.provider || 'gemini'); }
function readModelProbeCache() {
    try {
        const parsed = JSON.parse(localStorage.getItem(MODEL_PROBE_CACHE_KEY) || '{}');
        return parsed && typeof parsed === 'object' ? parsed : {};
    } catch (_) { return {}; }
}
function getModelProbeStatus(model) {
    const entry = readModelProbeCache()?.[modelProbeProviderKey()]?.[model];
    return entry && entry.status ? entry.status : 'unknown';
}
function writeModelProbeResult(providerKey, model, status) {
    try {
        const cache = readModelProbeCache();
        const bucket = cache[providerKey] && typeof cache[providerKey] === 'object' ? cache[providerKey] : {};
        bucket[model] = { status, at: Date.now() };
        const keys = Object.keys(bucket);
        if (keys.length > 600) {
            keys.sort((a, b) => (bucket[a].at || 0) - (bucket[b].at || 0));
            keys.slice(0, keys.length - 600).forEach(key => { delete bucket[key]; });
        }
        cache[providerKey] = bucket;
        localStorage.setItem(MODEL_PROBE_CACHE_KEY, JSON.stringify(cache));
    } catch (e) { console.warn('模型连通性缓存写入失败', e); }
}
// 已获取的模型列表按提供商持久化：每个提供商只需成功拉取一次，之后直接复用，不再重复请求。
function modelListCacheKey(provider) {
    const p = provider || state.cfg.provider;
    if (isLocalMode()) return `local:${state.cfg.localEngine || 'ollama'}:${String(state.cfg.backendUrl || '').replace(/\/$/, '')}`;
    return `remote:${p}`;
}
function readModelListCache() {
    try {
        const parsed = JSON.parse(localStorage.getItem(MODEL_LIST_CACHE_KEY) || '{}');
        return parsed && typeof parsed === 'object' ? parsed : {};
    } catch (_) { return {}; }
}
function saveModelListCache(models, provider) {
    try {
        if (!Array.isArray(models) || !models.length) return;
        const cache = readModelListCache();
        cache[modelListCacheKey(provider)] = { models, at: Date.now() };
        localStorage.setItem(MODEL_LIST_CACHE_KEY, JSON.stringify(cache));
    } catch (e) { console.warn('模型列表缓存写入失败', e); }
}
function loadModelListCache(provider) {
    const entry = readModelListCache()[modelListCacheKey(provider)];
    return entry && Array.isArray(entry.models) && entry.models.length ? entry : null;
}
function formatCacheTime(ts) {
    if (!ts) return '未知时间';
    const d = new Date(ts);
    const pad = n => String(n).padStart(2, '0');
    return `${d.getMonth() + 1}月${d.getDate()}日 ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
// 首次进入或切换到已有缓存的提供商时，直接用缓存填充，不发起网络请求。
function hydrateCachedModelList() {
    if (state.cfg.models && state.cfg.models.length) { updateModelListButtonLabel(true); return true; }
    const cached = loadModelListCache(state.cfg.provider);
    if (!cached) { updateModelListButtonLabel(false); return false; }
    state.cfg.models = cached.models;
    if (!cached.models.some(item => item.name === state.cfg.model)) state.cfg.model = cached.models[0].name;
    const source = isLocalMode() ? '本地' : (PROVIDERS[state.cfg.provider]?.name || state.cfg.provider);
    const counts = summarizeModelProbe(cached.models);
    $('#modelInfo').textContent = `已加载缓存的 ${cached.models.length} 个 ${source} 模型（${formatCacheTime(cached.at)} 获取）：可用 ${counts.ok} · 限流 ${counts.rate} · 不可用 ${counts.fail}。直接选择即可，无需再刷新。`;
    updateModelListButtonLabel(true);
    return true;
}
function updateModelListButtonLabel(hasCache) {
    const btn = $('#refreshModels');
    if (!btn) return;
    btn.textContent = hasCache ? '🔄 重新拉取模型（覆盖缓存）' : '🔄 刷新模型列表';
}

async function probeSingleModel(providerKey, model) {
    try {
        if (providerKey === 'local') {
            const base = getBackendUrl();
            const isLmStudio = getLocalEngine() === 'lmstudio';
            const response = await fetchT(
                isLmStudio ? `${base}/v1/chat/completions` : `${base}/api/chat`,
                {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(isLmStudio
                        ? { model, messages: [{ role: 'user', content: 'ping' }], max_tokens: 1, temperature: 0, stream: false }
                        : { model, messages: [{ role: 'user', content: 'ping' }], stream: false, options: { num_predict: 1, temperature: 0 } })
                },
                MODEL_PROBE_TIMEOUT_MS
            );
            if (response.status === 429) return 'rate';
            return response.ok ? 'ok' : 'fail';
        }
        const key = getSanitizedApiKey($('#apiKey').value || state.cfg.apiKey);
        if (!key) return 'fail';
        let response;
        if (providerKey === 'gemini') {
            response = await fetchT(
                `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`,
                {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key },
                    body: JSON.stringify({
                        contents: [{ role: 'user', parts: [{ text: 'ping' }] }],
                        generationConfig: { maxOutputTokens: 1, temperature: 0 }
                    })
                },
                MODEL_PROBE_TIMEOUT_MS
            );
        } else {
            const endpoint = {
                deepseek: 'https://api.deepseek.com/chat/completions',
                huggingface: 'https://api-inference.huggingface.co/v1/chat/completions',
                openrouter: 'https://openrouter.ai/api/v1/chat/completions',
                aliyun: 'https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions',
                nvidia: 'https://integrate.api.nvidia.com/v1/chat/completions'
            }[providerKey];
            if (!endpoint) return 'fail';
            response = await fetchT(
                endpoint,
                {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${key}` },
                    body: JSON.stringify({ model, messages: [{ role: 'user', content: 'ping' }], max_tokens: 1, temperature: 0, stream: false })
                },
                MODEL_PROBE_TIMEOUT_MS
            );
        }
        if (response.status === 429) return 'rate';
        return response.ok ? 'ok' : 'fail';
    } catch (_) {
        return 'fail';
    }
}
function summarizeModelProbe(models) {
    const providerKey = modelProbeProviderKey();
    const cache = readModelProbeCache()?.[providerKey] || {};
    let ok = 0, rate = 0, fail = 0, unknown = 0;
    models.forEach(item => {
        const status = cache?.[item.name]?.status || 'unknown';
        if (status === 'ok') ok++;
        else if (status === 'rate') rate++;
        else if (status === 'fail') fail++;
        else unknown++;
    });
    return { ok, rate, fail, unknown };
}
async function probeModels(models, force = false) {
    if (modelProbeRunning || !Array.isArray(models) || !models.length) return;
    const providerKey = modelProbeProviderKey();
    const cached = readModelProbeCache()?.[providerKey] || {};
    const pending = models.filter(item => force || !cached?.[item.name]?.status);
    if (!pending.length) {
        const counts = summarizeModelProbe(models);
        const statusEl = $('#modelProbeStatus');
        if (statusEl) statusEl.textContent = `连通性：可用 ${counts.ok} · 限流 ${counts.rate} · 不可用 ${counts.fail}`;
        return;
    }
    modelProbeRunning = true;
    const total = pending.length;
    let done = 0;
    const statusEl = $('#modelProbeStatus');
    const update = () => { if (statusEl) statusEl.textContent = `正在检测模型连通性 ${done}/${total}…`; };
    update();
    const queue = pending.slice();
    try {
        const workers = Array.from({ length: Math.min(MODEL_PROBE_CONCURRENCY, queue.length) }, async () => {
            while (queue.length) {
                const item = queue.shift();
                if (!item) break;
                const status = await probeSingleModel(providerKey, item.name);
                writeModelProbeResult(providerKey, item.name, status);
                done++;
                update();
            }
        });
        await Promise.all(workers);
    } finally {
        modelProbeRunning = false;
    }
    const counts = summarizeModelProbe(models);
    if (statusEl) statusEl.textContent = `连通性：可用 ${counts.ok} · 限流 ${counts.rate} · 不可用 ${counts.fail}`;
}
async function refreshModels(showToast=true) {
    if (modelProbeRunning) { toast('正在检测模型连通性，请稍候', 'bad'); return; }
    const provider = state.cfg.provider;
    try {
        let models = [];
        if (isLocalMode()) {
            state.cfg.localEngine = getLocalEngine();
            state.cfg.backendUrl = getBackendUrl();
            models = await fetchLocalModels();
        } else {
            const key = getSanitizedApiKey($('#apiKey').value || state.cfg.apiKey);
            if (!key) { toast('网端 AI 需要 API Key 才能刷新模型列表', 'bad'); return; }
            models = await PROVIDERS[provider].listModels(key);
        }
        state.cfg.models = models;
        if (!models.some(item => item.name === state.cfg.model)) state.cfg.model = models.length ? models[0].name : 'auto';
        if (models.length) { saveModelListCache(models, provider); updateModelListButtonLabel(true); }
        saveState(); initModelSearch();
        const source = isLocalMode() ? '本地' : (PROVIDERS[provider]?.name || provider);
        if (!models.length) {
            $('#modelInfo').textContent = `已读取 0 个 ${source} 模型`;
            if (showToast) toast('模型列表为空', 'bad');
            return;
        }
        $('#modelInfo').textContent = `已读取 ${models.length} 个 ${source} 模型，正在自动检测连通性…`;
        if (showToast) toast('模型列表已刷新，正在检测连通性…');
        await probeModels(models, showToast);
        const counts = summarizeModelProbe(models);
        $('#modelInfo').textContent = `已读取 ${models.length} 个 ${source} 模型；可用 ${counts.ok} 个，限流 ${counts.rate} 个，不可用 ${counts.fail} 个。列表已保存，以后直接从列表选择，无需再刷新。`;
        initModelSearch();
        if (showToast) toast(`模型检测完成：可用 ${counts.ok} 个`, counts.ok ? 'ok' : 'bad');
    } catch(e) {
        $('#modelInfo').textContent = '获取模型列表失败：' + e.message;
        if (showToast) toast('获取模型失败：' + e.message, 'bad');
    }
}
function initModelSearch() {
    const input = $('#modelSearchInput');
    const dropdown = $('#modelSearchDropdown');
    if (!input || !dropdown) return;
    const selectedModel = state.cfg.model || 'auto';
    const selModelObj = (state.cfg.models || []).find(m => m.name === selectedModel);
    const displayValue = selModelObj ? selModelObj.name : (selectedModel === 'auto' ? '自动选择' : selectedModel);
    if (document.activeElement !== input) {
        input.value = displayValue;
    }
    input.onfocus = () => { renderModelDropdown(input.value); dropdown.style.display = 'block'; };
    input.oninput = () => { renderModelDropdown(input.value); dropdown.style.display = 'block'; };
    if (!input.dataset.outsideClickBound) {
        document.addEventListener('click', (e) => {
            if (!e.target.closest('#modelSearchInput') && !e.target.closest('#modelSearchDropdown')) dropdown.style.display = 'none';
        });
        input.dataset.outsideClickBound = '1';
    }
    const showAllSwitch = $('#showAllModelsSwitch');
    if (showAllSwitch && !showAllSwitch.dataset.bound) {
        showAllSwitch.onchange = () => {
            renderModelDropdown($('#modelSearchInput').value);
            dropdown.style.display = 'block';
        };
        showAllSwitch.dataset.bound = '1';
    }
}
function renderModelDropdown(keyword) {
    const dropdown = $('#modelSearchDropdown');
    let models = state.cfg.models || [];
    const showAll = !!$('#showAllModelsSwitch')?.checked;
    let lowerKw = (keyword || '').toLowerCase();
    let filtered = lowerKw ? models.filter(m => (m.name || '').toLowerCase().includes(lowerKw) || (m.display || '').toLowerCase().includes(lowerKw)) : models;
    filtered = filtered.filter(m => {
        const status = getModelProbeStatus(m.name);
        return showAll || status === 'ok' || status === 'rate';
    });
    if (filtered.length === 0) {
        const hint = models.length && !showAll ? '没有可用模型；可勾选「显示全部模型」查看全部结果' : '未找到匹配模型';
        dropdown.innerHTML = `<div style="padding:10px;color:var(--muted)">${hint}</div>`;
        return;
    }
    const statusLabel = { ok: '✅', rate: '⏳限流', fail: '✖不可用', unknown: '…' };
    dropdown.innerHTML = filtered.map(m => {
        let isFree = m.free ? ' (免费)' : '';
        const status = getModelProbeStatus(m.name);
        return `<div class="model-option" data-name="${esc(m.name)}" style="padding:8px 10px; cursor:pointer; border-bottom:1px solid var(--line);">${esc(m.display || m.name)}${isFree} <span style="font-size:10px;color:var(--muted)">${statusLabel[status] || ''}</span></div>`;
    }).join('');
    dropdown.querySelectorAll('.model-option').forEach(opt => {
        opt.addEventListener('mousedown', (e) => {
            e.preventDefault();
            const name = opt.dataset.name;
            state.cfg.model = name;
            saveState();
            $('#modelSearchInput').value = name;
            dropdown.style.display = 'none';
            toast('已选择模型: ' + name, 'ok');
        });
    });
}
function getModelList() {
    let all = (state.cfg.models || []).map(m => m.name);
    if (state.cfg.model && state.cfg.model !== 'auto') return [state.cfg.model];
    // 旧版本缓存的模型列表可能含语音/嵌入类模型，这类模型不能做对话，直接排除
    all = all.filter(m => !/(transcribe|embedding|tts|audio|image|veo|lyria)/i.test(m));
    all = all.filter(m => score(m) > 0 && getModelProbeStatus(m) !== 'fail');
    if (all.length === 0) {
        const provider = state.cfg.provider;
        const defaults = {
            gemini: ['gemini-2.5-flash'],
            deepseek: ['deepseek-chat'],
            huggingface: ['meta-llama/Llama-3.1-8B-Instruct'],
            openrouter: [],
            aliyun: ['qwen-plus'],
            nvidia: ['meta/llama-3.3-70b-instruct']
        };
        all = defaults[provider] ? [...defaults[provider]] : [];
        if (all.length === 0) throw new Error('没有可用模型，请先点击"刷新模型列表"');
    }
    all.sort((a, b) => score(b) - score(a));
    const lastSuccessful = state.cfg.activeModel;
    if (lastSuccessful && all.includes(lastSuccessful)) {
        all = [lastSuccessful, ...all.filter(name => name !== lastSuccessful)];
    }
    return all.slice(0, 3);
}
// 模型请求统一入口：服务端过载自动重试，避免工具结果因一次 503 被丢弃。
// 429 不做原地重试：那是配额/频率限制，重试只会让限流更严重，交给上层决定是否换模型。
async function generateWithRetry(provider, model, history, key, opts = {}, search = false) {
    let lastError = null;
    for (let attempt = 0; attempt < 3; attempt++) {
        try {
            return await PROVIDERS[provider].generate(model, history, search, key, opts);
        } catch (e) {
            lastError = e;
            const detail = String(e?.message || e);
            if (attempt < 2 && /\b(500|502|503|504)\b/.test(detail)) {
                const wait = 2000 + attempt * 2000;
                if (liveTrace) liveTrace.step(`服务端繁忙（${detail.slice(0, 24)}），${Math.round(wait / 1000)} 秒后重试…`);
                await sleep(wait);
                continue;
            }
            throw e;
        }
    }
    throw lastError;
}
async function callAI(text, files, opts = {}) {
    const provider = state.cfg.provider;
    const model = state.cfg.model && state.cfg.model !== 'auto' ? state.cfg.model : '';
    const contextLimit = clampInt(state.cfg.contextMessages, 4, 40, 12);
    const textFiles = (files || []).filter(f => f.text != null);
    const binaryFiles = (files || []).filter(f => f.text == null);
    let combinedText = text || '';
    if (textFiles.length) {
        const fileContext = textFiles.map(f => `【文件：${f.name}】\n${f.text}`).join('\n\n');
        combinedText = combinedText ? combinedText + '\n\n' + fileContext : fileContext;
    }
    if (isLocalMode()) {
        const engine = getLocalEngine(), base = getBackendUrl();
        const recentMessages = opts.isolated ? [] : getActiveSession().messages.slice(-contextLimit);
        const sessionMessages = recentMessages.map(m => ({
            role: m.role === 'user' ? 'user' : 'assistant',
            content: String(m.text || '')
        }));
        if (combinedText) {
            const lastUserIdx = [...sessionMessages].reverse().findIndex(m => m.role === 'user');
            if (lastUserIdx >= 0) {
                sessionMessages[sessionMessages.length - 1 - lastUserIdx].content = combinedText;
            } else {
                sessionMessages.push({ role: 'user', content: combinedText });
            }
        }
        if (binaryFiles.length) {
            const images = binaryFiles.filter(f => f.mime?.startsWith('image/'));
            const others = binaryFiles.filter(f => !f.mime?.startsWith('image/'));
            if (others.length) {
                throw new Error('本地模式只支持图片和文本文件；' + others.map(f => f.name).join('、') + ' 为二进制文件，请先转成文字后粘贴。');
            }
            if (!images.length) throw new Error('没有可发送的图片文件。');
            if (engine === 'ollama') {
                const last = [...sessionMessages].reverse().find(m => m.role === 'user');
                const imgs = images.map(f => f.data);
                if (last) last.images = (last.images || []).concat(imgs);
                else sessionMessages.push({ role: 'user', content: combinedText || '请分析这些图片', images: imgs });
            } else {
                const last = [...sessionMessages].reverse().find(m => m.role === 'user');
                const content = [{ type: 'text', text: combinedText || '请分析这些图片' }].concat(
                    images.map(f => ({ type: 'image_url', image_url: { url: `data:${f.mime};base64,${f.data}` } }))
                );
                if (last) last.content = content;
                else sessionMessages.push({ role: 'user', content });
            }
        }
        if (engine === 'ollama') {
            if (liveTrace) liveTrace.step(`正在请求本地 Ollama（${model || 'llama3.2'}）…`);
            const messages = [{ role: 'system', content: getPrompt() }, ...sessionMessages];
            const payload = { model: model || 'llama3.2', messages, stream: false, options: { temperature: state.cfg.temperature, num_predict: state.cfg.maxTokens } };
            const data = await readJsonResponse(await fetchT(`${base}/api/chat`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }, 180000));
            const reply = normalizeProviderText(data.message?.content);
            if (!reply.trim()) throw new Error('本地模型返回空内容；请检查模型服务状态或切换模型。');
            recordUsage(data.model || model || 'ollama-local', 0, 0);
            const finalText = parseToolCalls(reply).length
                ? await runWithLocalTools(engine, base, model, messages, reply)
                : reply;
            return { text: finalText, model: data.model || model, search: false };
        }
        if (liveTrace) liveTrace.step(`正在请求本地 LM Studio（${model || '默认模型'}）…`);
        const messages = [{ role: 'system', content: getPrompt() }, ...sessionMessages.map(m => ({ role: m.role, content: m.content }))];
        const payload = { model: model || undefined, messages, temperature: state.cfg.temperature, max_tokens: state.cfg.maxTokens, stream: false };
        const data = await readJsonResponse(await fetchT(`${base}/v1/chat/completions`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }, 180000));
        const reply = normalizeProviderText(data.choices?.[0]?.message?.content, data.choices?.[0]?.message?.reasoning_content);
        if (!reply.trim()) throw new Error('本地模型返回空内容；请检查模型服务状态或切换模型。');
        recordUsage(data.model || model || 'lmstudio-local', data.usage?.prompt_tokens || 0, data.usage?.completion_tokens || 0);
        const finalText = parseToolCalls(reply).length
            ? await runWithLocalTools(engine, base, model, messages, reply)
            : reply;
        return { text: finalText, model: data.model || model, search: false };
    }
    let key = '';
    try { key = getSanitizedApiKey($('#apiKey').value || state.cfg.apiKey); } catch(e) { throw new Error('API Key 含非法字符，请到设置页重新输入'); }
    if (!key) throw new Error('网端 AI 模式需要 API Key');
    state.cfg.apiKey = key;
    if (provider === 'gemini' && model.includes('/')) {
        throw new Error('Gemini 直连模式不支持带斜杠的模型名，请切换到 OpenRouter 或改用 Gemini 原生模型名。');
    }
    let history = opts.isolated ? [] : getActiveSession().messages.slice(-contextLimit).map(m => ({ role: m.role === 'user' ? 'user' : 'model', parts: [{ text: String(m.text || '') }] }));
    if (combinedText) {
        const lastUserIdx = [...history].reverse().findIndex(m => m.role === 'user');
        if (lastUserIdx >= 0) {
            history[history.length - 1 - lastUserIdx].parts = [{ text: combinedText }];
        } else {
            history.push({ role: 'user', parts: [{ text: combinedText }] });
        }
    }
    if (binaryFiles.length) {
        const visualProviders = ['gemini', 'openrouter'];
        const hasImages = binaryFiles.some(f => f.mime?.startsWith('image/'));
        if (hasImages && !visualProviders.includes(provider)) {
            throw new Error(`当前提供商 ${PROVIDERS[provider]?.name || provider} 的直连模式暂不支持图片输入，请切换到 Gemini 或 OpenRouter，或移除图片。`);
        }
        if (!history.length) history.push({ role: 'user', parts: [{ text: combinedText || '请分析这些文件' }] });
        let lastUserMessage = [...history].reverse().find(m => m.role === 'user');
        if (!lastUserMessage) { lastUserMessage = { role: 'user', parts: [{ text: combinedText || '请分析这些文件' }] }; history.push(lastUserMessage); }
        const lastParts = lastUserMessage.parts;
        if (!lastParts[0]) lastParts[0] = { text: '' };
        if (typeof lastParts[0].text !== 'string') lastParts[0].text = '';
        for (const f of binaryFiles) {
            if (f.mime?.startsWith('image/')) {
                lastParts.push({ inline_data: { mime_type: f.mime, data: f.data } });
            } else if ((provider === 'gemini' || provider === 'openrouter') && f.mime === 'application/pdf') {
                lastParts.push({ inline_data: { mime_type: f.mime, data: f.data } });
            } else {
                lastParts[0].text += `\n[已上传文件：${f.name}（${f.mime}），当前 ${PROVIDERS[provider]?.name || provider} 直连模式暂不直接解析该类型。]`;
            }
        }
    }
    const models = getModelList(), errors = [];
    let rateLimited = 0;
    for (const m of models) {
        try {
            if (liveTrace) liveTrace.step(`正在向 ${m} 发送请求…`);
            // Gemini 直连启用自带联网搜索，无需工具审批即可拿到实时信息；后台自我分析不需要联网
            const r = await generateWithRetry(provider, m, history, key, opts, !opts.isolated && provider === 'gemini');
            if (!String(r?.text || '').trim()) throw new Error('模型返回了空回答（可能只返回推理内容或触发了模型端限制），未自动重复请求以避免重复计费；请重试或切换模型。');
            if (r.reasoning && liveTrace) liveTrace.setThought(r.reasoning);
            if (r.grounded && liveTrace) liveTrace.step('已联网检索实时信息');
            if (liveTrace) liveTrace.step(`已收到 ${m} 的回答`);
            if (!opts.isolated) {
                recordUsage(m, r.inputTokens, r.outputTokens);
                state.cfg.activeModel = m;
                saveState();
            }
            let finalText = r.text;
            if (!opts.isolated && (omniMode || parseToolCalls(r.text).length)) {
                try {
                    finalText = await runWithTools(provider, m, history, key, r.text, opts);
                } catch(e) {
                    console.warn('工具循环异常', e);
                    finalText = r.text + '\n\n[⚠️ 工具循环异常：' + e.message + ']';
                }
            }
            return { text: finalText, model: m, search: !!r.grounded };
        } catch(e) {
            const x = err(e);
            errors.push(`${m}：${x.text}`);
            if (x.kind === '429') rateLimited++;
            if (liveTrace && models.length > 1) liveTrace.step(`${m} 失败：${x.text.slice(0, 60)}，切换下一个…`);
            if (['key', '403', '401', 'net', 'timeout', 'empty'].includes(x.kind)) break;
            // 配额是账号级限制，换模型救不回来，只会让限流更严重；最多再试一个就停
            if (rateLimited >= 2) break;
            await sleep(150);
        }
    }
    throw new Error('所有模型调用失败。\n' + errors.slice(0, 8).join('\n'));
}
function err(e) {
    const m = String(e?.message || e);
    if (/返回空内容|未返回文本内容|空回答|empty response|no output/i.test(m)) return { kind: 'empty', text: m.slice(0, 300) };
    if (m.includes('non ISO-8859-1')) return { kind: 'key', text: 'API Key 包含非ASCII字符，请重新复制' };
    if (m.includes('429')) {
        if (/PerDay|per day|daily|requests per day/i.test(m)) {
            return { kind: '429', text: '今日免费配额已用完（429）。Google 免费层按天重置，需等重置或换一个 Key；付费层可解除该限制。' };
        }
        if (/PerMinute|per minute/i.test(m)) {
            return { kind: '429', text: '每分钟请求数超限（429）。等约 1 分钟再发，或减少连续刷新/测试次数。' };
        }
        return { kind: '429', text: '请求过于频繁或配额不足（429）。已去掉联网工具重试过一次，仍被限制，说明是账号级配额，请稍后再试或更换 Key。' };
    }
    if (/请求超时|timeout|timed out/i.test(m)) return { kind: 'timeout', text: '模型请求超时；为避免重复计费，已停止自动切换模型。可稍后重试、降低上下文/输出长度，或更换模型。' };
    if (m.includes('402')) return { kind: '402', text: 'OpenRouter 账户余额不足（402）' };
    if (m.includes('401')) return { kind: '401', text: '认证失败（401）' };
    if (m.includes('404')) return { kind: '404', text: '模型不可用（404）' };
    if (m.includes('403') || /API key|API_KEY_INVALID/i.test(m)) return { kind: '403', text: 'API Key 无效或无权限（403）' };
    if (m.includes('Failed to fetch') || m.includes('NetworkError') || m.includes('fetch')) return { kind: 'net', text: '网络请求失败（可能断网、CORS 被拦截，或本地服务未启动/未允许网页来源）' };
    return { kind: 'other', text: m.slice(0, 300) };
}
function sleep(ms){return new Promise(r=>setTimeout(r,ms));}
function recordUsage(model, inputTokens, outputTokens) {
    try {
        const raw = localStorage.getItem('guling_usage') || '[]';
        const parsed = JSON.parse(raw);
        const usage = Array.isArray(parsed) ? parsed : [];
        usage.push({ model, inputTokens: Number(inputTokens) || 0, outputTokens: Number(outputTokens) || 0, timestamp: Date.now() });
        localStorage.setItem('guling_usage', JSON.stringify(usage.slice(-1000)));
    } catch(e) { console.warn('用量统计未能保存', e); }
}
function getModelPrice(model) {
    const m = String(model || '').toLowerCase();
    if (!m) return null;
    if (m.includes('free') || m.endsWith(':free')) return { input: 0, output: 0 };
    if (m.includes('gemini') && m.includes('flash')) return { input: 0.1, output: 0.4 };
    if (m.includes('gemini') && m.includes('pro')) return { input: 1.25, output: 5.0 };
    if (m.includes('qwen-turbo')) return { input: 0.05, output: 0.1 };
    if (m.includes('qwen-plus')) return { input: 0.15, output: 0.45 };
    if (m.includes('qwen')) return { input: 0.2, output: 0.6 };
    if (m.includes('deepseek')) return { input: 0.3, output: 0.6 };
    if (m.includes('llama') || m.includes('mistral') || m.includes('glm')) return { input: 0.2, output: 0.2 };
    return null;
}
function getCostSummary() {
    let usage = [];
    try { const parsed = JSON.parse(localStorage.getItem('guling_usage') || '[]'); usage = Array.isArray(parsed) ? parsed : []; } catch(e) { usage = []; }
    const today = new Date().setHours(0,0,0,0);
    const todayUsage = usage.filter(u => u.timestamp >= today);
    let sum = 0, hasUnknownPrice = false;
    todayUsage.forEach(u => {
        const p = getModelPrice(u.model);
        if (!p) { hasUnknownPrice = true; return; }
        sum += (u.inputTokens * p.input + u.outputTokens * p.output) / 1e6;
    });
    return sum.toFixed(4) + (hasUnknownPrice ? '（部分模型未配置价格，非完整账单）' : '');
}
const SEARCH_ENGINES = [
    'https://search.bus-hit.me/search', 'https://searx.si/search', 'https://search.mdosch.de/search',
    'https://priv.au/search', 'https://s.zhaoweiwei.de/search', 'https://searx.tiekoetter.com/search',
    'https://search.weil-no.de/search', 'https://searx.nycademy.it/search', 'https://searx.work/search',
    'https://searxng.site/search', 'https://search.sapti.me/search', 'https://searxng.catsup.me/search',
    'https://search.nova-si.de/search', 'https://searx.female.de/search'
];
async function keiroSearch(query, maxResults, externalSignal) {
    const url = 'https://api.keirolabs.cloud/api/v2/search/fast';
    const r = await fetchT(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${state.cfg.searchApiKey}` },
        body: JSON.stringify({ query, maxResults: Math.min(maxResults, 10) })
    }, 12000, externalSignal);
    if (!r.ok) throw new Error(`Keiro HTTP ${r.status}`);
    const d = await r.json();
    const list = Array.isArray(d?.results) ? d.results : (Array.isArray(d) ? d : []);
    const results = list
        .filter(item => item && (item.url || item.link))
        .map(item => ({
            title: String(item.title || '').slice(0, 200),
            snippet: String(item.snippet || item.content || item.description || '').slice(0, 500),
            url: String(item.url || item.link || ''),
            engine: 'Keiro'
        }))
        .filter(item => item.url && item.title);
    if (!results.length) throw new Error('Keiro 未返回结果');
    return results.slice(0, maxResults);
}
async function tavilySearch(query, maxResults, externalSignal) {
    const url = 'https://api.tavily.com/search';
    const r = await fetchT(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ api_key: state.cfg.searchApiKey, query, max_results: Math.min(maxResults, 10), search_depth: 'basic', include_answer: false })
    }, 15000, externalSignal);
    if (!r.ok) throw new Error(`Tavily HTTP ${r.status}`);
    const d = await r.json();
    const list = Array.isArray(d?.results) ? d.results : [];
    const results = list
        .filter(item => item && item.url)
        .map(item => ({
            title: String(item.title || '').slice(0, 200),
            snippet: String(item.content || '').slice(0, 500),
            url: String(item.url || ''),
            engine: 'Tavily'
        }))
        .filter(item => item.url && item.title);
    if (!results.length) throw new Error('Tavily 未返回结果');
    return results.slice(0, maxResults);
}
async function testSearchConnection() {
    const provider = state.cfg.searchProvider || 'builtin';
    const statusEl = $('#searchTestStatus');
    if (statusEl) statusEl.textContent = '测试中…';
    try {
        if (provider === 'builtin') {
            const r = await webSearch('test', 3, true);
            if (statusEl) statusEl.textContent = `✅ 内置搜索可用，返回 ${r.length} 条结果。`;
            return true;
        }
        if (!state.cfg.searchApiKey) {
            if (statusEl) statusEl.textContent = '❌ 请先填写 API Key。';
            return false;
        }
        if (provider === 'keiro') {
            const r = await keiroSearch('test', 3);
            if (statusEl) statusEl.textContent = `✅ Keiro 连接成功，返回 ${r.length} 条结果。`;
            return true;
        }
        if (provider === 'tavily') {
            const r = await tavilySearch('test', 3);
            if (statusEl) statusEl.textContent = `✅ Tavily 连接成功，返回 ${r.length} 条结果。`;
            return true;
        }
    } catch (e) {
        if (statusEl) statusEl.textContent = `❌ 连接失败：${e.message}`;
        return false;
    }
}
function syncSearchProviderUI() {
    const sel = $('#searchProvider');
    const keyWrap = $('#searchKeyWrap');
    if (sel) sel.value = state.cfg.searchProvider || 'builtin';
    const keyInput = $('#searchApiKey');
    if (keyInput) keyInput.value = state.cfg.searchApiKey || '';
    if (keyWrap) keyWrap.style.display = (state.cfg.searchProvider === 'builtin') ? 'none' : 'block';
}
async function webSearch(query, maxResults=8, quick=false, externalSignal) {
    if (!query) return [];
    const provider = state.cfg.searchProvider || 'builtin';
    if (provider === 'keiro' && state.cfg.searchApiKey) {
        try { return await keiroSearch(query, maxResults, externalSignal); }
        catch (e) { /* fall through to builtin */ }
    }
    if (provider === 'tavily' && state.cfg.searchApiKey) {
        try { return await tavilySearch(query, maxResults, externalSignal); }
        catch (e) { /* fall through to builtin */ }
    }
    let engines = state.cfg.searchEngineUrl ? [state.cfg.searchEngineUrl] : (quick ? [SEARCH_ENGINES[5]] : SEARCH_ENGINES);
    if (quick) engines = engines.slice(0, 1);
    const results = [];
    const errors = [];
    const aborted = () => externalSignal && externalSignal.aborted;
    for (const engine of engines) {
        if (aborted()) throw new Error('搜索已取消');
        const url = engine + (engine.includes('?') ? '&' : '?') + 'format=json&q=' + encodeURIComponent(query) + '&number=' + maxResults;
        try {
            const r = await fetchT(url, { method:'GET', headers:{'Accept':'application/json'} }, 8000, externalSignal);
            if (r.ok) {
                const d = await r.json();
                if (d.results && Array.isArray(d.results)) {
                    d.results.forEach(item => {
                        if (item.url && item.title) results.push({ title: item.title, snippet: item.content || item.snippet || '', url: item.url, engine: engine.replace('https://','').replace('/search','') });
                    });
                }
                if (results.length) break;
            }
        } catch(e) { errors.push(`直接: ${e.message}`); }
        const allProxies = [
            'https://api.allorigins.win/raw?url=' + encodeURIComponent(url),
            'https://corsproxy.io/?' + encodeURIComponent(url),
            'https://api.codetabs.com/v1/proxy?quest=' + encodeURIComponent(url)
        ];
        const proxies = quick ? allProxies.slice(0, 1) : allProxies;
        for (const proxy of proxies) {
            if (aborted()) throw new Error('搜索已取消');
            try {
                const r = await fetchT(proxy, { method:'GET', headers:{'Accept':'application/json'} }, 8000, externalSignal);
                if (r.ok) {
                    const d = await r.json();
                    if (d.results && Array.isArray(d.results)) {
                        d.results.forEach(item => {
                            if (item.url && item.title) results.push({ title: item.title, snippet: item.content || item.snippet || '', url: item.url, engine: engine.replace('https://','').replace('/search','') });
                        });
                    }
                }
            } catch(e) { errors.push(`代理: ${e.message}`); }
            if (results.length) break;
        }
        if (results.length) break;
    }
    if (results.length === 0) {
        try {
            const url = 'https://en.wikipedia.org/w/api.php?action=opensearch&format=json&formatversion=2&search=' + encodeURIComponent(query) + '&limit=' + maxResults;
            const r = await fetchT(url, {}, 8000, externalSignal);
            const d = await r.json();
            if (Array.isArray(d) && d.length >= 4) {
                for (let i=0;i<d[1].length;i++) {
                    results.push({ title: d[1][i], snippet: d[2][i] || '', url: d[3][i] || '', engine: 'Wikipedia' });
                }
            }
        } catch(e) { errors.push(`Wikipedia: ${e.message}`); }
    }
    if (results.length === 0) throw new Error('所有搜索源均失败：' + errors.slice(0,2).join('; '));
    const seen = new Set();
    const deduped = results.filter(r => {
        if (seen.has(r.url)) return false;
        seen.add(r.url);
        return true;
    });
    return deduped.slice(0, maxResults);
}
function render() {
    const s = getActiveSession();
    if (!s) return;
    const ms = s.messages.length ? s.messages.map((m, idx) => {
        const trace = m.role === 'user' ? null : (m.trace || null);
        const thinkHtml = trace && trace.thought
            ? `<details class="trace think"><summary>思考过程</summary><div class="think-body">${esc(trace.thought)}</div></details>`
            : '';
        const stepsHtml = (trace && Array.isArray(trace.steps) ? trace.steps : []).map(step =>
            `<div class="trace-step done"><span class="dot">✓</span><span class="txt">${esc(step)}</span></div>`
        ).join('') || '<div class="trace-step">无步骤记录</div>';
        const traceHtml = trace
            ? `${thinkHtml}<details class="trace"><summary>${esc(traceSummaryText(trace))}</summary><div class="trace-steps">${stepsHtml}</div></details>`
            : '';
        return `
        <div class="msg ${m.role === 'user' ? 'user' : 'ai'}">
            <div class="meta">
                <span>${m.role === 'user' ? '创造者' : '古灵'}</span>
                ${['ai','assistant'].includes(m.role) && !String(m.text || '').startsWith('请求失败：') ? `<button class="btn-tiny" onclick="extractLesson(${idx})">记住教训</button>` : ''}
            </div>
            ${traceHtml}
            ${m.role === 'user' ? esc(displayText(m.text)) : mdToHtml(displayText(m.text))}
        </div>`;
    }).join('') : '<div style="color:var(--muted);text-align:center;margin:50px 0">当前会话为空</div>';
    $('#chatList').innerHTML = ms;
    $('#chatList').scrollTop = $('#chatList').scrollHeight;
    const sessionSelect = $('#sessionSelect');
    sessionSelect.replaceChildren();
    state.sessions.forEach((session, index) => {
        const option = document.createElement('option');
        option.value = String(session?.id ?? `session-${index}`);
        option.textContent = String(session?.name || '对话 ' + (index + 1));
        sessionSelect.appendChild(option);
    });
    sessionSelect.value = String(state.active ?? '');
    setInputIfNotFocused('#backendUrl', state.cfg.backendUrl || (state.cfg.localEngine === 'lmstudio' ? 'http://127.0.0.1:1234' : 'http://127.0.0.1:11434'));
    $('#localEngine').value = state.cfg.localEngine || 'ollama';
    $('#aiModeSelect').value = aiMode();
    $('#providerSelect').value = state.cfg.provider;
    hydrateCachedModelList();
    initModelSearch();
    $('#modeSelect').value = state.meta.mode || 'guling';
    $('#status').textContent = `${VERSION} · ${MODES[state.meta.mode] || '古灵'} · ${state.cfg.provider} · ${aiMode()}`;
    $('#memCount').textContent = state.mem.length + ' 条';
    const memChars = state.mem.reduce((n, m) => n + String(m).length, 0);
    $('#memCharCount').textContent = memChars ? `（共约 ${memChars} 字，注入上限 ${MAX_MEM_CHARS} 字）` : '';
    $('#memList').innerHTML = state.mem.length ? state.mem.map((m, i) => `<div class="memitem"><b>#${i+1}</b> ${esc(m)} <button style="border:0;background:none;color:#ff7c87;float:right" onclick="removeMem(${i})">×</button></div>`).join('') : '暂无记忆';
    $('#filebar').innerHTML = pendingFiles.map((f, i) => `<div class="filepill">${f.loading ? '[解析中] ' : (f.text != null ? '[文本] ' : '')}${esc(f.name)} <button onclick="removeFile(${i})">×</button></div>`).join('');
    renderRulesTable();
    const ruleChars = (state.cfg.coreRules || []).join('\n').length;
    $('#ruleCountLabel').textContent = (state.cfg.coreRules || []).length;
    $('#ruleCharLabel').textContent = ruleChars;
    const charWarn = $('#ruleCharWarn');
    if (charWarn) charWarn.style.display = ruleChars > MAX_RULES_WARN_CHARS ? 'block' : 'none';
    $('#costDisplay').textContent = `今日费用: $${getCostSummary()}`;
    $('#tempRange').value = state.cfg.temperature;
    $('#tempVal').textContent = state.cfg.temperature;
    $('#maxTokensRange').value = state.cfg.maxTokens;
    $('#maxTokensVal').textContent = state.cfg.maxTokens;
    $('#ctxRange').value = clampInt(state.cfg.contextMessages, 4, 40, 12);
    $('#ctxVal').textContent = clampInt(state.cfg.contextMessages, 4, 40, 12);
    updateRuleHash();
    syncMiniMode();
    renderBackupInfo();
    $('#omniModeSwitch').checked = !!omniMode;
    renderApprovalQueue();
    renderMcpServers();
    syncSearchProviderUI();
}
function renderBackupInfo() {
    const el = $('#backupInfo');
    if (!el) return;
    try {
        const raw = localStorage.getItem(BACKUP_STORE);
        if (!raw) { el.textContent = '暂无备份'; return; }
        const d = JSON.parse(raw);
        const t = d.__backupTime || null;
        el.textContent = '最近备份：' + (t ? new Date(t).toLocaleString() : '未知时间');
    } catch(e) { el.textContent = '备份损坏或无法读取'; }
}
function tab(n) {
    $$('nav button').forEach(b => b.classList.toggle('active', b.dataset.tab === n));
    $$('.tab').forEach(t => t.classList.toggle('active', t.id === 'tab-' + n));
    if (n === 'capsule') renderBackupInfo();
}
function removeSession(id) {
    if (state.sessions.length === 1) { toast('至少保留一个会话', 'bad'); return; }
    if (!confirm('删除该会话？')) return;
    state.sessions = state.sessions.filter(x => x.id !== id);
    if (state.active === id) state.active = state.sessions[0].id;
    saveState(); render(); toast('会话已删除', 'ok');
}
function removeMem(i) { state.mem.splice(i, 1); saveState(); render(); }
function removeFile(i) { pendingFiles.splice(i, 1); render(); }
function removeRule(i) {
    state.cfg.coreRules.splice(i, 1);
    state.cfg.rulesVersion = 'custom';
    saveState(); render();
}
function updateRuleHash() {
    const law = state.cfg.coreLaw || '';
    const rules = state.cfg.coreRules || [];
    const hashEl = $('#ruleHash');
    const checkEl = $('#ruleCheck');
    if (!hashEl || !checkEl) return;
    if (!(window.crypto && window.crypto.subtle && typeof window.crypto.subtle.digest === 'function')) {
        hashEl.textContent = '当前环境不支持';
        checkEl.textContent = 'SHA-256 需要 HTTPS 或 localhost（非安全上下文不可用）';
        return;
    }
    crypto.subtle.digest('SHA-256', new TextEncoder().encode(law + rules.join('\n'))).then(buf => {
        const hash = [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, '0')).join('');
        hashEl.textContent = hash.slice(0, 16) + '…';
        checkEl.textContent = '规则库动态指纹（SHA-256）';
    }).catch(() => {
        hashEl.textContent = '不支持';
        checkEl.textContent = '浏览器不支持SHA-256';
    });
}
function syncMiniMode() {
    const mode = state.meta.mode || 'guling';
    document.querySelectorAll('.mini-mode').forEach(b => { b.classList.toggle('active', b.dataset.mode === mode); });
}
function initMiniMode() {
    const toggle = $('#miniToggle');
    const modes = $('#miniModes');
    let open = false;
    toggle.addEventListener('click', () => {
        open = !open;
        modes.style.display = open ? 'flex' : 'none';
        toggle.textContent = open ? '✕' : '☁';
    });
    document.querySelectorAll('.mini-mode').forEach(btn => {
        btn.addEventListener('click', () => {
            state.meta.mode = btn.dataset.mode;
            saveState();
            render();
            toast('已切换到' + MODES[btn.dataset.mode], 'ok');
        });
    });
    let isDragging = false, startX, startY, startLeft, startTop, moved = false, rafId = null;
    const switcher = $('#miniModeSwitcher');
    switcher.addEventListener('pointerdown', (e) => {
        isDragging = true; moved = false;
        startX = e.clientX; startY = e.clientY;
        startLeft = switcher.offsetLeft; startTop = switcher.offsetTop;
        switcher.setPointerCapture(e.pointerId);
    });
    switcher.addEventListener('pointermove', (e) => {
        if (!isDragging) return;
        const dx = e.clientX - startX, dy = e.clientY - startY;
        if (Math.abs(dx) > 5 || Math.abs(dy) > 5) moved = true;
        if (moved) {
            if (rafId) cancelAnimationFrame(rafId);
            rafId = requestAnimationFrame(() => {
                switcher.style.left = (startLeft + dx) + 'px';
                switcher.style.top = (startTop + dy) + 'px';
                rafId = null;
            });
        }
    });
    switcher.addEventListener('pointerup', () => { isDragging = false; setTimeout(() => moved = false, 100); });
}
function initKeyboardFix() {
    if (window.visualViewport) {
        window.visualViewport.addEventListener('resize', () => {
            const vv = window.visualViewport;
            const composer = document.querySelector('.composer');
            const kh = window.innerHeight - vv.height;
            if (kh > 0) { composer.style.paddingBottom = (kh + 9) + 'px'; } else { composer.style.paddingBottom = '9px'; }
        });
    }
}
let isExtractingLesson = false;
function extractLesson(msgIndex) {
    if (isExtractingLesson) return;
    const s = getActiveSession();
    if (!s.messages[msgIndex] || !['ai','assistant'].includes(s.messages[msgIndex].role) || String(s.messages[msgIndex].text || '').startsWith('请求失败：')) return;
    isExtractingLesson = true;
    const text = s.messages[msgIndex].text;
    const rule = prompt('你想让古灵记住什么教训？可以修改以下提取的内容并保存为新规则：', `【创造者纠正】不要出现以下错误：${text.slice(0, 30)}... 以后必须严格规范回答。`);
    if (rule) {
        state.cfg.coreRules.push(rule);
        state.cfg.rulesVersion = 'custom';
        saveState();
        render();
        toast('已作为新规则保存，下次对话生效', 'ok');
    }
    setTimeout(() => { isExtractingLesson = false; }, 1000);
}
// ZIP 安全文本提取：只读取文本源码，不执行压缩包中的任何内容。
async function extractZipText(file) {
    if (!file || file.size > 10 * 1024 * 1024) throw new Error('ZIP 压缩包超过 10MB 安全上限。');
    if (!window.GulingZipReader) throw new Error('ZIP 读取模块未加载，请重新打开应用或更新版本。');
    return window.GulingZipReader.extractZipTextFromBytes(await file.arrayBuffer());
}
function normalizeProjectPath(raw) {
    const path = String(raw || '').replace(/\\/g, '/').replace(/^\.\//, '');
    if (!path || path.length > 500 || path.startsWith('/') || /^[a-z]:/i.test(path)) return '';
    if (path.split('/').some(part => part === '..')) return '';
    return path;
}
// ===== 项目 ZIP 永久保存（IndexedDB，刷新/重启不丢失） =====
function openProjectDb() {
    return new Promise((resolve, reject) => {
        if (!window.indexedDB) { reject(new Error('当前环境不支持 IndexedDB')); return; }
        const request = indexedDB.open(PROJECT_DB_NAME, 1);
        request.onupgradeneeded = () => {
            const db = request.result;
            if (!db.objectStoreNames.contains(PROJECT_DB_STORE)) db.createObjectStore(PROJECT_DB_STORE);
        };
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error || new Error('打开项目数据库失败'));
    });
}
async function saveProjectRecord(record) {
    const db = await openProjectDb();
    try {
        await new Promise((resolve, reject) => {
            const tx = db.transaction(PROJECT_DB_STORE, 'readwrite');
            tx.objectStore(PROJECT_DB_STORE).put(record, PROJECT_DB_KEY);
            tx.oncomplete = () => resolve();
            tx.onerror = () => reject(tx.error || new Error('保存项目 ZIP 失败'));
            tx.onabort = () => reject(tx.error || new Error('保存项目 ZIP 已中止'));
        });
    } finally { db.close(); }
}
async function loadProjectRecord() {
    const db = await openProjectDb();
    try {
        return await new Promise((resolve, reject) => {
            const tx = db.transaction(PROJECT_DB_STORE, 'readonly');
            const request = tx.objectStore(PROJECT_DB_STORE).get(PROJECT_DB_KEY);
            request.onsuccess = () => resolve(request.result || null);
            request.onerror = () => reject(request.error || new Error('读取项目 ZIP 失败'));
        });
    } finally { db.close(); }
}
async function parseProjectBytes(bytes) {
    if (!window.GulingZipReader) throw new Error('ZIP 读取模块未加载，请重新打开应用或更新版本。');
    const parsed = await window.GulingZipReader.extractZipTextFromBytes(bytes);
    return { files: parsed.files || [], skipped: parsed.skipped || 0 };
}
let selfAnalysisRunning = false;
let selfAnalysisTimer = null;

function projectFingerprint() {
    if (!projectRef || !projectRef.files || !projectRef.files.length) return '';
    const size = projectRef.files.reduce((total, file) => total + String(file.content || '').length, 0);
    return `${projectRef.name}:${projectRef.files.length}:${size}`;
}
function readSelfProfile() {
    try {
        const saved = JSON.parse(localStorage.getItem(SELF_PROFILE_KEY) || 'null');
        return saved && saved.text ? saved : null;
    } catch (_) { return null; }
}
function selfProfileStatusText(saved) {
    if (!saved) return '自我认知：等待模型接入';
    const provider = saved.providerLabel || saved.provider || '未知提供商';
    const model = saved.model && saved.model !== '自动选择' ? ` · ${saved.model}` : '';
    return `自我认知：模型已清楚自我来源（${saved.project}，由 ${provider}${model} 分析）`;
}
function selfProfileNote() {
    const saved = readSelfProfile();
    if (!saved) return '';
    return `\n【自我来源已确认】创造者已上传你的源代码包「${saved.project}」，你已确认这就是你自己（古灵 OMNI）的实现代码，不是第三方项目。你当前的真实能力以这份自我认知为准，不得虚构未实现的功能：\n${saved.text}`;
}
function updateSelfAwareStatus(text, tone) {
    const el = $('#selfAwareStatus');
    if (!el) return;
    el.textContent = text;
    el.style.color = tone === 'ok' ? '#6bd18a' : (tone === 'bad' ? '#f08a8a' : 'var(--muted)');
}
// 模型接入后自动读一遍创造者上传的源码包，建立“这是我自己的代码”的自我认知
async function runSelfAnalysis(reason) {
    if (selfAnalysisRunning) return;
    if (!projectRef || !projectRef.files.length) {
        updateSelfAwareStatus('自我认知：未上传源码包，自动分析已取消');
        return;
    }
    const configured = isLocalMode() ? !!state.cfg.backendUrl : !!state.cfg.apiKey;
    if (!configured) {
        updateSelfAwareStatus('自我认知：尚未接入模型，接入成功后会自动分析源码');
        return;
    }
    if (busy) {
        clearTimeout(selfAnalysisTimer);
        selfAnalysisTimer = setTimeout(() => runSelfAnalysis(reason), 4000);
        return;
    }
    const fingerprint = projectFingerprint();
    const analysisProvider = isLocalMode() ? 'local' : state.cfg.provider;
    const analysisProviderLabel = isLocalMode() ? '本地模型' : (PROVIDERS[state.cfg.provider]?.name || state.cfg.provider);
    const analysisModel = state.cfg.model && state.cfg.model !== 'auto' ? state.cfg.model : '自动选择';
    const saved = readSelfProfile();
    if (reason !== 'manual' && saved && saved.fingerprint === fingerprint && saved.provider === analysisProvider) {
        updateSelfAwareStatus(selfProfileStatusText(saved), 'ok');
        return;
    }
    selfAnalysisRunning = true;
    updateSelfAwareStatus('自我认知：正在后台分析你自己的源码…');
    try {
        const prompt = `这份源码属于你自己（古灵 OMNI），不是第三方项目。
请阅读后确认身份与能力，输出一份自我认知摘要（400-700 字），必须包含：
1. 你的运行形态与技术栈（Android WebView + Capacitor、targetSdk、版本号）；
2. 你实际已实现的能力（对话、联网检索、本地模型、工具调用与审批、项目分析、自我更新等，只写代码里真实存在的）；
3. 你明确不具备或受限的能力；
4. 一句话确认：你的自我来源是创造者上传的这份源码包。
只依据下列源码，不得猜测或虚构；不要调用任何工具，直接输出结果。

项目：${projectRef.name}
文件清单：
${projectManifestText(3000)}

关键源码：
${projectSourceBundle(26000)}`;
        const result = await callAI(prompt, [], { isolated: true });
        const text = String(result?.text || '').trim();
        if (!text) throw new Error('模型返回空内容');
        try {
            localStorage.setItem(SELF_PROFILE_KEY, JSON.stringify({
                project: projectRef.name,
                fingerprint,
                provider: analysisProvider,
                providerLabel: analysisProviderLabel,
                model: analysisModel,
                text: text.slice(0, 3000),
                at: Date.now()
            }));
        } catch (_) {}
        updateSelfAwareStatus(selfProfileStatusText(readSelfProfile()), 'ok');
        toast('模型已清楚自我来源', 'ok');
    } catch (e) {
        updateSelfAwareStatus('自我认知：自我分析失败：' + e.message, 'bad');
    } finally {
        selfAnalysisRunning = false;
    }
}
function scheduleSelfAnalysis(delay = 1200) {
    clearTimeout(selfAnalysisTimer);
    selfAnalysisTimer = setTimeout(() => { runSelfAnalysis('auto'); }, delay);
}
function bootstrapSelfAwareness() {
    if (!projectRef || !projectRef.files.length) {
        updateSelfAwareStatus('自我认知：未上传源码包，自动分析已取消');
        return;
    }
    const saved = readSelfProfile();
    const provider = isLocalMode() ? 'local' : state.cfg.provider;
    if (saved && saved.fingerprint === projectFingerprint() && saved.provider === provider) {
        updateSelfAwareStatus(selfProfileStatusText(saved), 'ok');
        return;
    }
    updateSelfAwareStatus(saved ? '自我认知：更换了模型，正在重新分析源码…' : '自我认知：已检测到源码包，等待模型接入');
    scheduleSelfAnalysis(2500);
}
function updateProjectUi(note = '当前项目') {
    const sizeMb = projectZipBytes ? (projectZipBytes.byteLength / 1024 / 1024).toFixed(2) : '0.00';
    const fileName = projectRef?.name || '未命名项目';
    const fileCount = projectRef?.files?.length || 0;
    const statusEl = $('#termuxUploadStatus');
    if (statusEl) statusEl.textContent = `${note}：${fileName}（${sizeMb} MB，${fileCount} 个文本文件，已永久保存，刷新不丢失）`;
    const buildBtn = $('#termuxBuildApkBtn');
    if (buildBtn) buildBtn.disabled = !termuxProjectZipUploaded;
    const analyzeBtn = $('#termuxAnalyzeProject');
    if (analyzeBtn) analyzeBtn.disabled = !projectRef || !projectRef.files.length;
}
async function restorePersistedProject() {
    let record = null;
    try { record = await loadProjectRecord(); } catch (error) { console.warn('读取持久化项目失败', error); return; }
    if (!record || !record.bytes) return;
    try {
        projectZipBytes = record.bytes instanceof Uint8Array ? record.bytes : new Uint8Array(record.bytes);
        let parsed = { files: [], skipped: 0 };
        try { parsed = await parseProjectBytes(projectZipBytes); } catch (error) { console.warn('恢复项目后解析源码失败', error); }
        projectRef = { name: record.name || 'guling-project.zip', files: parsed.files, skipped: parsed.skipped, at: record.at || new Date().toISOString() };
        termuxProjectZipUploaded = true;
        updateProjectUi('已恢复上次上传');
        const out = $('#termuxBuildOutput');
        if (out) out.textContent = `已载入项目：${projectRef.name}。可先让古灵分析，或按建议生成新版本。`;
        bootstrapSelfAwareness();
    } catch (error) {
        console.warn('恢复项目 ZIP 失败', error);
    }
}
function projectSourceBundle(limit = 60000) {
    if (!projectRef) return '';
    const priority = [
        'www/app.js', 'www/index.html', 'www/style.css', 'www/providers.js', 'www/config.js',
        'package.json', 'capacitor.config.ts',
        'android/app/src/main/java/com/guling/omni/GulingNativePlugin.java',
        'android/app/src/main/AndroidManifest.xml'
    ];
    const files = [...projectRef.files].sort((a, b) => {
        const ai = priority.findIndex(item => a.name.endsWith(item));
        const bi = priority.findIndex(item => b.name.endsWith(item));
        return (ai < 0 ? 999 : ai) - (bi < 0 ? 999 : bi);
    });
    let text = '';
    for (const file of files) {
        if (text.length >= limit) break;
        const remaining = limit - text.length;
        const content = file.content.length > remaining
            ? file.content.slice(0, remaining) + '\n…（已截断）'
            : file.content;
        text += `\n=== ${file.name} ===\n${content}\n`;
    }
    return text;
}
function projectManifestText(limit = 6000) {
    if (!projectRef) return '（创造者尚未上传项目 ZIP，无法读取项目源码）';
    const lines = projectRef.files.map(f => `${f.name}（${f.content.length} 字符）`);
    let text = `项目：${projectRef.name}\n可读文本文件 ${projectRef.files.length} 个，跳过 ${projectRef.skipped} 个非文本或超限文件。\n${lines.join('\n')}`;
    if (text.length > limit) text = text.slice(0, limit) + '\n…（清单已截断，请用 project_search 检索）';
    return text;
}
function readProjectFileContent(rawPath, maxChars = 12000) {
    if (!projectRef) return '（创造者尚未上传项目 ZIP）';
    const path = normalizeProjectPath(rawPath);
    if (!path) return '文件路径不合法';
    const file = projectRef.files.find(f => f.name === path) || projectRef.files.find(f => f.name.endsWith('/' + path));
    if (!file) return `未找到文件：${path}。可先用 project_list 查看可用路径`;
    const content = file.content.slice(0, maxChars);
    return `${file.name}（${file.content.length} 字符）\n${content}${file.content.length > maxChars ? `\n\n[已截断至 ${maxChars} 字符]` : ''}`;
}
function searchProjectText(rawQuery, maxHits = 40) {
    if (!projectRef) return '（创造者尚未上传项目 ZIP）';
    const query = String(rawQuery || '').trim();
    if (!query) return '缺少 query 参数';
    const needle = query.toLowerCase();
    const keywords = query.toLowerCase().split(/\s+/).filter(Boolean);
    const fileHits = [];
    for (const file of projectRef.files) {
        const lines = file.content.split('\n');
        const hits = [];
        for (let i = 0; i < lines.length; i++) {
            if (!lines[i].toLowerCase().includes(needle)) continue;
            const prev = i > 0 ? lines[i - 1].trim().slice(0, 120) : '';
            hits.push({ line: i + 1, text: lines[i].trim().slice(0, 200), prev });
            if (hits.length >= 10) break;
        }
        if (hits.length) {
            const score = keywordScore(file.content, query) + hits.length * 2;
            fileHits.push({ file, hits, score });
        }
    }
    if (!fileHits.length) return '没有匹配结果';
    fileHits.sort((a, b) => b.score - a.score);
    const out = [];
    let total = 0;
    for (const fh of fileHits) {
        if (total >= maxHits) break;
        const remaining = maxHits - total;
        const shown = fh.hits.slice(0, Math.min(remaining, 5));
        total += shown.length;
        const lines = shown.map(h => `  L${h.line}: ${h.text}${h.prev ? `\n    ↑ ${h.prev}` : ''}`);
        out.push(`📄 ${fh.file.name}（${fh.hits.length} 处匹配）\n${lines.join('\n')}`);
    }
    const summary = fileHits.length > 10 ? `（共 ${fileHits.length} 个文件命中，仅显示前 10 个）` : '';
    return `${out.join('\n\n')}${summary}`;
}
function parseProjectFiles(text) {
    const match = String(text || '').match(/```guling-files\s*([\s\S]*?)```/);
    if (!match) return null;
    let data;
    try { data = JSON.parse(match[1].trim()); } catch (e) { return null; }
    const files = [];
    for (const item of Array.isArray(data?.files) ? data.files : []) {
        const path = normalizeProjectPath(item?.path);
        if (!path || typeof item?.content !== 'string') continue;
        files.push({ path, content: item.content });
    }
    return files.length ? files : null;
}
function stripProjectFiles(text) {
    return String(text || '').replace(/```guling-files[\s\S]*?```/g, '（新版本源码已折叠）').trim();
}
function applyProjectFilesToZip(files) {
    if (!projectZipBytes) throw new Error('没有项目 ZIP，请先在设置中上传。');
    if (!window.fflate || typeof window.fflate.unzipSync !== 'function') throw new Error('ZIP 组件不支持重新打包');
    if (files.length > 80) throw new Error('单次生成的文件数量超过 80 个限制');
    const entries = window.fflate.unzipSync(projectZipBytes);
    for (const file of files) entries[file.path] = window.fflate.strToU8(file.content);
    return window.fflate.zipSync(entries, { level: 6 });
}

const TEXT_EXTENSIONS = /\.(txt|md|markdown|json|csv|tsv|log|xml|html|htm|yaml|yml|ini|conf|env|js|mjs|ts|tsx|jsx|py|java|c|cc|cpp|h|hpp|cs|go|rs|rb|php|css|scss|less|sh|bash|zsh|ps1|sql|vue|svelte|toml|properties|gradle|dockerfile|makefile|gitignore)$/i;
function isTextFile(f) {
    return /^text\//i.test(f.mime || '') || TEXT_EXTENSIONS.test(f.name || '');
}
async function send() {
    if (busy) return;
    if (!(await verifyMaster())) return;
    if (pendingFiles.some(file => file.ready)) {
        busy = true;
        $('#sendBtn').disabled = true;
        $('#sendBtn').textContent = '解析附件…';
        toast('正在读取附件，请稍候…');
        while (true) {
            const pendingReads = pendingFiles.map(file => file.ready).filter(Boolean);
            if (!pendingReads.length) break;
            await Promise.allSettled(pendingReads);
        }
        busy = false;
        $('#sendBtn').disabled = false;
        $('#sendBtn').textContent = '发送';
    }
    const text = $('#prompt').value.trim();
    if (!text && pendingFiles.length === 0) return;
    if (!isLocalMode()) {
        try {
            const k = getSanitizedApiKey($('#apiKey').value || state.cfg.apiKey);
            if (!k) { toast('网端 AI 模式需要 API Key', 'bad'); tab('settings'); return; }
            state.cfg.apiKey = k;
        } catch(e) {
            toast('API Key 含非法字符，请到设置页重新输入', 'bad'); tab('settings'); return;
        }
    }
    const s = getActiveSession();
    const fileNames = pendingFiles.map(f => f.name).join('、');
    const displayText = text || (pendingFiles.length ? `（上传文件：${fileNames}）` : '');
    s.messages.push({ role: 'user', text: displayText });
    $('#prompt').value = '';
    render();
    busy = true; $('#sendBtn').disabled = true; $('#sendBtn').textContent = '思考中…';
    let success = false;
    let aiReply = '';
    liveTrace = startLiveTrace();
    const callOpts = {
        onChunk: (fullText) => { if (liveTrace) liveTrace.setText(fullText); },
        onThought: (reasoning) => { if (liveTrace) liveTrace.setThought(reasoning); }
    };
    try {
        const result = await callAI(text, pendingFiles, callOpts);
        aiReply = String(result?.text || '').trim();
        if (!aiReply) throw new Error('模型返回空内容；未显示空白回复，也未自动重复请求。请重试或更换模型。');
        const trace = liveTrace ? liveTrace.finish(true) : null;
        liveTrace = null;
        s.messages.push({ role: 'assistant', text: aiReply, trace });
        success = true;
        if (projectRef && !readSelfProfile()) scheduleSelfAnalysis(1500);
    } catch(e) {
        const trace = liveTrace ? liveTrace.finish(false) : null;
        liveTrace = null;
        s.messages.push({ role: 'assistant', text: '请求失败：\n' + e.message, trace });
    }
    if (success) pendingFiles = [];
    saveState();
    render();
    busy = false; $('#sendBtn').disabled = false; $('#sendBtn').textContent = '发送';
    if (success && text) {
        autoExtractMemory(text);
    }
}
function autoExtractMemory(userText) {
    if (!userText) return;
    const MEMORY_PATTERNS = [
        /(?:请?记住|帮我记住|记得)[:：]?\s*(.{2,80})/,
        /我叫([^\s，。！？,.!?；;]{1,20})/,
        /我的名字(?:是|叫)\s*([^\s，。！？,.!?；;]{1,20})/,
        /我是(?:一个|一名)?([^\s，。！？,.!?；;]{2,20})/,
        /我(?:喜欢|爱)\s*([^\s，。！？,.!?；;]{1,30})/,
        /我(?:不喜欢|讨厌)\s*([^\s，。！？,.!?；;]{1,30})/,
        /我偏好\s*([^\s，。！？,.!?；;]{1,30})/,
        /我(?:住在|来自)\s*([^\s，。！？,.!?；;]{1,20})/,
        /我(?:从事|的工作是)\s*([^\s，。！？,.!?；;]{1,30})/,
        /从现在开始[,，]?\s*(.{2,60})/,
        /以后都\s*(.{2,60})/
    ];
    for (const p of MEMORY_PATTERNS) {
        const m = userText.match(p);
        if (m && m[1]) {
            const candidate = String(m[1]).trim().replace(/[。！？.!?]+$/, '');
            if (candidate.length < 2 || candidate.length > 100) return;
            if (state.mem.includes(candidate)) return;
            setTimeout(() => {
                if (confirm('是否记住这条偏好/信息？\n\n' + candidate + '\n\n（保存后可随时在"记忆"页删除）')) {
                    state.mem.push(candidate);
                    saveState();
                    render();
                    toast('🧠 已记住：' + candidate, 'ok');
                }
            }, 120);
            return;
        }
    }
}
document.addEventListener('DOMContentLoaded', async function init(){
    const archBanner = $('#architectureBanner');
    const closeArchBanner = $('#closeArchitectureBanner');
    try {
        if(localStorage.getItem(ARCH_BANNER_STORE) === '1'){ if(archBanner) archBanner.remove(); }
        else if(archBanner && closeArchBanner){
            closeArchBanner.addEventListener('click',()=>{
                try{localStorage.setItem(ARCH_BANNER_STORE,'1');}catch(e){}
                archBanner.remove();
            });
        }
    }catch(e){}
    state = loadState();
    if (!state.sessions || !state.sessions.length) state.sessions = defaultState().sessions;
    state.active = state.sessions.some(x => x.id === state.active) ? state.active : state.sessions[0].id;
    if (!state.cfg) state.cfg = defaultState().cfg;
    if (!state.cfg.github) state.cfg.github = { token: '', user: '', repo: '' };
    $('#apiKey').value = state.cfg.apiKey || '';
    if ($('#lawBox')) $('#lawBox').value = state.cfg.coreLaw || '';
    $('#githubToken').value = state.cfg.github.token || '';
    $('#githubUser').value = state.cfg.github.user || '';
    $('#githubRepo').value = state.cfg.github.repo || '';
    let apiKeyTimer = null;
    $('#apiKey').oninput = () => {
        state.cfg.apiKey = sanitizeApiKey($('#apiKey').value);
        clearTimeout(apiKeyTimer);
        apiKeyTimer = setTimeout(() => saveState(), 400);
    };
    $('#apiKey').onblur = () => {
        clearTimeout(apiKeyTimer);
        state.cfg.apiKey = sanitizeApiKey($('#apiKey').value);
        saveState();
    };
    $('#rememberKeySwitch').checked = state.cfg.rememberKey !== false;
    $('#rememberKeySwitch').onchange = (e) => {
        state.cfg.rememberKey = e.target.checked;
        saveState();
        toast(e.target.checked ? '✅ 已开启：刷新后自动恢复 Key' : '🔒 已关闭：关闭页面后 Key 自动清空', 'ok');
    };
    $('#omniModeSwitch').onchange = () => { omniMode = $('#omniModeSwitch').checked; state.cfg.omniMode = omniMode; saveState(); toast(omniMode?'✅已开启全知全能模式':'已关闭全知模式','ok'); };
    $('#toolApprovalList').onclick = event => {
        const button = event.target.closest('[data-task-action]');
        if (!button) return;
        if (button.dataset.taskAction === 'allow') approveToolTask(button.dataset.taskId);
        if (button.dataset.taskAction === 'deny') denyToolTask(button.dataset.taskId);
    };
    $('#rejectAllToolTasks').onclick = rejectAllPendingToolTasks;
    $('#toggleHistoryBtn').onclick = () => { toolHistoryExpanded = !toolHistoryExpanded; renderApprovalQueue(); };
    $('#startNativeServices').onclick = async () => {
        const plugin = nativePlugin();
        if (!plugin) { toast('原生能力仅在 Android 安装版中可用', 'bad'); return; }
        try {
            const current = await plugin.getStatus();
            if (!current.notificationPermission) {
                toast('请在应用通知设置中允许通知，系统确认任务才可显示', 'bad');
                await plugin.openNotificationSettings();
                return;
            }
            const result = await plugin.startServices();
            if (result?.needsOverlayPermission) {
                toast('请在系统页面允许悬浮窗，然后返回并再次点击启用', 'bad');
                await plugin.openOverlayPermissionSettings();
            } else {
                toast('常驻服务已启动', 'ok');
            }
            setTimeout(refreshNativeStatus, 400);
        } catch (error) { toast(`无法启动原生服务：${error.message}`, 'bad'); }
    };
    $('#openAccessibilitySettings').onclick = async () => {
        const plugin = nativePlugin();
        if (!plugin) { toast('原生能力仅在 Android 安装版中可用', 'bad'); return; }
        try { await plugin.openAccessibilitySettings(); }
        catch (error) { toast(`无法打开无障碍设置：${error.message}`, 'bad'); }
    };
    const openOverlayBtn = $('#openOverlaySettings');
    if (openOverlayBtn) openOverlayBtn.onclick = async () => {
        const plugin = nativePlugin();
        if (!plugin) { toast('原生能力仅在 Android 安装版中可用', 'bad'); return; }
        try { await plugin.openOverlayPermissionSettings(); }
        catch (error) { toast(`无法打开悬浮窗设置：${error.message}`, 'bad'); }
    };
    const openNotifBtn = $('#openNotificationSettings');
    if (openNotifBtn) openNotifBtn.onclick = async () => {
        const plugin = nativePlugin();
        if (!plugin) { toast('原生能力仅在 Android 安装版中可用', 'bad'); return; }
        try { await plugin.openNotificationSettings(); }
        catch (error) { toast(`无法打开通知设置：${error.message}`, 'bad'); }
    };
    $('#stopNativeServices').onclick = async () => {
        const plugin = nativePlugin();
        if (!plugin) return;
        try { await plugin.stopServices(); toast('常驻服务已停止', 'ok'); refreshNativeStatus(); }
        catch (error) { toast(`无法停止原生服务：${error.message}`, 'bad'); }
    };
    // ===== 附近信号扫描 =====
    const scanBtn = $('#scanSignalsBtn');
    const exportSignalsBtn = $('#exportSignalsBtn');
    if (scanBtn) scanBtn.onclick = async () => {
        const plugin = nativePlugin();
        if (!plugin) { toast('信号扫描仅在 Android 安装版中可用', 'bad'); return; }
        scanBtn.disabled = true;
        scanBtn.textContent = '📡 扫描中…';
        const status = $('#signalScanStatus');
        if (status) status.textContent = '正在请求权限并扫描周围 WiFi 与蓝牙设备（约 4 秒）…';
        $('#signalSummary').style.display = 'none';
        $('#signalWifiList').innerHTML = '';
        $('#signalBleList').innerHTML = '';
        try {
            const result = await plugin.scanNearbySignals();
            lastSignalScanResult = result;
            renderSignalScanResult(result);
            if (exportSignalsBtn) exportSignalsBtn.disabled = false;
            if (status) status.textContent = `扫描完成：${result.summary?.wifiCount || 0} 个 WiFi，${result.summary?.bleCount || 0} 个蓝牙设备。`;
        } catch (error) {
            if (status) status.textContent = '扫描失败：' + error.message;
            toast('扫描失败：' + error.message, 'bad');
        } finally {
            scanBtn.disabled = false;
            scanBtn.textContent = '📡 开始扫描';
        }
    };
    if (exportSignalsBtn) exportSignalsBtn.onclick = () => {
        if (!lastSignalScanResult) return;
        const blob = new Blob([JSON.stringify(lastSignalScanResult, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `signal-scan-${Date.now()}.json`;
        a.click();
        URL.revokeObjectURL(url);
        toast('信号数据已导出为 JSON', 'ok');
    };
    const clearSignalsBtn = $('#clearSignalsBtn');
    if (clearSignalsBtn) clearSignalsBtn.onclick = () => {
        lastSignalScanResult = null;
        $('#signalScanStatus').textContent = '';
        $('#signalSummary').style.display = 'none';
        $('#signalSummary').innerHTML = '';
        $('#signalWifiList').innerHTML = '';
        $('#signalBleList').innerHTML = '';
        if (exportSignalsBtn) exportSignalsBtn.disabled = true;
        toast('已清除扫描结果', 'ok');
    };
    document.addEventListener('visibilitychange', () => {
        if (!document.hidden) {
            refreshNativeStatus();
            pendingToolTasks.filter(task => task.status === 'waitingDevice').forEach(pollNativeToolTask);
        }
    });
    refreshNativeStatus();
    $('#runSandboxCode').onclick = async ()=>{
        const code = $('#sandboxCodeInput').value.trim();
        if(!code) return;
        const outBox = $('#sandboxOutput');
        outBox.textContent = '已加入人工审批队列…';
        const outcome = await enqueueToolTask('code_run_js', { code }, '手动沙箱');
        outBox.textContent = outcome.ok ? `输出：${outcome.result}` : `未执行：${outcome.result}`;
    };
    $('#aiModeSelect').onchange = (e) => {
        state.cfg.aiMode = e.target.value;
        saveState(); render();
        toast('已切换到' + ({local:'本地模型直连模式',remote:'前端直连云端供应商'}[e.target.value] || e.target.value), 'ok');
    };
    $('#modeSelect').onchange = (e) => {
        state.meta.mode = e.target.value;
        saveState(); render();
        toast('已切换到' + (MODES[e.target.value] || e.target.value), 'ok');
    };
    $('#sendBtn').onclick = send;
    $('#prompt').onkeydown = (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } };
    $$('nav button').forEach(b => b.onclick = () => tab(b.dataset.tab));
    $('#newSessionBtn').onclick = () => {
        const count = state.sessions.length + 1;
        const id = Date.now().toString();
        state.sessions.unshift({ id, name: '对话 ' + count, messages: [] });
        state.active = id;
        saveState(); render(); toast('已创建新对话');
    };
    $('#deleteSessionBtn').onclick = () => removeSession(state.active);
    $('#sessionSelect').onchange = (e) => { state.active = e.target.value; saveState(); render(); };
    $('#uploadBtn').onclick = () => $('#fileInput').click();
    $('#fileInput').onchange = (e) => {
        const files = [...e.target.files];
        let total = pendingFiles.reduce((n, f) => n + (f.size || 0), 0);
        for (const f of files) {
            if (pendingFiles.length >= 5) { toast('最多上传 5 个文件', 'bad'); break; }
            if (f.size > 10 * 1024 * 1024) { toast(f.name + ' 超过 10MB', 'bad'); continue; }
            if (total + f.size > 20 * 1024 * 1024) { toast('文件总大小超过 20MB', 'bad'); break; }
            total += f.size;
            const archiveName = /\.(rar|7z|tar|gz|bz2|xz|tgz)$/i.test(f.name) || /application\/(?:x-7z-compressed|x-rar-compressed|x-tar|gzip|x-gzip)/i.test(f.type || '');
            if (archiveName && !/\.zip$/i.test(f.name) && f.type !== 'application/zip' && f.type !== 'application/x-zip-compressed') {
                toast(`${f.name}：目前只支持 ZIP 压缩包；RAR、7Z、TAR、GZ 暂不支持。`, 'bad');
                continue;
            }
            const reader = new FileReader();
            if (/\.zip$/i.test(f.name) || f.type === 'application/zip' || f.type === 'application/x-zip-compressed') {
                const entry = { name: `${f.name}（正在解析…）`, mime: 'text/plain', size: f.size, text: '', loading: true };
                pendingFiles.push(entry);
                render();
                entry.ready = extractZipText(f).then(result => {
                    const preview = result.files.map(x => `\n\n===== 文件：${x.name} =====\n${x.content}`).join('');
                    const skippedNote = result.skipped ? `\n另有 ${result.skipped} 个文件因类型、数量或安全限额而跳过。` : '';
                    entry.name = `${f.name}（已提取 ${result.files.length} 个文本文件）`;
                    entry.text = `ZIP 项目分析内容：\n压缩包：${f.name}\n提取文件数：${result.files.length}\n注意：仅提取文本内容，未执行压缩包中的任何代码。${skippedNote}${preview}`;
                    toast(`已安全提取 ${result.files.length} 个文本文件${result.skipped ? `，跳过 ${result.skipped} 项` : ''}`, 'ok');
                }).catch(error => {
                    pendingFiles = pendingFiles.filter(item => item !== entry);
                    toast(`${f.name} 解析失败：${error.message}`, 'bad');
                }).finally(() => {
                    entry.loading = false;
                    delete entry.ready;
                    render();
                });
                continue;
            }
            if (isTextFile(f)) {
                const entry = { name: f.name, mime: f.type || 'text/plain', size: f.size, text: '', loading: true };
                pendingFiles.push(entry);
                render();
                entry.ready = new Promise((resolve, reject) => {
                    reader.onload = () => resolve(String(reader.result || ''));
                    reader.onerror = () => reject(new Error(f.name + ' 读取失败'));
                    reader.readAsText(f);
                }).then(textContent => {
                    if (!textContent) throw new Error(f.name + ' 读取失败');
                    entry.text = textContent;
                }).catch(error => {
                    pendingFiles = pendingFiles.filter(item => item !== entry);
                    toast(error.message, 'bad');
                }).finally(() => {
                    entry.loading = false;
                    delete entry.ready;
                    render();
                });
            } else {
                const entry = { name: f.name, mime: f.type || 'application/octet-stream', size: f.size, loading: true };
                pendingFiles.push(entry);
                render();
                entry.ready = new Promise((resolve, reject) => {
                    reader.onload = () => resolve(String(reader.result || ''));
                    reader.onerror = () => reject(new Error(f.name + ' 读取失败'));
                    reader.readAsDataURL(f);
                }).then(dataUrl => {
                    const data = String(dataUrl).split(',')[1] || '';
                    if (!data) throw new Error(f.name + ' 读取失败');
                    entry.data = data;
                }).catch(error => {
                    pendingFiles = pendingFiles.filter(item => item !== entry);
                    toast(error.message, 'bad');
                }).finally(() => {
                    entry.loading = false;
                    delete entry.ready;
                    render();
                });
            }
        }
        e.target.value = '';
    };
    const Speech = window.SpeechRecognition || window.webkitSpeechRecognition;
    $('#voiceBtn').onclick = () => {
        if (!Speech) { toast('浏览器不支持语音识别', 'bad'); return; }
        if (recognition) { try { recognition.stop(); } catch(e) {} recognition = null; return; }
        recognition = new Speech();
        recognition.lang = 'zh-CN';
        recognition.interimResults = true;
        recognition.onresult = (ev) => {
            let t = '';
            for(let i=0;i<ev.results.length;i++) t+=ev.results[i][0].transcript;
            $('#prompt').value = t;
        };
        recognition.onend = ()=>{recognition=null;};
        recognition.onerror = ()=>{recognition=null;};
        recognition.start();
    };
    $('#providerSelect').onchange = () => {
        const nextProvider = $('#providerSelect').value;
        if (nextProvider === state.cfg.provider) return;
        state.cfg.provider = nextProvider;
        state.cfg.model = 'auto';
        state.cfg.models = [];
        state.cfg.apiKey = '';
        $('#apiKey').value = '';
        $('#modelSearchInput').value = '自动选择';
        $('#modelInfo').textContent = '提供商已切换，请输入对应服务商的 API Key。';
        saveState();
        if (!hydrateCachedModelList()) $('#modelInfo').textContent = '该提供商还没有模型列表，点一次「刷新模型列表」即可（之后不会再要求刷新）。';
        initModelSearch();
    };
    $('#saveGithubCfg').onclick = () => {
        try {
            if (!state.cfg.github) state.cfg.github = {};
            state.cfg.github.token = ($('#githubToken').value || '').trim();
            state.cfg.github.user = ($('#githubUser').value || '').trim();
            state.cfg.github.repo = ($('#githubRepo').value || '').trim();
            saveState();
            toast(state.cfg.github.token ? 'GitHub 配置已保存' : '请先填写 GitHub Token', state.cfg.github.token ? 'ok' : 'bad');
        } catch(e) { toast('保存失败：' + e.message, 'bad'); }
    };
    $('#saveCfg').onclick = () => {
        try {
            state.cfg.aiMode = $('#aiModeSelect').value;
            state.cfg.localEngine = $('#localEngine').value;
            state.cfg.backendUrl = ($('#backendUrl').value.trim() || (state.cfg.localEngine === 'lmstudio' ? 'http://127.0.0.1:1234' : 'http://127.0.0.1:11434')).replace(/\/$/, '');
            state.cfg.provider = $('#providerSelect').value;
            state.cfg.apiKey = getSanitizedApiKey($('#apiKey').value);
            const m = $('#modelSearchInput').value.trim();
            state.cfg.model = (!m || m === '自动选择') ? 'auto' : m;
            state.meta.mode = $('#modeSelect').value;
            saveState(); render(); toast('配置已保存', 'ok');
        } catch(e) { toast('保存失败：' + e.message, 'bad'); }
    };
    $('#tempRange').oninput = (e) => { state.cfg.temperature = parseFloat(e.target.value); $('#tempVal').textContent = state.cfg.temperature; };
    $('#tempRange').onchange = () => saveState();
    $('#maxTokensRange').oninput = (e) => { state.cfg.maxTokens = parseInt(e.target.value); $('#maxTokensVal').textContent = state.cfg.maxTokens; };
    $('#maxTokensRange').onchange = () => saveState();
    $('#ctxRange').oninput = (e) => { state.cfg.contextMessages = clampInt(e.target.value, 4, 40, 12); $('#ctxVal').textContent = state.cfg.contextMessages; };
    $('#ctxRange').onchange = () => saveState();
    $('#refreshModels').onclick = () => refreshModels(true);
    $('#addMcpServer').onclick = addMcpServerFromForm;
    $('#mcpServerList').onclick = handleMcpListClick;
    const searchProviderSel = $('#searchProvider');
    if (searchProviderSel) searchProviderSel.onchange = () => {
        state.cfg.searchProvider = searchProviderSel.value;
        syncSearchProviderUI();
    };
    const saveSearchBtn = $('#saveSearchBtn');
    if (saveSearchBtn) saveSearchBtn.onclick = () => {
        const keyInput = $('#searchApiKey');
        state.cfg.searchApiKey = keyInput ? keyInput.value.trim() : '';
        state.cfg.searchProvider = searchProviderSel ? searchProviderSel.value : 'builtin';
        saveState();
        toast('搜索设置已保存', 'ok');
    };
    const testSearchBtn = $('#testSearchBtn');
    if (testSearchBtn) testSearchBtn.onclick = () => {
        const keyInput = $('#searchApiKey');
        state.cfg.searchApiKey = keyInput ? keyInput.value.trim() : '';
        state.cfg.searchProvider = searchProviderSel ? searchProviderSel.value : 'builtin';
        testSearchConnection();
    };
    $('#checkBackendBtn').onclick = () => {
        state.cfg.localEngine = $('#localEngine').value;
        state.cfg.backendUrl = ($('#backendUrl').value.trim() || (state.cfg.localEngine === 'lmstudio' ? 'http://127.0.0.1:1234' : 'http://127.0.0.1:11434')).replace(/\/$/, '');
        saveState(); checkBackend();
    };
    $('#backendUrl').onchange = () => {
        state.cfg.localEngine = $('#localEngine').value;
        state.cfg.backendUrl = ($('#backendUrl').value.trim() || (state.cfg.localEngine === 'lmstudio' ? 'http://127.0.0.1:1234' : 'http://127.0.0.1:11434')).replace(/\/$/, '');
        saveState();
    };
    $('#showArchitectureBtn').onclick = () => { const el = $('#architectureInfo'); el.style.display = el.style.display === 'none' ? 'block' : 'none'; };
    $('#testCfg').onclick = async () => {
        try {
            if (isLocalMode()) {
                const cached = loadModelListCache('local');
                if (!cached) { await refreshModels(false); }
                else {
                    state.cfg.models = cached.models;
                    await probeModels(cached.models, true);
                    const c = summarizeModelProbe(cached.models);
                    $('#modelInfo').textContent = `连通性复测完成：可用 ${c.ok} · 限流 ${c.rate} · 不可用 ${c.fail}`;
                }
                toast('本地模型服务连接成功', 'ok');
                scheduleSelfAnalysis(600);
                return;
            }
            const k = getSanitizedApiKey($('#apiKey').value || state.cfg.apiKey);
            if (!k) { toast('请先输入 Key', 'bad'); return; }
            state.cfg.apiKey = k;
            let models = (state.cfg.models && state.cfg.models.length) ? state.cfg.models : (loadModelListCache(state.cfg.provider)?.models || []);
            saveState();
            if (!models.length) {
                // 该提供商从未成功拉取过列表：这里才请求一次并缓存，之后测试不再联网拉列表。
                await refreshModels(true);
                return;
            }
            $('#modelInfo').textContent = `正在复测 ${models.length} 个模型…`;
            await probeModels(models, true);
            const counts = summarizeModelProbe(models);
            $('#modelInfo').textContent = `测试完成：可用 ${counts.ok} · 限流 ${counts.rate} · 不可用 ${counts.fail}（列表保持缓存，可反复测试）`;
            initModelSearch();
            toast(`连接正常：可用 ${counts.ok} 个`, counts.ok ? 'ok' : 'bad');
            if (counts.ok) scheduleSelfAnalysis(600);
        } catch(e) { $('#modelInfo').textContent = '连接失败：' + e.message; toast('连接失败：' + e.message, 'bad'); }
    };
    $('#exportMemoryZip').onclick = async () => {
        try {
            if (!window.fflate || typeof window.fflate.zipSync !== 'function') throw new Error('ZIP 组件未加载');
            const bundle = { format: 'guling-memory-bundle', version: 1, exportedAt: new Date().toISOString(), memory: state.mem };
            const bytes = window.fflate.zipSync({ 'guling-memory.json': window.fflate.strToU8(JSON.stringify(bundle, null, 2)) });
            const blob = new Blob([bytes], { type: 'application/zip' });
            const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = `guling-memory-${Date.now()}.zip`; a.click();
            setTimeout(() => URL.revokeObjectURL(a.href), 1500);
            toast(`已导出 ${state.mem.length} 条本地记忆 ZIP`, 'ok');
        } catch (e) { toast('记忆 ZIP 导出失败：' + e.message, 'bad'); }
    };
    function bytesToBase64(bytes) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onerror = () => reject(new Error('读取 ZIP 失败'));
            reader.onload = () => resolve(String(reader.result || '').split(',')[1] || '');
            reader.readAsDataURL(new Blob([bytes], { type: 'application/zip' }));
        });
    }
    async function saveApkBytesToDownloads(bytes) {
        const plugin = nativePlugin();
        if (!plugin || typeof plugin.saveApkToDownloads !== 'function') {
            toast('当前版本不支持自动保存 APK；请手动下载安装', 'bad');
            return null;
        }
        return await plugin.saveApkToDownloads({ base64: await bytesToBase64(bytes) });
    }
    async function openBuiltApkInstaller() {
        const plugin = nativePlugin();
        if (!plugin || typeof plugin.installBuiltApk !== 'function') {
            toast('APK 已生成，请在 Download/GulingBuild 中手动安装', 'ok');
            return;
        }
        for (let attempt = 0; attempt < 3; attempt++) {
            try {
                await plugin.installBuiltApk();
                toast('已打开系统安装器，请确认安装', 'ok');
                return;
            } catch (e) {
                if (attempt === 2) {
                    toast('自动打开安装器失败：' + e.message + '；请在 Download/GulingBuild 中手动安装', 'bad');
                    return;
                }
                await new Promise(resolve => setTimeout(resolve, 1500));
            }
        }
    }
    const GITHUB_API = 'https://api.github.com';
    const GITHUB_WORKFLOW_YML = `name: Build APK
on:
  push:
    paths:
      - 'guling-project.zip'
      - '.github/workflows/build.yml'
  workflow_dispatch:
jobs:
  build:
    runs-on: ubuntu-latest
    env:
      ANDROID_HOME: /usr/local/lib/android/sdk
      ANDROID_SDK_ROOT: /usr/local/lib/android/sdk
    steps:
      - uses: actions/checkout@v4
      - name: Setup Node
        uses: actions/setup-node@v4
        with:
          node-version: '20'
      - name: Setup JDK 17
        uses: actions/setup-java@v4
        with:
          distribution: 'temurin'
          java-version: '17'
      - name: Install Android SDK components
        run: |
          export PATH="$ANDROID_HOME/cmdline-tools/latest/bin:$PATH"
          yes | sdkmanager --licenses >/dev/null 2>&1 || true
          sdkmanager "platform-tools" "build-tools;34.0.0" "platforms;android-34"
      - name: Unzip project
        run: |
          mkdir -p source
          unzip -oq guling-project.zip -d source
          ROOT=$(find source -name package.json -type f -not -path "*/node_modules/*" -not -path "*/build/*" | head -n 1 | sed "s#/package.json##")
          echo "PROJECT_ROOT=$ROOT" >> $GITHUB_ENV
      - name: Install dependencies
        run: |
          cd "$PROJECT_ROOT"
          npm install --no-audit --no-fund
      - name: Run self-checks
        run: |
          cd "$PROJECT_ROOT"
          npm test
      - name: Sync Android
        run: |
          cd "$PROJECT_ROOT"
          npx cap sync android
      - name: Register native plugin
        run: |
          cd "$PROJECT_ROOT"
          node scripts/register-native-plugin.cjs
      - name: Build APK
        run: |
          cd "$PROJECT_ROOT/android"
          chmod +x gradlew
          ./gradlew assembleDebug
      - name: Upload APK
        uses: actions/upload-artifact@v4
        with:
          name: guling-omni-apk
          path: \${{ env.PROJECT_ROOT }}/android/app/build/outputs/apk/debug/*.apk
`;
    function githubHeaders() {
        const token = (state.cfg.github && state.cfg.github.token) || '';
        if (!token) throw new Error('未配置 GitHub Token，请先在自我更新卡片中填写并保存。');
        return {
            'Authorization': 'Bearer ' + token,
            'Accept': 'application/vnd.github+json',
            'X-GitHub-Api-Version': '2022-11-28',
            'Content-Type': 'application/json'
        };
    }
    async function githubEnsureRepo() {
        const gh = state.cfg.github || {};
        if (!gh.token) throw new Error('未配置 GitHub Token');
        if (!gh.user) throw new Error('未配置 GitHub 用户名');
        const repo = gh.repo && gh.repo.trim() ? gh.repo.trim() : 'guling-omni-build';
        const owner = gh.user.trim();
        // 检查仓库是否存在，不存在则创建
        try {
            await fetch(`${GITHUB_API}/repos/${owner}/${repo}`, { headers: githubHeaders() });
        } catch (e) {
            // 网络错误，直接抛
            throw e;
        }
        const check = await fetch(`${GITHUB_API}/repos/${owner}/${repo}`, { headers: githubHeaders() });
        if (check.status === 404) {
            const create = await fetch(`${GITHUB_API}/user/repos`, {
                method: 'POST',
                headers: githubHeaders(),
                body: JSON.stringify({ name: repo, private: true, auto_init: true })
            });
            if (create.status >= 300) {
                const err = await create.text();
                throw new Error('创建仓库失败(' + create.status + ')：' + err.slice(0, 300));
            }
        } else if (check.status >= 300) {
            throw new Error('访问仓库失败(' + check.status + ')');
        }
        return { owner, repo };
    }
    async function githubPutFile(owner, repo, path, contentBytes, message) {
        const b64 = await bytesToBase64(contentBytes);
        // 先获取现有文件的 sha（用于更新）
        let sha = null;
        const get = await fetch(`${GITHUB_API}/repos/${owner}/${repo}/contents/${path}`, { headers: githubHeaders() });
        if (get.status === 200) {
            const data = await get.json();
            sha = data.sha;
        }
        const body = { message, content: b64 };
        if (sha) body.sha = sha;
        const resp = await fetch(`${GITHUB_API}/repos/${owner}/${repo}/contents/${path}`, {
            method: 'PUT',
            headers: githubHeaders(),
            body: JSON.stringify(body)
        });
        if (resp.status >= 300) {
            const err = await resp.text();
            throw new Error(`上传 ${path} 失败(${resp.status})：` + err.slice(0, 300));
        }
    }
    async function githubWaitForRun(owner, repo, afterTs) {
        // 等待 workflow run 出现并完成
        const deadline = Date.now() + 30 * 60 * 1000;
        let runId = null;
        while (Date.now() < deadline) {
            const list = await fetch(`${GITHUB_API}/repos/${owner}/${repo}/actions/runs?per_page=5`, { headers: githubHeaders() });
            if (list.status === 200) {
                const data = await list.json();
                const runs = (data.workflow_runs || []).filter(r => r.created_at && new Date(r.created_at).getTime() >= afterTs - 5000);
                if (runs.length) {
                    runId = runs[0].id;
                    break;
                }
            }
            await new Promise(r => setTimeout(r, 8000));
        }
        if (!runId) throw new Error('未检测到 GitHub Actions 构建任务，可能触发失败。');
        // 轮询 run 状态
        while (Date.now() < deadline) {
            const run = await fetch(`${GITHUB_API}/repos/${owner}/${repo}/actions/runs/${runId}`, { headers: githubHeaders() });
            if (run.status === 200) {
                const data = await run.json();
                if (data.status === 'completed') {
                    if (data.conclusion === 'success') return runId;
                    throw new Error('GitHub Actions 构建失败：' + (data.conclusion || 'unknown') + '。请到仓库 Actions 页面查看日志。');
                }
            }
            await new Promise(r => setTimeout(r, 10000));
        }
        throw new Error('等待 GitHub Actions 构建超时（30 分钟）。');
    }
    async function githubDownloadApk(owner, repo, runId) {
        // 列出 artifacts
        const arts = await fetch(`${GITHUB_API}/repos/${owner}/${repo}/actions/runs/${runId}/artifacts`, { headers: githubHeaders() });
        if (arts.status !== 200) throw new Error('获取构建产物失败');
        const data = await arts.json();
        const artifact = (data.artifacts || []).find(a => a.name === 'guling-omni-apk');
        if (!artifact) throw new Error('未找到 APK 构建产物');
        // 下载 artifact zip
        const dl = await fetch(`${GITHUB_API}/repos/${owner}/${repo}/actions/artifacts/${artifact.id}/zip`, {
            headers: { ...githubHeaders(), 'Accept': 'application/vnd.github+json' }
        });
        if (dl.status >= 300) throw new Error('下载 APK 产物失败(' + dl.status + ')');
        const zipBytes = new Uint8Array(await dl.arrayBuffer());
        // 解压出 APK
        if (!window.fflate) throw new Error('ZIP 组件未加载');
        const unzipped = window.fflate.unzipSync(zipBytes);
        const apkEntry = Object.keys(unzipped).find(k => k.endsWith('.apk'));
        if (!apkEntry) throw new Error('产物中未找到 APK 文件');
        return unzipped[apkEntry];
    }
    async function buildApkViaGitHub({ confirmBuild = true, installAfter = true } = {}) {
        if (!termuxProjectZipUploaded) { toast('请先上传项目 ZIP', 'bad'); return; }
        const gh = state.cfg.github || {};
        if (!gh.token || !gh.user) { toast('请先填写并保存 GitHub Token 和用户名', 'bad'); return; }
        if (confirmBuild && !confirm('将上传项目到 GitHub 并触发 Actions 构建 APK。首次推送会下载 Gradle 依赖，通常需要 5-15 分钟。继续吗？')) return;
        const output = $('#termuxBuildOutput');
        const button = $('#termuxBuildApkBtn'); button.disabled = true;
        try {
            output.textContent = '正在连接 GitHub 并准备仓库…';
            const { owner, repo } = await githubEnsureRepo();
            output.textContent = `仓库已就绪：${owner}/${repo}，正在上传项目包…`;
            const pushTs = Date.now();
            await githubPutFile(owner, repo, '.github/workflows/build.yml', new TextEncoder().encode(GITHUB_WORKFLOW_YML), 'chore: add build workflow');
            await githubPutFile(owner, repo, 'guling-project.zip', projectZipBytes, 'build: update project zip');
            output.textContent = '项目已上传，正在等待 GitHub Actions 构建（首次约 5-15 分钟）…';
            const runId = await githubWaitForRun(owner, repo, pushTs);
            output.textContent = '构建成功，正在下载 APK…';
            const apkBytes = await githubDownloadApk(owner, repo, runId);
            output.textContent = `APK 已下载（${(apkBytes.length / 1024 / 1024).toFixed(2)} MB），正在保存并打开安装器…`;
            await saveApkBytesToDownloads(apkBytes);
            toast('APK 构建完成，正在打开系统安装器', 'ok');
            if (installAfter) await openBuiltApkInstaller();
        } catch (e) {
            output.textContent = 'GitHub 构建失败：' + e.message;
            toast('构建失败：' + e.message, 'bad');
        } finally {
            button.disabled = !termuxProjectZipUploaded;
        }
    }
    async function runAssistantTurn(userText) {
        const session = getActiveSession();
        session.messages.push({ role: 'user', text: userText });
        saveState(); render();
        const result = await callAI(userText, []);
        const reply = String(result?.text || '').trim();
        if (!reply) throw new Error('模型返回空内容');
        session.messages.push({ role: 'assistant', text: reply });
        saveState(); render();
        return reply;
    }
    function readSavedProjectSuggestion() {
        try {
            const saved = JSON.parse(localStorage.getItem('guling_project_suggestion_v1') || 'null');
            return saved && saved.text ? String(saved.text) : '';
        } catch (_) { return ''; }
    }
    async function runProjectAnalysis() {
        if (!(await verifyMaster())) return;
        if (!projectRef || !projectRef.files.length) { toast('请先上传可解析的项目 ZIP', 'bad'); return; }
        if (busy) { toast('古灵正在处理其他任务，请稍候', 'bad'); return; }
        const analyzeBtn = $('#termuxAnalyzeProject');
        const buildBtn = $('#termuxBuildApkBtn');
        const output = $('#termuxBuildOutput');
        busy = true;
        if (analyzeBtn) { analyzeBtn.disabled = true; analyzeBtn.textContent = '② 正在分析…'; }
        if (buildBtn) buildBtn.disabled = true;
        tab('chat');
        if (output) output.textContent = '正在让古灵阅读项目并生成功能建议…';
        try {
            const prompt = `请分析我永久保存的项目「${projectRef.name}」，并提出可增加的工具与使用功能建议。
要求：
1. 提出 3-8 条具体、可落地的建议；
2. 每条写明：功能名称、用户价值、涉及文件、实现要点、风险；
3. 只能基于项目现状，不得编造已存在的功能；
4. 不要输出完整代码或补丁，只输出建议。
需要查看更多文件时，可使用 project_list / project_search / project_read。

项目清单：
${projectManifestText(8000)}

关键源码：
${projectSourceBundle(40000)}`;
            const reply = await runAssistantTurn(prompt);
            lastProjectSuggestion = reply;
            try { localStorage.setItem('guling_project_suggestion_v1', JSON.stringify({ text: reply, project: projectRef.name, at: Date.now() })); } catch (_) {}
            if (output) output.textContent = '分析完成，建议已显示在对话中。确认后点击 ③ 生成新版本并构建。';
            toast('古灵已完成项目分析', 'ok');
        } catch (e) {
            if (output) output.textContent = '项目分析失败：' + e.message;
            toast('项目分析失败：' + e.message, 'bad');
        } finally {
            busy = false;
            if (analyzeBtn) { analyzeBtn.disabled = !projectRef || !projectRef.files.length; analyzeBtn.textContent = '② 让古灵分析项目并提出功能建议'; }
            if (buildBtn) buildBtn.disabled = !termuxProjectZipUploaded;
        }
    }
    async function generateNewVersionAndBuild() {
        if (!(await verifyMaster())) return;
        if (!projectRef || !projectZipBytes) { toast('请先上传项目 ZIP', 'bad'); return; }
        if (busy) { toast('古灵正在处理其他任务，请稍候', 'bad'); return; }
        const suggestion = lastProjectSuggestion || readSavedProjectSuggestion();
        if (!suggestion) { toast('请先点击第②步，让古灵分析项目并提出建议', 'bad'); return; }
        if (!confirm('古灵将根据建议修改代码、重新打包，然后上传到 GitHub 触发 Actions 构建 APK。构建会联网下载依赖，通常需要 5-15 分钟。继续吗？')) return;
        const buildBtn = $('#termuxBuildApkBtn');
        const analyzeBtn = $('#termuxAnalyzeProject');
        const output = $('#termuxBuildOutput');
        const previousMaxTokens = state.cfg.maxTokens;
        busy = true;
        if (buildBtn) { buildBtn.disabled = true; buildBtn.textContent = '③ 正在生成新版本…'; }
        if (analyzeBtn) analyzeBtn.disabled = true;
        if (output) output.textContent = '正在让古灵根据建议修改代码…';
        try {
            // 代码生成需要更长的输出上限；结束后恢复创造者在设置中的值。
            state.cfg.maxTokens = Math.max(previousMaxTokens, 8192);
            const prompt = `下面是项目清单、关键源码和上次的功能建议。请根据建议直接修改代码并输出新版本。
输出要求：
1. 只输出一个 \`\`\`guling-files 代码块，内容为 JSON：{"files":[{"path":"相对路径","content":"完整文件内容"}]}；
2. files 中只放新增或修改的文件，content 必须是完整可运行文件，禁止省略或用“…”占位；
3. 不要输出补丁，不要输出解释性代码块；
4. 保持原有架构与接口，改动尽可能小；
5. path 使用项目内相对路径。

上次建议：
${suggestion}

项目清单：
${projectManifestText(8000)}

关键源码：
${projectSourceBundle(50000)}`;
            const reply = await runAssistantTurn(prompt);
            const files = parseProjectFiles(reply);
            if (!files) throw new Error('模型没有返回 guling-files 代码块，可能输出被截断或格式错误。请重试或改用支持更长输出的模型。');
            if (output) output.textContent = `已生成 ${files.length} 个文件，正在重新打包…`;
            const bytes = applyProjectFilesToZip(files);
            if (bytes.byteLength > 27 * 1024 * 1024) throw new Error('新项目 ZIP 超过 27 MB');
            const merged = new Map(projectRef.files.map(item => [item.name, item.content]));
            files.forEach(item => merged.set(item.path, item.content));
            projectRef = {
                name: projectRef.name,
                files: [...merged].map(([name, content]) => ({ name, content })),
                skipped: projectRef.skipped,
                at: new Date().toISOString()
            };
            projectZipBytes = bytes;
            termuxProjectZipUploaded = true;
            try { await saveProjectRecord({ name: projectRef.name, bytes, at: projectRef.at }); } catch (error) { console.warn('新版本永久保存失败', error); }
            if (output) output.textContent = '新版本已打包，正在上传 GitHub 并构建…';
            updateProjectUi('已生成新版本');
            toast('新版本已生成，开始 GitHub 构建', 'ok');
            await buildApkViaGitHub({ confirmBuild: false, installAfter: true });
        } catch (e) {
            if (output) output.textContent = '生成新版本失败：' + e.message;
            toast('生成新版本失败：' + e.message, 'bad');
        } finally {
            state.cfg.maxTokens = previousMaxTokens;
            busy = false;
            if (buildBtn) { buildBtn.disabled = !termuxProjectZipUploaded; buildBtn.textContent = '③ 按建议生成新版本并由 GitHub 构建 APK'; }
            if (analyzeBtn) analyzeBtn.disabled = !projectRef || !projectRef.files.length;
        }
    }
    $('#termuxUploadProjectZip').onclick = () => $('#termuxProjectZipInput').click();
    $('#termuxProjectZipInput').onchange = async (event) => {
        const file = event.target.files && event.target.files[0];
        if (!file) return;
        const statusEl = $('#termuxUploadStatus');
        const buildBtn = $('#termuxBuildApkBtn');
        buildBtn.disabled = true; termuxProjectZipUploaded = false;
        try {
            if (!/\.zip$/i.test(file.name) || file.size < 100 || file.size > 27 * 1024 * 1024) throw new Error('请选择有效 ZIP，大小不能超过 27 MB。');
            const bytes = new Uint8Array(await file.arrayBuffer());
            statusEl.textContent = `正在解析 ${file.name}（${(file.size / 1024 / 1024).toFixed(2)} MB）…`;
            let parsed = { files: [], skipped: 0 };
            let parseError = null;
            try { parsed = await parseProjectBytes(bytes); } catch (error) { parseError = error; }
            projectZipBytes = bytes;
            projectRef = { name: file.name, files: parsed.files, skipped: parsed.skipped, at: new Date().toISOString() };
            termuxProjectZipUploaded = true;
            let persistenceNote = '已永久保存';
            try {
                await saveProjectRecord({ name: file.name, bytes, at: projectRef.at });
            } catch (error) {
                persistenceNote = '永久保存失败：' + error.message;
            }
            updateProjectUi(persistenceNote);
            statusEl.textContent = `${persistenceNote}：${file.name}（${(file.size / 1024 / 1024).toFixed(2)} MB，${parsed.files.length} 个文本文件）${parseError ? '；源码解析失败：' + parseError.message : '；古灵随时可读取源码'}`;
            $('#termuxBuildOutput').textContent = '项目 ZIP 已永久保存。可先让古灵分析并提出功能建议，确认后点击 ③ 上传 GitHub 构建。';
            toast('项目 ZIP 已永久保存', 'ok');
            scheduleSelfAnalysis(800);
        } catch (e) {
            statusEl.textContent = '上传失败：' + e.message;
            toast('项目 ZIP 上传失败：' + e.message, 'bad');
            if (projectZipBytes) { termuxProjectZipUploaded = true; buildBtn.disabled = false; }
        }
        finally { event.target.value = ''; }
    };
    $('#termuxAnalyzeProject').onclick = () => runProjectAnalysis();
    $('#selfAwareReanalyze').onclick = () => {
        if (!projectRef || !projectRef.files.length) { toast('请先上传项目 ZIP', 'bad'); return; }
        if (selfAnalysisRunning) { toast('正在分析中，请稍候', 'bad'); return; }
        const configured = isLocalMode() ? !!state.cfg.backendUrl : !!state.cfg.apiKey;
        if (!configured) { toast('请先接入模型（填写 Key 并测试连接）', 'bad'); return; }
        runSelfAnalysis('manual');
    };
    $('#termuxBuildApkBtn').onclick = () => generateNewVersionAndBuild();
    $('#saveMem').onclick = () => {
        const t = $('#newMem').value.trim();
        if (!t) return;
        state.mem.push(t);
        $('#newMem').value = '';
        saveState(); render(); toast('记忆已保存');
    };
    $('#ruleEditorSave').onclick = saveRuleEdit;
    $('#ruleEditorCancel').onclick = cancelRuleEdit;
    $('#addRuleBtn').onclick = () => {
        const t = $('#newRule').value.trim();
        if (!t) return;
        state.cfg.coreRules.push(t);
        state.cfg.rulesVersion = 'custom';
        $('#newRule').value = '';
        saveState(); render(); toast('规则已添加');
    };
    $('#resetRulesBtn').onclick = async () => {
        if (!(await verifyMaster())) return;
        if (!confirm(`重置为默认 1 条规律 + ${DEFAULT_RULES.length} 条规则？你手动改过的规则会被覆盖，角色卡不受影响。`)) return;
        state.cfg.coreLaw = DEFAULT_LAW;
        state.cfg.coreRules = [...DEFAULT_RULES];
        state.cfg.rulesVersion = RULES_VERSION;
        saveState(); render();
        toast('规则已重置为默认', 'ok');
    };
    $('#exportData').onclick = async () => {
        if (!(await verifyMaster())) return;
        const cfgCopy = JSON.parse(JSON.stringify(state.cfg));
        delete cfgCopy.apiKey;
        delete cfgCopy.searchApiKey;
        cfgCopy.mcpServers = (cfgCopy.mcpServers || []).map(server => ({ ...server, token: '' }));
        const data = { sessions: state.sessions, mem: state.mem, cfg: cfgCopy, meta: state.meta, exportTime: new Date().toISOString(), version: VERSION };
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = `guling-omni-${Date.now()}.json`;
        a.click();
        setTimeout(() => URL.revokeObjectURL(a.href), 1000);
        toast('已导出全部数据（API Key 已剥离）', 'ok');
    };
    $('#importDataBtn').onclick = async () => { if (!(await verifyMaster())) return; $('#importDataInput').click(); };
    $('#importDataInput').onchange = async (e) => {
        const f = e.target.files[0];
        if (!f) return;
        try {
            const d = JSON.parse(await f.text());
            if (d.sessions) state.sessions = d.sessions;
            if (Array.isArray(d.mem)) state.mem = d.mem;
            if (d.cfg) state.cfg = { ...state.cfg, ...d.cfg };
            if (d.meta) state.meta = d.meta;
            if (!state.sessions || !state.sessions.length) state.sessions = defaultState().sessions;
            if (!Array.isArray(state.cfg.coreRules) || !state.cfg.coreRules.length) state.cfg.coreRules = [...DEFAULT_RULES];
            delete state.cfg.autoToolConfirm;
            state.active = state.sessions.some(x => x.id === state.active) ? state.active : state.sessions[0].id;
            omniMode = !!state.cfg.omniMode;
            saveState(); render();
            $('#apiKey').value = state.cfg.apiKey || '';
            if ($('#lawBox')) $('#lawBox').value = state.cfg.coreLaw || '';
            toast('数据已导入', 'ok');
        } catch(err) { toast('导入失败：' + err.message, 'bad'); }
        e.target.value = '';
    };
    $('#clearAll').onclick = async () => {
        if (!(await verifyMaster())) return;
        if (!confirm('⚠️ 清空所有本地数据（会话、记忆、规则、配置、密钥）？此操作不可恢复。')) return;
        [STORE, BACKUP_STORE, 'guling_usage'].forEach(k => { try { localStorage.removeItem(k); } catch(e) {} });
        state = defaultState(); omniMode = false;
        saveState(); render();
        $('#apiKey').value = ''; if ($('#lawBox')) $('#lawBox').value = state.cfg.coreLaw;
        toast('本地数据已清空', 'ok');
    };
    $('#restoreBackup').onclick = async () => {
        if (!(await verifyMaster())) return;
        const raw = localStorage.getItem(BACKUP_STORE);
        if (!raw) { toast('暂无备份', 'bad'); return; }
        if (!confirm('用自动备份覆盖当前数据？（API Key 不会恢复）')) return;
        try {
            const d = JSON.parse(raw);
            delete d.__backupTime;
            if (d.sessions) state.sessions = d.sessions;
            if (Array.isArray(d.mem)) state.mem = d.mem;
            if (d.cfg) state.cfg = { ...state.cfg, ...d.cfg };
            if (d.meta) state.meta = d.meta;
            delete state.cfg.autoToolConfirm;
            state.active = state.sessions.some(x => x.id === state.active) ? state.active : state.sessions[0].id;
            omniMode = !!state.cfg.omniMode;
            saveState(); render();
            if (!state.cfg.apiKey) {
                toast('备份已恢复（API Key 因安全原因未备份，请重新输入）', 'ok');
            } else {
                toast('备份已恢复', 'ok');
            }
        } catch(e) { toast('恢复失败：' + e.message, 'bad'); }
    };
    $('#runSelfCheck').onclick = () => runLocalSelfCheck().catch(e => { const out = $('#selfCheckOutput'); if (out) out.textContent = '自检发生异常：' + e.message; });
    $('#resetState').onclick = async () => {
        if (!(await verifyMaster())) return;
        if (!confirm('清除运行状态（保持配置与数据）？')) return;
        verified = false; busy = false; pendingFiles = [];
        render(); toast('运行状态已清除', 'ok');
    };
    initMiniMode();
    initKeyboardFix();
    render();
    await restorePersistedProject().catch(() => {});
    bootstrapSelfAwareness();
    if (mcpServers().some(server => server.enabled)) {
        setTimeout(() => refreshAllMcpServers(false).catch(() => {}), 1200);
    }
    writeAutoBackup(true);
    setInterval(() => writeAutoBackup(true), 24 * 60 * 60 * 1000);
    window.addEventListener('beforeunload', () => writeAutoBackup(true));
    if (isLocalMode()) checkBackend().catch(() => {});
    if (!isLocalMode() && state.cfg.apiKey) refreshModels(false).catch(() => {});
});
