(function (root, factory) {
    if (typeof module === 'object' && module.exports) {
        module.exports = factory(require('fflate'));
    } else {
        root.GulingZipReader = factory(root.fflate);
    }
})(typeof globalThis !== 'undefined' ? globalThis : this, function (fflate) {
    'use strict';

    const LIMITS = Object.freeze({
        archiveBytes: 10 * 1024 * 1024,
        entries: 5000,
        files: 250,
        perFileBytes: 1024 * 1024,
        totalBytes: 4 * 1024 * 1024,
        timeoutMs: 30000
    });
    const IGNORED = /(^|\/)(node_modules|\.git|\.gradle|build|dist|\.idea|vendor|target)(\/|$)/i;
    const TEXT_EXT = /\.(txt|md|markdown|json|csv|tsv|log|xml|html?|ya?ml|ini|conf|env|m?js|tsx?|jsx?|py|java|c|cc|cpp|h|hpp|cs|go|rs|rb|php|css|scss|less|sh|sql|vue|svelte|toml|properties|gradle|kt|kts|swift|dart|bat|ps1|gitignore|dockerfile)$/i;

    function normalizeName(raw) {
        return String(raw || '').replace(/\\/g, '/').replace(/^\.\//, '');
    }

    function isSafeTextPath(name) {
        const parts = name.split('/');
        if (!name || name.length > 500 || name.startsWith('/') || /^[a-z]:/i.test(name) || parts.some(part => part === '..')) return false;
        if (name.endsWith('/') || IGNORED.test(name) || !TEXT_EXT.test(name)) return false;
        return true;
    }

    function extractZipTextFromBytes(input) {
        if (!fflate || typeof fflate.Unzip !== 'function') return Promise.reject(new Error('ZIP 解压组件未加载，请重新安装或更新应用。'));
        const bytes = input instanceof Uint8Array ? input : new Uint8Array(input);
        if (!bytes.length) return Promise.reject(new Error('ZIP 文件为空。'));
        if (bytes.byteLength > LIMITS.archiveBytes) return Promise.reject(new Error('ZIP 压缩包超过 10MB 安全上限。'));

        return new Promise((resolve, reject) => {
            let unzip;
            let pending = 0;
            let seenEntries = 0;
            let actualTotal = 0;
            let pushed = false;
            let settled = false;
            let skipped = 0;
            const startedAt = Date.now();
            const results = [];
            const active = new Set();
            const decoder = new TextDecoder('utf-8', { fatal: false });
            const timer = setTimeout(() => fail(new Error('ZIP 解压超过 30 秒，已中止以保护设备。')), LIMITS.timeoutMs);

            function cleanup() {
                clearTimeout(timer);
                for (const stream of active) {
                    try { stream.terminate?.(); } catch (_) {}
                }
                active.clear();
            }
            function fail(error) {
                if (settled) return;
                settled = true;
                cleanup();
                reject(error instanceof Error ? error : new Error(String(error || 'ZIP 解压失败。')));
            }
            function finishIfReady() {
                if (settled || !pushed || pending !== 0) return;
                settled = true;
                cleanup();
                if (!results.length) {
                    reject(new Error('压缩包中没有可读取的文本文件。当前支持 ZIP（Store/Deflate）中的文本源码和文档；RAR、7Z 等格式暂不支持。'));
                    return;
                }
                resolve({ files: results, skipped });
            }
            function skipStream(stream, state) {
                if (state.done) return;
                state.done = true;
                actualTotal = Math.max(0, actualTotal - state.bytes);
                state.chunks.length = 0;
                skipped++;
                active.delete(stream);
                try { stream.terminate?.(); } catch (_) {}
                pending = Math.max(0, pending - 1);
                finishIfReady();
            }

            try {
                // 单线程分块解压，避免恶意归档通过大量条目启动大量 Worker。
                const useAsync = false;
                unzip = new fflate.Unzip(file => {
                    seenEntries++;
                    if (seenEntries > LIMITS.entries) {
                        fail(new Error('ZIP 文件数量超过 5000 项安全上限。'));
                        return;
                    }
                    const name = normalizeName(file.name);
                    if (!isSafeTextPath(name) || results.length >= LIMITS.files) {
                        skipped++;
                        return;
                    }
                    const declaredSize = Number(file.originalSize);
                    if (Number.isFinite(declaredSize) && declaredSize > LIMITS.perFileBytes) {
                        skipped++;
                        return;
                    }
                    if (file.compression !== 0 && file.compression !== 8) {
                        skipped++;
                        return;
                    }
                    if (file.compression === 8 && !useAsync && typeof fflate.UnzipInflate !== 'function') {
                        skipped++;
                        return;
                    }
                    const streamState = { chunks: [], bytes: 0, done: false };
                    file.ondata = (error, chunk, final) => {
                        if (streamState.done || settled) return;
                        if (Date.now() - startedAt > LIMITS.timeoutMs) {
                            fail(new Error('ZIP 解压超过 30 秒，已中止以保护设备。'));
                            return;
                        }
                        if (error) {
                            skipStream(file, streamState);
                            return;
                        }
                        if (chunk && chunk.byteLength) {
                            const nextFile = streamState.bytes + chunk.byteLength;
                            const nextTotal = actualTotal + chunk.byteLength;
                            if (nextFile > LIMITS.perFileBytes || nextTotal > LIMITS.totalBytes) {
                                skipStream(file, streamState);
                                return;
                            }
                            streamState.chunks.push(chunk);
                            streamState.bytes = nextFile;
                            actualTotal = nextTotal;
                        }
                        if (final) {
                            streamState.done = true;
                            active.delete(file);
                            const joined = new Uint8Array(streamState.bytes);
                            let offset = 0;
                            for (const part of streamState.chunks) {
                                joined.set(part, offset);
                                offset += part.byteLength;
                            }
                            const content = decoder.decode(joined);
                            if (!content.includes('\u0000')) results.push({ name, content });
                            else {
                                actualTotal = Math.max(0, actualTotal - streamState.bytes);
                                skipped++;
                            }
                            streamState.chunks.length = 0;
                            pending = Math.max(0, pending - 1);
                            finishIfReady();
                        }
                    };
                    pending++;
                    active.add(file);
                    try { file.start(); }
                    catch (_) {
                        skipStream(file, streamState);
                    }
                });
                if (typeof fflate.UnzipPassThrough === 'function') unzip.register(fflate.UnzipPassThrough);
                if (typeof fflate.UnzipInflate === 'function') unzip.register(useAsync ? fflate.AsyncUnzipInflate : fflate.UnzipInflate);
                unzip.push(bytes, true);
                if (Date.now() - startedAt > LIMITS.timeoutMs) {
                    fail(new Error('ZIP 解压超过 30 秒，已中止以保护设备。'));
                    return;
                }
                pushed = true;
                finishIfReady();
            } catch (error) {
                fail(new Error(`ZIP 文件无法读取：${String(error?.message || error).slice(0, 240)}`));
            }
        });
    }

    return { extractZipTextFromBytes, limits: LIMITS };
});
