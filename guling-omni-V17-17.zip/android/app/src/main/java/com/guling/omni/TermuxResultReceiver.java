package com.guling.omni;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class TermuxResultReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String taskId = intent.getStringExtra("taskId");
        if (taskId == null || taskId.isEmpty()) return;
        String prefix = "result_" + taskId;
        String stdout = intent.getStringExtra("stdout");
        String stderr = intent.getStringExtra("stderr");
        int exitCode = intent.getIntExtra("exitCode", -1);
        String error = intent.getStringExtra("errmsg");
        context.getSharedPreferences("guling_termux_results", Context.MODE_PRIVATE).edit()
            .putString(prefix + "_stdout", stdout == null ? "" : stdout)
            .putString(prefix + "_stderr", stderr == null ? "" : stderr)
            .putInt(prefix + "_exit", exitCode)
            .putString(prefix + "_error", error == null ? "" : error)
            .apply();
    }
}
