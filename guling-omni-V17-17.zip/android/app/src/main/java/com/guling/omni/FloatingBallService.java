package com.guling.omni;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class FloatingBallService extends Service {
    public static final String ACTION_START = "com.guling.omni.action.START_FLOATING";
    public static final String ACTION_STOP = "com.guling.omni.action.STOP_FLOATING";
    public static final String ACTION_QUEUE_SCREEN = "com.guling.omni.action.QUEUE_SCREEN";
    public static final String ACTION_CANCEL_SCREEN = "com.guling.omni.action.CANCEL_SCREEN";
    public static final String EXTRA_TASK_ID = "task_id";
    public static final String EXTRA_TOOL_NAME = "tool_name";
    public static final String EXTRA_ARGS = "task_args";
    public static final String PREFERENCES = "guling_native_tasks";
    private static final String PENDING_IDS = "pending_ids";

    private static final String SERVICE_CHANNEL = "guling_omni_foreground";
    private static final String TASK_CHANNEL = "guling_omni_approval";
    private static final int SERVICE_NOTIFICATION_ID = 7811;
    private static volatile boolean running = false;

    private WindowManager windowManager;
    private View bubble;
    private WindowManager.LayoutParams bubbleParams;
    private boolean bubbleAdded = false;

    public static boolean isRunning() {
        return running;
    }

    public static String resultKey(String id) {
        return "result_" + id;
    }

    public static String okKey(String id) {
        return "ok_" + id;
    }

    private static String cancelledKey(String id) {
        return "cancelled_" + id;
    }

    private static int taskNotificationId(String id) {
        return 9000 + (id.hashCode() & 0x3fffffff) % 100000;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannels();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopSelf();
            return START_NOT_STICKY;
        }

        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            if (ACTION_QUEUE_SCREEN.equals(action)) {
                String id = intent.getStringExtra(EXTRA_TASK_ID);
                storeTaskResult(this, id, false, "悬浮窗权限已关闭，任务未执行。");
            }
            stopSelf();
            return START_NOT_STICKY;
        }

        startVisibleForeground();
        running = true;
        addBubbleIfNeeded();

        if (ACTION_QUEUE_SCREEN.equals(action)) {
            String id = intent.getStringExtra(EXTRA_TASK_ID);
            String tool = intent.getStringExtra(EXTRA_TOOL_NAME);
            String args = intent.getStringExtra(EXTRA_ARGS);
            showScreenApprovalNotification(id, tool, args);
        } else if (ACTION_CANCEL_SCREEN.equals(action)) {
            String id = intent.getStringExtra(EXTRA_TASK_ID);
            cancelScreenAction(this, id);
        }
        return START_STICKY;
    }

    private void startVisibleForeground() {
        Notification notification = buildForegroundNotification();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(SERVICE_NOTIFICATION_ID, notification,
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(SERVICE_NOTIFICATION_ID, notification);
        }
    }

    private void createNotificationChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel serviceChannel = new NotificationChannel(
                SERVICE_CHANNEL, "古灵常驻服务", NotificationManager.IMPORTANCE_LOW);
        serviceChannel.setDescription("显示悬浮球服务运行状态，并提供停止操作。");
        manager.createNotificationChannel(serviceChannel);
        NotificationChannel taskChannel = new NotificationChannel(
                TASK_CHANNEL, "古灵屏幕任务确认", NotificationManager.IMPORTANCE_HIGH);
        taskChannel.setDescription("仅在你批准屏幕工具后显示一次性读取或点击确认。");
        manager.createNotificationChannel(taskChannel);
    }

    private Notification buildForegroundNotification() {
        Intent launch = getPackageManager().getLaunchIntentForPackage(getPackageName());
        PendingIntent openApp = null;
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            openApp = PendingIntent.getActivity(this, 7811, launch, pendingIntentFlags());
        }
        Intent stop = new Intent(this, FloatingBallService.class).setAction(ACTION_STOP);
        PendingIntent stopService = PendingIntent.getService(this, 7812, stop, pendingIntentFlags());

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, SERVICE_CHANNEL)
                : new Notification.Builder(this);
        builder.setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("古灵常驻服务正在运行")
                .setContentText("悬浮球已启用；屏幕操作仍需逐项人工确认。")
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "停止", stopService);
        if (openApp != null) builder.setContentIntent(openApp);
        return builder.build();
    }

    private int pendingIntentFlags() {
        return PendingIntent.FLAG_UPDATE_CURRENT |
                (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
    }

    private void addBubbleIfNeeded() {
        if (bubbleAdded || windowManager == null || (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this))) return;
        TextView view = new TextView(this);
        view.setText("OMNI");
        view.setTextSize(10);
        view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        view.setTextColor(0xFFFFFFFF);
        view.setGravity(Gravity.CENTER);
        view.setContentDescription("古灵悬浮球，点击返回古灵应用");
        view.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        GradientDrawable background = new GradientDrawable();
        background.setShape(GradientDrawable.OVAL);
        background.setColor(0xEE263B55);
        background.setStroke(dp(2), 0xFF8FC4C9);
        view.setBackground(background);

        int overlayType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        bubbleParams = new WindowManager.LayoutParams(
                dp(58), dp(58), overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL |
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        bubbleParams.gravity = Gravity.TOP | Gravity.START;
        bubbleParams.x = dp(14);
        bubbleParams.y = dp(220);

        view.setOnTouchListener(new View.OnTouchListener() {
            private float downRawX;
            private float downRawY;
            private int startX;
            private int startY;
            private boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        downRawX = event.getRawX();
                        downRawY = event.getRawY();
                        startX = bubbleParams.x;
                        startY = bubbleParams.y;
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = event.getRawX() - downRawX;
                        float dy = event.getRawY() - downRawY;
                        if (Math.abs(dx) > dp(5) || Math.abs(dy) > dp(5)) moved = true;
                        if (moved) {
                            bubbleParams.x = startX + Math.round(dx);
                            bubbleParams.y = startY + Math.round(dy);
                            try { windowManager.updateViewLayout(bubble, bubbleParams); } catch (Exception ignored) {}
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) openApp();
                        return true;
                    default:
                        return true;
                }
            }
        });

        try {
            windowManager.addView(view, bubbleParams);
            bubble = view;
            bubbleAdded = true;
        } catch (Exception ignored) {
            bubble = null;
            bubbleAdded = false;
        }
    }

    private void openApp() {
        Intent launch = getPackageManager().getLaunchIntentForPackage(getPackageName());
        if (launch == null) return;
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(launch);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void showScreenApprovalNotification(String id, String toolName, String rawArgs) {
        if (id == null || id.isEmpty() ||
                !(toolName != null && (toolName.equals("screen_read") || toolName.equals("screen_tap")))) {
            storeTaskResult(this, id, false, "无效的屏幕任务，未执行。");
            return;
        }
        JSONObject args;
        try { args = new JSONObject(rawArgs == null ? "{}" : rawArgs); }
        catch (Exception ignored) { args = new JSONObject(); }

        Intent execute = new Intent(this, ScreenActionReceiver.class)
                .setAction(ScreenActionReceiver.ACTION_EXECUTE)
                .putExtra(EXTRA_TASK_ID, id)
                .putExtra(EXTRA_TOOL_NAME, toolName)
                .putExtra(EXTRA_ARGS, args.toString());
        Intent reject = new Intent(this, ScreenActionReceiver.class)
                .setAction(ScreenActionReceiver.ACTION_REJECT)
                .putExtra(EXTRA_TASK_ID, id);
        int requestCode = id.hashCode() & 0x7fffffff;
        PendingIntent executePending = PendingIntent.getBroadcast(
                this, requestCode, execute, pendingIntentFlags());
        PendingIntent rejectPending = PendingIntent.getBroadcast(
                this, requestCode ^ 0x13579, reject, pendingIntentFlags());

        String details = toolName.equals("screen_tap")
                ? "点击控件 [" + args.optInt("index", -1) + "]「" + args.optString("expectedText", "未标注目标") + "」"
                : "读取当前应用可访问的屏幕文字";
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, TASK_CHANNEL)
                : new Notification.Builder(this);
        Notification notification = builder
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("古灵屏幕任务：需要系统确认")
                .setContentText(details + "。请切换到目标应用后点击执行。")
                .setStyle(new Notification.BigTextStyle().bigText(
                        details + "。此操作只会在你点击“执行”后发生；拒绝或忽略通知不会操作屏幕。"))
                .setCategory(Notification.CATEGORY_REMINDER)
                .setAutoCancel(false)
                .addAction(android.R.drawable.ic_media_play, "执行", executePending)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "拒绝", rejectPending)
                .build();
        updatePendingId(this, id, true);
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        manager.notify(taskNotificationId(id), notification);
    }

    public static void cancelScreenAction(Context context, String id) {
        if (id == null || id.isEmpty()) return;
        context.getSharedPreferences(PREFERENCES, MODE_PRIVATE)
                .edit().putBoolean(cancelledKey(id), true).apply();
        updatePendingId(context, id, false);
        NotificationManager manager = (NotificationManager) context.getSystemService(NOTIFICATION_SERVICE);
        if (manager != null) manager.cancel(taskNotificationId(id));
    }

    public static void cancelAllScreenActions(Context context) {
        android.content.SharedPreferences preferences =
                context.getSharedPreferences(PREFERENCES, MODE_PRIVATE);
        Set<String> pending = new HashSet<>(preferences.getStringSet(PENDING_IDS, Collections.emptySet()));
        for (String id : pending) {
            cancelScreenAction(context, id);
            storeTaskResult(context, id, false, "常驻服务已停止，屏幕任务已取消。");
            preferences.edit().putBoolean(cancelledKey(id), true).apply();
        }
    }

    private static void updatePendingId(Context context, String id, boolean add) {
        android.content.SharedPreferences preferences =
                context.getSharedPreferences(PREFERENCES, MODE_PRIVATE);
        Set<String> pending = new HashSet<>(preferences.getStringSet(PENDING_IDS, Collections.emptySet()));
        if (add) pending.add(id);
        else pending.remove(id);
        android.content.SharedPreferences.Editor editor = preferences.edit();
        if (pending.isEmpty()) editor.remove(PENDING_IDS);
        else editor.putStringSet(PENDING_IDS, pending);
        editor.apply();
    }

    public static boolean isScreenActionCancelled(Context context, String id) {
        return id == null || context.getSharedPreferences(PREFERENCES, MODE_PRIVATE)
                .getBoolean(cancelledKey(id), false);
    }

    public static void storeTaskResult(Context context, String id, boolean ok, String result) {
        if (id == null || id.isEmpty()) return;
        context.getSharedPreferences(PREFERENCES, MODE_PRIVATE)
                .edit()
                .putString(resultKey(id), result == null ? "" : result)
                .putBoolean(okKey(id), ok)
                .remove(cancelledKey(id))
                .apply();
        NotificationManager manager = (NotificationManager) context.getSystemService(NOTIFICATION_SERVICE);
        if (manager != null) manager.cancel(taskNotificationId(id));
    }

    @Override
    public void onDestroy() {
        cancelAllScreenActions(this);
        if (bubbleAdded && windowManager != null && bubble != null) {
            try { windowManager.removeView(bubble); } catch (Exception ignored) {}
        }
        bubble = null;
        bubbleAdded = false;
        running = false;
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE);
        else stopForeground(true);
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
