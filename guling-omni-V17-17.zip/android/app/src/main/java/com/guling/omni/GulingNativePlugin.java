package com.guling.omni;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.app.PendingIntent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.net.wifi.ScanResult;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanSettings;
import android.os.ParcelUuid;
import android.content.ContentValues;
import android.provider.MediaStore;
import android.util.Base64;
import java.io.OutputStream;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import androidx.core.content.ContextCompat;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

@CapacitorPlugin(name = "GulingNative", permissions = {
    @Permission(
        strings = {
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_CONNECT
        },
        alias = "signalScan"
    )
})
public class GulingNativePlugin extends Plugin {

    private static final long SCAN_WINDOW_MS = 4000;

    private PluginCall pendingSignalCall;
    private final List<android.bluetooth.le.ScanResult> bleResults = new ArrayList<>();
    private android.bluetooth.le.ScanCallback bleScanCallback;
    private boolean bleScanning = false;

    @PluginMethod
    public void getTermuxStatus(PluginCall call) {
        Context context = getContext();
        JSObject result = new JSObject();
        boolean installed = false;
        try {
            context.getPackageManager().getPackageInfo("com.termux", 0);
            installed = true;
        } catch (Exception ignored) {}
        boolean apiInstalled = false;
        try {
            context.getPackageManager().getPackageInfo("com.termux.api", 0);
            apiInstalled = true;
        } catch (Exception ignored) {}
        result.put("termuxInstalled", installed);
        result.put("termuxApiInstalled", apiInstalled);
        call.resolve(result);
    }

    @PluginMethod
    public void queueTermuxCommand(PluginCall call) {
        Context context = getContext();
        String taskId = call.getString("taskId", "");
        String command = call.getString("command", "").trim();
        if (taskId.isEmpty() || command.isEmpty() || command.length() > 2000) {
            call.reject("缺少任务编号或命令，命令长度不得超过 2000 字符。");
            return;
        }
        Intent intent = new Intent("com.termux.RUN_COMMAND");
        intent.setPackage("com.termux");
        intent.putExtra("com.termux.RUN_COMMAND_PATH", "/data/data/com.termux/files/usr/bin/bash");
        intent.putExtra("com.termux.RUN_COMMAND_ARGUMENTS", new String[]{"-lc", command});
        intent.putExtra("com.termux.RUN_COMMAND_WORKDIR", "/data/data/com.termux/files/home");
        intent.putExtra("com.termux.RUN_COMMAND_BACKGROUND", true);
        intent.putExtra("com.termux.RUN_COMMAND_SESSION_ACTION", "0");
        Intent callbackIntent = new Intent(context, TermuxResultReceiver.class);
        callbackIntent.setAction("com.guling.omni.TERMUX_RESULT");
        callbackIntent.putExtra("taskId", taskId);
        int pendingFlags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 31) pendingFlags |= PendingIntent.FLAG_MUTABLE;
        else if (Build.VERSION.SDK_INT >= 23) pendingFlags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent callback = PendingIntent.getBroadcast(context, taskId.hashCode(), callbackIntent, pendingFlags);
        intent.putExtra("com.termux.RUN_COMMAND_RESULT_PENDING_INTENT", callback);
        try {
            context.startService(intent);
            JSObject result = new JSObject();
            result.put("queued", true);
            result.put("message", "命令已提交给 Termux；请稍后读取执行结果。");
            call.resolve(result);
        } catch (SecurityException e) {
            call.reject("Termux 拒绝执行。请安装 Termux:API，并在 Termux 的 ~/.termux/termux.properties 中设置 allow-external-apps = true，然后重启 Termux。", e);
        } catch (Exception e) {
            call.reject("无法调用 Termux：" + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void pollTermuxCommand(PluginCall call) {
        String taskId = call.getString("taskId", "");
        if (taskId.isEmpty()) { call.reject("缺少 taskId。"); return; }
        android.content.SharedPreferences prefs = getContext().getSharedPreferences("guling_termux_results", Context.MODE_PRIVATE);
        String key = "result_" + taskId;
        String stdout = prefs.getString(key + "_stdout", null);
        JSObject result = new JSObject();
        result.put("ready", stdout != null || prefs.contains(key + "_exit"));
        if (stdout != null || prefs.contains(key + "_exit")) {
            result.put("stdout", stdout == null ? "" : stdout);
            result.put("stderr", prefs.getString(key + "_stderr", ""));
            result.put("exitCode", prefs.getInt(key + "_exit", -1));
            result.put("error", prefs.getString(key + "_error", ""));
            prefs.edit().remove(key + "_stdout").remove(key + "_stderr").remove(key + "_exit").remove(key + "_error").apply();
        }
        call.resolve(result);
    }

    @PluginMethod
    public void saveProjectZipToDownloads(PluginCall call) {
        String encoded = call.getString("base64", "");
        if (encoded.isEmpty() || encoded.length() > 36_000_000) {
            call.reject("项目 ZIP 为空或超过 27 MB 限制。");
            return;
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            call.reject("自动上传项目 ZIP 需要 Android 10 或更新版本；请手动将 ZIP 放入 Termux 可访问的 Download 目录。");
            return;
        }
        android.content.ContentResolver resolver = getContext().getContentResolver();
        Uri uri = null;
        try {
            byte[] bytes = Base64.decode(encoded, Base64.DEFAULT);
            if (bytes.length == 0 || bytes.length > 27 * 1024 * 1024) {
                call.reject("项目 ZIP 为空或超过 27 MB 限制。");
                return;
            }
            // 覆盖旧文件：MediaStore 遇到同名文件会自动改名，而构建脚本固定读取 guling-project.zip，
            // 因此先删除 Download/GulingBuild/ 下的同名旧条目，避免构建到上一次的旧包。
            try {
                String[] projection = { MediaStore.MediaColumns._ID };
                String selection = MediaStore.MediaColumns.DISPLAY_NAME + "=? AND " + MediaStore.MediaColumns.RELATIVE_PATH + "=?";
                String[] selectionArgs = { "guling-project.zip", "Download/GulingBuild/" };
                try (android.database.Cursor cursor = resolver.query(
                        MediaStore.Downloads.EXTERNAL_CONTENT_URI, projection, selection, selectionArgs, null)) {
                    while (cursor != null && cursor.moveToNext()) {
                        long id = cursor.getLong(0);
                        try {
                            resolver.delete(android.content.ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, id), null, null);
                        } catch (Exception ignored) {}
                    }
                }
            } catch (Exception ignored) {}
            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, "guling-project.zip");
            values.put(MediaStore.MediaColumns.MIME_TYPE, "application/zip");
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/GulingBuild/");
            values.put(MediaStore.MediaColumns.IS_PENDING, 1);
            uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new java.io.IOException("无法创建 Download 文件");
            try (OutputStream out = resolver.openOutputStream(uri, "w")) {
                if (out == null) throw new java.io.IOException("无法写入 Download 文件");
                out.write(bytes);
                out.flush();
            }
            ContentValues ready = new ContentValues();
            ready.put(MediaStore.MediaColumns.IS_PENDING, 0);
            resolver.update(uri, ready, null, null);
            JSObject result = new JSObject();
            result.put("saved", true);
            result.put("path", "Download/GulingBuild/guling-project.zip");
            result.put("bytes", bytes.length);
            call.resolve(result);
        } catch (Exception e) {
            if (uri != null) try { resolver.delete(uri, null, null); } catch (Exception ignored) {}
            call.reject("无法把项目 ZIP 保存到共享 Download：" + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void installBuiltApk(PluginCall call) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            call.reject("自动打开安装器需要 Android 10 或更新版本，请在 Download/GulingBuild 中手动安装。");
            return;
        }
        Uri apkUri = null;
        try {
            String[] projection = { MediaStore.MediaColumns._ID };
            String selection = MediaStore.MediaColumns.DISPLAY_NAME + "=? AND " + MediaStore.MediaColumns.RELATIVE_PATH + "=?";
            String[] selectionArgs = { "guling-omni-debug.apk", "Download/GulingBuild/" };
            try (android.database.Cursor cursor = getContext().getContentResolver().query(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI, projection, selection, selectionArgs, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    apkUri = android.content.ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cursor.getLong(0));
                }
            }
        } catch (Exception ignored) {}
        if (apkUri == null) {
            call.reject("未找到 Download/GulingBuild/guling-omni-debug.apk，请确认构建完成后手动安装。");
            return;
        }
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(apkUri, "application/vnd.android.package-archive");
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            getContext().startActivity(intent);
            JSObject result = new JSObject();
            result.put("opened", true);
            result.put("path", "Download/GulingBuild/guling-omni-debug.apk");
            call.resolve(result);
        } catch (Exception e) {
            call.reject("无法打开系统安装器：" + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void saveApkToDownloads(PluginCall call) {
        String encoded = call.getString("base64", "");
        if (encoded.isEmpty() || encoded.length() > 200_000_000) {
            call.reject("APK 为空或超过 150 MB 限制。");
            return;
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            call.reject("自动保存 APK 需要 Android 10 或更新版本。");
            return;
        }
        android.content.ContentResolver resolver = getContext().getContentResolver();
        Uri uri = null;
        try {
            byte[] bytes = Base64.decode(encoded, Base64.DEFAULT);
            if (bytes.length == 0 || bytes.length > 150 * 1024 * 1024) {
                call.reject("APK 为空或超过 150 MB 限制。");
                return;
            }
            // 删除旧的同名 APK，避免 MediaStore 自动改名导致 installBuiltApk 找不到
            try {
                String[] projection = { MediaStore.MediaColumns._ID };
                String selection = MediaStore.MediaColumns.DISPLAY_NAME + "=? AND " + MediaStore.MediaColumns.RELATIVE_PATH + "=?";
                String[] selectionArgs = { "guling-omni-debug.apk", "Download/GulingBuild/" };
                try (android.database.Cursor cursor = resolver.query(
                        MediaStore.Downloads.EXTERNAL_CONTENT_URI, projection, selection, selectionArgs, null)) {
                    while (cursor != null && cursor.moveToNext()) {
                        long id = cursor.getLong(0);
                        try {
                            resolver.delete(android.content.ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, id), null, null);
                        } catch (Exception ignored) {}
                    }
                }
            } catch (Exception ignored) {}
            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, "guling-omni-debug.apk");
            values.put(MediaStore.MediaColumns.MIME_TYPE, "application/vnd.android.package-archive");
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/GulingBuild/");
            values.put(MediaStore.MediaColumns.IS_PENDING, 1);
            uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new java.io.IOException("无法创建 Download 文件");
            try (OutputStream out = resolver.openOutputStream(uri, "w")) {
                if (out == null) throw new java.io.IOException("无法写入 Download 文件");
                out.write(bytes);
                out.flush();
            }
            ContentValues ready = new ContentValues();
            ready.put(MediaStore.MediaColumns.IS_PENDING, 0);
            resolver.update(uri, ready, null, null);
            JSObject result = new JSObject();
            result.put("saved", true);
            result.put("path", "Download/GulingBuild/guling-omni-debug.apk");
            result.put("bytes", bytes.length);
            call.resolve(result);
        } catch (Exception e) {
            if (uri != null) try { resolver.delete(uri, null, null); } catch (Exception ignored) {}
            call.reject("无法把 APK 保存到共享 Download：" + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void getStatus(PluginCall call) {
        Context context = getContext();
        JSObject result = new JSObject();
        result.put("overlayPermission", Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(context));
        result.put("foregroundService", FloatingBallService.isRunning());
        result.put("accessibilityEnabled", OmniAccessibilityService.isEnabled(context));
        result.put("notificationPermission", Build.VERSION.SDK_INT < 33 ||
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED);
        call.resolve(result);
    }

    @PluginMethod
    public void openOverlayPermissionSettings(PluginCall call) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(getContext())) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getContext().getPackageName()));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(intent);
        }
        call.resolve();
    }

    @PluginMethod
    public void openAccessibilitySettings(PluginCall call) {
        Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        getContext().startActivity(intent);
        call.resolve();
    }

    @PluginMethod
    public void openNotificationSettings(PluginCall call) {
        Intent intent = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
        intent.putExtra(Settings.EXTRA_APP_PACKAGE, getContext().getPackageName());
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        getContext().startActivity(intent);
        call.resolve();
    }

    @PluginMethod
    public void startServices(PluginCall call) {
        Context context = getContext();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
            JSObject result = new JSObject();
            result.put("needsOverlayPermission", true);
            call.resolve(result);
            return;
        }
        if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            call.reject("请先在 Android 系统设置中允许古灵发送通知，再启动常驻服务。");
            return;
        }
        Intent intent = new Intent(context, FloatingBallService.class);
        intent.setAction(FloatingBallService.ACTION_START);
        ContextCompat.startForegroundService(context, intent);
        call.resolve();
    }

    @PluginMethod
    public void stopServices(PluginCall call) {
        Context context = getContext();
        context.stopService(new Intent(context, FloatingBallService.class));
        call.resolve();
    }

    @PluginMethod
    public void queueScreenAction(PluginCall call) {
        Context context = getContext();
        String taskId = call.getString("taskId", "");
        String toolName = call.getString("toolName", "");
        JSObject args = call.getObject("args");
        if (taskId.isEmpty() || !(toolName.equals("screen_read") || toolName.equals("screen_tap"))) {
            call.reject("无效的屏幕操作任务。");
            return;
        }
        if (!FloatingBallService.isRunning()) {
            call.reject("请先启用悬浮球与常驻服务。");
            return;
        }
        if (!OmniAccessibilityService.isEnabled(context)) {
            call.reject("请先在 Android 无障碍设置中手动启用古灵屏幕助手。");
            return;
        }
        if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            call.reject("通知权限未开启，无法显示第二步系统确认。");
            return;
        }
        Intent intent = new Intent(context, FloatingBallService.class);
        intent.setAction(FloatingBallService.ACTION_QUEUE_SCREEN);
        intent.putExtra(FloatingBallService.EXTRA_TASK_ID, taskId);
        intent.putExtra(FloatingBallService.EXTRA_TOOL_NAME, toolName);
        intent.putExtra(FloatingBallService.EXTRA_ARGS, args == null ? "{}" : args.toString());
        ContextCompat.startForegroundService(context, intent);
        JSObject result = new JSObject();
        result.put("queued", true);
        call.resolve(result);
    }

    @PluginMethod
    public void pollScreenAction(PluginCall call) {
        String taskId = call.getString("taskId", "");
        if (taskId.isEmpty()) {
            call.reject("缺少 taskId。");
            return;
        }
        Context context = getContext();
        String resultKey = FloatingBallService.resultKey(taskId);
        String okKey = FloatingBallService.okKey(taskId);
        android.content.SharedPreferences preferences =
                context.getSharedPreferences(FloatingBallService.PREFERENCES, Context.MODE_PRIVATE);
        String value = preferences.getString(resultKey, null);
        JSObject result = new JSObject();
        result.put("ready", value != null);
        if (value != null) {
            result.put("ok", preferences.getBoolean(okKey, false));
            result.put("result", value);
            preferences.edit().remove(resultKey).remove(okKey).apply();
        }
        call.resolve(result);
    }

    @PluginMethod
    public void cancelScreenAction(PluginCall call) {
        String taskId = call.getString("taskId", "");
        if (!taskId.isEmpty()) FloatingBallService.cancelScreenAction(getContext(), taskId);
        call.resolve();
    }

    // ================= 附近信号扫描（WiFi + BLE） =================

    @PluginMethod
    public void scanNearbySignals(PluginCall call) {
        if (pendingSignalCall != null) {
            call.reject("上一次扫描尚未完成，请稍候再试。");
            return;
        }
        pendingSignalCall = call;
        if (getPermissionState("signalScan") != PermissionState.GRANTED) {
            requestPermissionForAlias("signalScan", call, "onSignalScanPermissionResult");
        } else {
            startSignalScan();
        }
    }

    @PermissionCallback
    private void onSignalScanPermissionResult(PluginCall call) {
        if (getPermissionState("signalScan") == PermissionState.GRANTED) {
            startSignalScan();
        } else {
            PluginCall saved = pendingSignalCall;
            pendingSignalCall = null;
            if (saved != null) saved.reject("需要位置与蓝牙权限才能扫描附近信号。请到系统设置中为古灵授权后重试。");
        }
    }

    private void startSignalScan() {
        Context context = getContext();
        // WiFi
        WifiManager wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
        boolean wifiReady = wifiManager != null && wifiManager.isWifiEnabled();
        if (wifiManager != null) {
            try { wifiManager.startScan(); } catch (Exception ignored) {}
        }
        // BLE
        BluetoothManager btManager = (BluetoothManager) context.getSystemService(Context.BLUETOOTH_SERVICE);
        BluetoothAdapter btAdapter = btManager != null ? btManager.getAdapter() : null;
        BluetoothLeScanner scanner = (btAdapter != null && btAdapter.isEnabled()) ? btAdapter.getBluetoothLeScanner() : null;
        synchronized (bleResults) { bleResults.clear(); }
        bleScanning = false;
        if (scanner != null) {
            bleScanCallback = new ScanCallback() {
                @Override
                public void onScanResult(int callbackType, android.bluetooth.le.ScanResult result) {
                    if (result != null) {
                        synchronized (bleResults) { bleResults.add(result); }
                    }
                }
                @Override
                public void onBatchScanResults(List<android.bluetooth.le.ScanResult> results) {
                    if (results != null) {
                        synchronized (bleResults) { bleResults.addAll(results); }
                    }
                }
            };
            try {
                ScanSettings settings = new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build();
                scanner.startScan(new ArrayList<ScanFilter>(), settings, bleScanCallback);
                bleScanning = true;
            } catch (Exception ignored) { bleScanning = false; }
        }
        final boolean finalWifiReady = wifiReady;
        final WifiManager finalWifi = wifiManager;
        final BluetoothLeScanner finalScanner = scanner;
        new Handler(Looper.getMainLooper()).postDelayed(() -> collectSignalResults(finalWifi, finalWifiReady, finalScanner), SCAN_WINDOW_MS);
    }

    private void collectSignalResults(WifiManager wifiManager, boolean wifiReady, BluetoothLeScanner scanner) {
        if (bleScanning && scanner != null && bleScanCallback != null) {
            try { scanner.stopScan(bleScanCallback); } catch (Exception ignored) {}
            bleScanning = false;
        }
        List<ScanResult> wifiList = new ArrayList<>();
        if (wifiManager != null) {
            try {
                List<ScanResult> raw = wifiManager.getScanResults();
                if (raw != null) wifiList.addAll(raw);
            } catch (Exception ignored) {}
        }
        JSArray wifiArr = new JSArray();
        JSObject summary = new JSObject();
        summary.put("wifiReady", wifiReady);
        summary.put("bleReady", scanner != null);
        int openCount = 0;
        int band24 = 0, band5 = 0, band6 = 0;
        int excellent = 0, good = 0, fair = 0, weak = 0;
        java.util.Map<Integer, Integer> channelCount = new java.util.HashMap<>();
        String strongestSsid = "";
        int strongestRssi = -200;
        for (ScanResult sr : wifiList) {
            JSObject o = new JSObject();
            String ssid = sr.SSID != null ? sr.SSID : "";
            String bssid = sr.BSSID != null ? sr.BSSID : "";
            o.put("ssid", ssid);
            o.put("bssid", bssid);
            o.put("rssi", sr.level);
            o.put("frequency", sr.frequency);
            int channel = frequencyToChannel(sr.frequency);
            o.put("channel", channel);
            String band = bandFromFrequency(sr.frequency);
            o.put("band", band);
            o.put("capabilities", sr.capabilities != null ? sr.capabilities : "");
            String sec = parseSecurity(sr.capabilities);
            o.put("security", sec);
            o.put("isOpen", "Open".equals(sec));
            if ("Open".equals(sec)) openCount++;
            String quality = signalQuality(sr.level);
            o.put("signalQuality", quality);
            o.put("distanceMeters", wifiDistanceMeters(sr.level));
            wifiArr.put(o);
            if ("2.4GHz".equals(band)) band24++;
            else if ("5GHz".equals(band)) band5++;
            else if ("6GHz".equals(band)) band6++;
            if ("excellent".equals(quality)) excellent++;
            else if ("good".equals(quality)) good++;
            else if ("fair".equals(quality)) fair++;
            else weak++;
            if (channel > 0 && "2.4GHz".equals(band)) {
                channelCount.merge(channel, 1, Integer::sum);
            }
            if (sr.level > strongestRssi && !ssid.isEmpty()) {
                strongestRssi = sr.level;
                strongestSsid = ssid;
            }
        }
        summary.put("wifiCount", wifiArr.length());
        summary.put("openWifiCount", openCount);
        JSObject bands = new JSObject();
        bands.put("2.4GHz", band24);
        bands.put("5GHz", band5);
        bands.put("6GHz", band6);
        summary.put("bands", bands);
        JSObject sigDist = new JSObject();
        sigDist.put("excellent", excellent);
        sigDist.put("good", good);
        sigDist.put("fair", fair);
        sigDist.put("weak", weak);
        summary.put("signalDistribution", sigDist);
        JSArray crowded = new JSArray();
        List<java.util.Map.Entry<Integer, Integer>> sorted = new ArrayList<>(channelCount.entrySet());
        sorted.sort((a, b) -> b.getValue() - a.getValue());
        for (java.util.Map.Entry<Integer, Integer> e : sorted) {
            JSObject c = new JSObject();
            c.put("channel", e.getKey());
            c.put("count", e.getValue());
            crowded.put(c);
        }
        summary.put("crowdedChannels", crowded);
        summary.put("strongestWifi", strongestSsid);
        summary.put("strongestRssi", strongestRssi);
        summary.put("environment", wifiArr.length() >= 15 ? "dense" : (wifiArr.length() >= 5 ? "normal" : "sparse"));

        // BLE
        JSArray bleArr = new JSArray();
        List<android.bluetooth.le.ScanResult> bleCopy;
        synchronized (bleResults) { bleCopy = new ArrayList<>(bleResults); }
        java.util.Set<String> seenBle = new java.util.HashSet<>();
        for (android.bluetooth.le.ScanResult r : bleCopy) {
            BluetoothDevice dev = r.getDevice();
            if (dev == null) continue;
            String addr = dev.getAddress();
            if (addr == null || seenBle.contains(addr)) continue;
            seenBle.add(addr);
            JSObject o = new JSObject();
            o.put("address", addr);
            String name = null;
            try { name = dev.getName(); } catch (Exception ignored) {}
            o.put("name", name != null ? name : "");
            o.put("rssi", r.getRssi());
            int tx = r.getTxPower();
            o.put("txPower", tx);
            android.bluetooth.le.ScanRecord record = r.getScanRecord();
            List<ParcelUuid> uuids = record != null ? record.getServiceUuids() : null;
            JSArray uuidArr = new JSArray();
            if (uuids != null) {
                for (ParcelUuid u : uuids) {
                    if (u != null) uuidArr.put(u.toString());
                }
            }
            o.put("serviceUuids", uuidArr);
            if (record != null) {
                android.util.SparseArray<byte[]> mfg = record.getManufacturerSpecificData();
                if (mfg != null && mfg.size() > 0) {
                    int key = mfg.keyAt(0);
                    byte[] data = mfg.get(key);
                    o.put("manufacturerId", key);
                    o.put("manufacturerDataHex", bytesToHex(data));
                }
            }
            o.put("distanceMeters", bleDistanceMeters(r.getRssi(), tx));
            bleArr.put(o);
        }
        summary.put("bleCount", bleArr.length());
        summary.put("timestamp", System.currentTimeMillis());

        JSObject result = new JSObject();
        result.put("wifi", wifiArr);
        result.put("ble", bleArr);
        result.put("summary", summary);

        PluginCall saved = pendingSignalCall;
        pendingSignalCall = null;
        if (saved != null) saved.resolve(result);
    }

    private static int frequencyToChannel(int freq) {
        if (freq >= 2412 && freq <= 2472) return (freq - 2407) / 5;
        if (freq == 2484) return 14;
        if (freq >= 5170 && freq <= 5825) return (freq - 5000) / 5;
        if (freq >= 5955 && freq <= 7115) return (freq - 5950) / 5;
        return 0;
    }

    private static String bandFromFrequency(int freq) {
        if (freq >= 2400 && freq < 2500) return "2.4GHz";
        if (freq >= 5000 && freq < 5900) return "5GHz";
        if (freq >= 5900 && freq < 7200) return "6GHz";
        return "unknown";
    }

    private static String parseSecurity(String caps) {
        if (caps == null) return "Unknown";
        String c = caps.toUpperCase();
        if (c.contains("WPA3")) return "WPA3";
        if (c.contains("WPA2")) return "WPA2";
        if (c.contains("WPA")) return "WPA";
        if (c.contains("WEP")) return "WEP";
        if (c.contains("ESS") || c.contains("[ESS]")) return "Open";
        return "Open";
    }

    private static String signalQuality(int rssi) {
        if (rssi >= -50) return "excellent";
        if (rssi >= -60) return "good";
        if (rssi >= -70) return "fair";
        return "weak";
    }

    private static double wifiDistanceMeters(int rssi) {
        // RSSI at 1m ≈ -40 dBm for typical WiFi AP; path loss exponent n=2.5 (indoor)
        double exp = (-40.0 - rssi) / 25.0;
        double d = Math.pow(10.0, exp);
        if (d < 0.3) d = 0.3;
        return Math.round(d * 10.0) / 10.0;
    }

    private static double bleDistanceMeters(int rssi, int txPower) {
        // txPower is RSSI at 1m if available; otherwise assume -59 dBm.
        int ref = (txPower != 0 && txPower > -127 && txPower < 20) ? txPower : -59;
        double exp = (ref - rssi) / 20.0;
        double d = Math.pow(10.0, exp);
        if (d < 0.1) d = 0.1;
        return Math.round(d * 10.0) / 10.0;
    }

    private static String bytesToHex(byte[] bytes) {
        if (bytes == null) return "";
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) sb.append(String.format("%02X", b));
        return sb.toString();
    }

    // ==================== Shell（系统自带 sh）====================

    @PluginMethod
    public void getShellStatus(PluginCall call) {
        JSObject ret = new JSObject();
        ret.put("ready", true);
        ret.put("method", "system-sh");
        ret.put("binDir", "/system/bin");
        call.resolve(ret);
    }

    @PluginMethod
    public void execShell(PluginCall call) {
        String command = call.getString("command", "");
        long timeoutMs = call.getLong("timeout", 30000L);
        if (command == null || command.trim().isEmpty()) {
            call.reject("command is empty");
            return;
        }
        if (command.length() > 4000) {
            call.reject("command too long (max 4000 chars)");
            return;
        }
        executeShellAsync(command, timeoutMs, call);
    }

    private void executeShellAsync(String command, long timeoutMs, PluginCall call) {
        new Thread(() -> {
            try {
                ShellResult result = runShellCommand(command, timeoutMs);
                JSObject ret = new JSObject();
                ret.put("stdout", result.stdout);
                ret.put("stderr", result.stderr);
                ret.put("exitCode", result.exitCode);
                ret.put("method", result.method);
                call.resolve(ret);
            } catch (Exception e) {
                call.reject("exec failed: " + e.getMessage());
            }
        }).start();
    }

    private static class ShellResult {
        String stdout = "";
        String stderr = "";
        int exitCode = -1;
        String method = "";
    }

    private ShellResult runProcess(java.util.List<String> cmd, java.util.Map<String, String> env,
                                   long timeoutMs, String method) throws Exception {
        ShellResult result = new ShellResult();
        result.method = method;
        ProcessBuilder pb = new ProcessBuilder(cmd);
        if (env != null) for (java.util.Map.Entry<String, String> e : env.entrySet()) {
            pb.environment().put(e.getKey(), e.getValue());
        }
        Process p = pb.start();
        String out = readStream(p.getInputStream());
        String err = readStream(p.getErrorStream());
        boolean finished = p.waitFor(timeoutMs, java.util.concurrent.TimeUnit.MILLISECONDS);
        if (!finished) {
            p.destroyForcibly();
            result.stdout = out;
            result.stderr = err + "\n[timeout after " + timeoutMs + "ms]";
            result.exitCode = 124;
            return result;
        }
        result.stdout = out;
        result.stderr = err;
        result.exitCode = p.exitValue();
        return result;
    }

    private ShellResult runSystemShell(String command, long timeoutMs) throws Exception {
        java.util.List<String> cmd = new java.util.ArrayList<>();
        cmd.add("/system/bin/sh");
        cmd.add("-c");
        cmd.add(command);
        java.util.Map<String, String> env = new java.util.HashMap<>();
        env.put("HOME", getContext().getFilesDir().getAbsolutePath());
        env.put("PATH", "/product/bin:/apex/com.android.runtime/bin:/system/bin:/system/xbin:/data/local/bin");
        env.put("TMPDIR", getContext().getCacheDir().getAbsolutePath());
        return runProcess(cmd, env, timeoutMs, "system-sh");
    }

    private ShellResult runShellCommand(String command, long timeoutMs) throws Exception {
        return runSystemShell(command, timeoutMs);
    }

    private String readStream(java.io.InputStream is) throws Exception {
        StringBuilder sb = new StringBuilder();
        byte[] buf = new byte[4096];
        int n;
        while ((n = is.read(buf)) > 0) {
            sb.append(new String(buf, 0, n));
            if (sb.length() > 65536) {
                sb.append("\n... [output truncated]");
                break;
            }
        }
        return sb.toString();
    }

    // ==================== Browser Automation (in-app WebView) ====================

    private android.webkit.WebView agentWebView = null;
    private String browserLastResult = null;

    private android.webkit.WebView getOrCreateWebView() {
        if (agentWebView != null) return agentWebView;
        android.app.Activity activity = getActivity();
        if (activity == null) return null;
        activity.runOnUiThread(() -> {
            android.webkit.WebView wv = new android.webkit.WebView(activity);
            android.webkit.WebSettings s = wv.getSettings();
            s.setJavaScriptEnabled(true);
            s.setDomStorageEnabled(true);
            s.setDatabaseEnabled(true);
            s.setAllowFileAccess(false);
            s.setAllowContentAccess(false);
            s.setMixedContentMode(android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW);
            s.setUserAgentString("Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36 Guling/1.0");
            wv.setWebViewClient(new android.webkit.WebViewClient() {
                @Override
                public void onPageFinished(android.webkit.WebView view, String url) {
                    browserLastResult = "loaded:" + url;
                }
            });
            wv.setVisibility(android.view.View.GONE);
            wv.setLayoutParams(new android.view.ViewGroup.LayoutParams(1, 1));
            android.view.ViewGroup root = activity.findViewById(android.R.id.content);
            root.addView(wv);
            agentWebView = wv;
        });
        // wait for creation
        int tries = 0;
        while (agentWebView == null && tries < 50) {
            try { Thread.sleep(20); } catch (InterruptedException e) { break; }
            tries++;
        }
        return agentWebView;
    }

    @PluginMethod
    public void browserOpen(PluginCall call) {
        String url = call.getString("url", "");
        if (url == null || url.isEmpty()) { call.reject("url required"); return; }
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            url = "https://" + url;
        }
        android.webkit.WebView wv = getOrCreateWebView();
        if (wv == null) { call.reject("webview unavailable"); return; }
        browserLastResult = null;
        final String fUrl = url;
        getActivity().runOnUiThread(() -> wv.loadUrl(fUrl));
        // wait for page load
        new Thread(() -> {
            int tries = 0;
            while (browserLastResult == null && tries < 150) {
                try { Thread.sleep(100); } catch (InterruptedException e) { break; }
                tries++;
            }
            JSObject ret = new JSObject();
            ret.put("ok", browserLastResult != null);
            ret.put("url", browserLastResult != null ? browserLastResult.replace("loaded:", "") : fUrl);
            call.resolve(ret);
        }).start();
    }

    @PluginMethod
    public void browserEval(PluginCall call) {
        String script = call.getString("script", "");
        if (script == null || script.isEmpty()) { call.reject("script required"); return; }
        android.webkit.WebView wv = agentWebView;
        if (wv == null) { call.reject("no webview, call browser_open first"); return; }
        getActivity().runOnUiThread(() ->
            wv.evaluateJavascript(script, value -> {
                JSObject ret = new JSObject();
                ret.put("result", value != null ? value : "null");
                call.resolve(ret);
            })
        );
    }

    @PluginMethod
    public void browserClick(PluginCall call) {
        String selector = call.getString("selector", "");
        if (selector == null || selector.isEmpty()) { call.reject("selector required"); return; }
        String safe = selector.replace("\\", "\\\\").replace("'", "\\'");
        browserEvalInternal(call,
            "(function(){var el=document.querySelector('" + safe + "');if(el){el.click();return 'clicked:'+el.tagName;}return 'not found';})()");
    }

    @PluginMethod
    public void browserInput(PluginCall call) {
        String selector = call.getString("selector", "");
        String text = call.getString("text", "");
        if (selector == null || selector.isEmpty()) { call.reject("selector required"); return; }
        String safeSel = selector.replace("\\", "\\\\").replace("'", "\\'");
        String safeText = text.replace("\\", "\\\\").replace("'", "\\'");
        browserEvalInternal(call,
            "(function(){var el=document.querySelector('" + safeSel + "');if(!el)return 'not found';el.value='" + safeText + "';el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));return 'filled';})()");
    }

    @PluginMethod
    public void browserRead(PluginCall call) {
        android.webkit.WebView wv = agentWebView;
        if (wv == null) { call.reject("no webview, call browser_open first"); return; }
        getActivity().runOnUiThread(() ->
            wv.evaluateJavascript(
                "(function(){return document.body?document.body.innerText.slice(0,10000):'';})()",
                value -> {
                    JSObject ret = new JSObject();
                    ret.put("text", value != null ? value.replaceAll("^\"|\"$", "").replace("\\n", "\n").replace("\\\"", "\"") : "");
                    ret.put("url", wv.getUrl());
                    ret.put("title", wv.getTitle());
                    call.resolve(ret);
                }
            )
        );
    }

    private void browserEvalInternal(PluginCall call, String script) {
        android.webkit.WebView wv = agentWebView;
        if (wv == null) { call.reject("no webview, call browser_open first"); return; }
        getActivity().runOnUiThread(() ->
            wv.evaluateJavascript(script, value -> {
                JSObject ret = new JSObject();
                ret.put("result", value != null ? value : "null");
                call.resolve(ret);
            })
        );
    }

    @PluginMethod
    public void browserClose(PluginCall call) {
        if (agentWebView != null) {
            getActivity().runOnUiThread(() -> {
                agentWebView.loadUrl("about:blank");
                agentWebView.clearHistory();
            });
        }
        JSObject ret = new JSObject();
        ret.put("ok", true);
        call.resolve(ret);
    }
}
