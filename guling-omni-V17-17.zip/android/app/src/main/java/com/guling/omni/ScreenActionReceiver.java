package com.guling.omni;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class ScreenActionReceiver extends BroadcastReceiver {
    public static final String ACTION_EXECUTE = "com.guling.omni.action.EXECUTE_APPROVED_SCREEN_TASK";
    public static final String ACTION_REJECT = "com.guling.omni.action.REJECT_SCREEN_TASK";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        String taskId = intent.getStringExtra(FloatingBallService.EXTRA_TASK_ID);
        if (taskId == null || taskId.isEmpty()) return;

        if (ACTION_REJECT.equals(intent.getAction())) {
            FloatingBallService.storeTaskResult(context, taskId, false,
                    "你在 Android 系统通知中拒绝了屏幕操作。");
            return;
        }
        if (!ACTION_EXECUTE.equals(intent.getAction())) return;

        String toolName = intent.getStringExtra(FloatingBallService.EXTRA_TOOL_NAME);
        String argsJson = intent.getStringExtra(FloatingBallService.EXTRA_ARGS);
        OmniAccessibilityService.performApprovedAction(context, taskId, toolName, argsJson);
    }
}
