package com.guling.omni;

import android.accessibilityservice.AccessibilityService;
import android.content.ComponentName;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class OmniAccessibilityService extends AccessibilityService {
    private static volatile OmniAccessibilityService instance;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Intentionally do not collect or retain screen content from background events.
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public void onDestroy() {
        if (instance == this) instance = null;
        super.onDestroy();
    }

    public static boolean isEnabled(Context context) {
        String enabledServices = Settings.Secure.getString(
                context.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (TextUtils.isEmpty(enabledServices)) return false;
        String target = new ComponentName(context, OmniAccessibilityService.class)
                .flattenToString().toLowerCase(Locale.ROOT);
        for (String service : enabledServices.split(":")) {
            if (target.equals(service.toLowerCase(Locale.ROOT))) return true;
        }
        return false;
    }

    public static void performApprovedAction(
            Context context, String taskId, String toolName, String argsJson) {
        if (FloatingBallService.isScreenActionCancelled(context, taskId)) {
            FloatingBallService.storeTaskResult(context, taskId, false, "任务已取消，未操作屏幕。");
            return;
        }
        OmniAccessibilityService service = instance;
        if (service == null) {
            FloatingBallService.storeTaskResult(context, taskId, false,
                    "无障碍服务当前未连接；请检查系统设置后重试。");
            return;
        }
        service.handler.postDelayed(() -> {
            if (FloatingBallService.isScreenActionCancelled(context, taskId)) {
                FloatingBallService.storeTaskResult(context, taskId, false, "任务已取消，未操作屏幕。");
                return;
            }
            try {
                JSONObject args = new JSONObject(argsJson == null ? "{}" : argsJson);
                String result;
                if ("screen_read".equals(toolName)) {
                    result = service.readCurrentScreen();
                } else if ("screen_tap".equals(toolName)) {
                    result = service.clickAccessibleControl(args);
                } else {
                    throw new IllegalArgumentException("仅允许屏幕读取或已审批的控件点击。");
                }
                FloatingBallService.storeTaskResult(context, taskId, true, result);
            } catch (Exception error) {
                FloatingBallService.storeTaskResult(context, taskId, false,
                        "屏幕操作失败：" + String.valueOf(error.getMessage()));
            }
        }, 1200);
    }

    private String readCurrentScreen() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) throw new IllegalStateException("没有可读取的活动窗口。");
        String packageName = String.valueOf(root.getPackageName());
        ensureExternalTarget(packageName);

        List<String> text = new ArrayList<>();
        List<Control> controls = new ArrayList<>();
        int[] visited = {0};
        collectVisibleContent(root, text, controls, visited, 0);

        StringBuilder result = new StringBuilder();
        result.append("当前应用：").append(packageName).append("\n可见屏幕文字：\n");
        int textCount = 0;
        for (String line : text) {
            if (textCount++ >= 100 || result.length() > 5000) break;
            result.append("- ").append(line).append('\n');
        }
        result.append("\n可点击控件（可用 screen_tap 的 index 指定）：\n");
        for (int i = 0; i < controls.size() && i < 80 && result.length() < 7000; i++) {
            result.append('[').append(i).append("] ").append(controls.get(i).label).append('\n');
        }
        if (text.isEmpty() && controls.isEmpty()) result.append("未找到可访问的文字或控件。");
        return result.toString().trim();
    }

    private String clickAccessibleControl(JSONObject args) {
        int index = args.optInt("index", -1);
        String expectedText = args.optString("expectedText", "").trim();
        if (index < 0 || expectedText.isEmpty()) {
            throw new IllegalArgumentException("点击需要 index 和 expectedText；请先读取屏幕并使用返回的控件序号。");
        }
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) throw new IllegalStateException("没有可操作的活动窗口。");
        ensureExternalTarget(String.valueOf(root.getPackageName()));

        List<String> ignoredText = new ArrayList<>();
        List<Control> controls = new ArrayList<>();
        collectVisibleContent(root, ignoredText, controls, new int[]{0}, 0);
        if (index >= controls.size()) throw new IllegalStateException("控件序号已失效，请重新读取屏幕。");
        Control control = controls.get(index);
        if (!control.label.toLowerCase(Locale.ROOT).contains(expectedText.toLowerCase(Locale.ROOT))) {
            throw new IllegalStateException("屏幕内容已变化，目标文字与控件序号不匹配；未点击。");
        }
        if (!control.node.isVisibleToUser() || !control.node.isClickable()) {
            throw new IllegalStateException("目标控件当前不可见或不可点击。");
        }
        if (!control.node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            throw new IllegalStateException("Android 未能点击该控件。");
        }
        return "已点击可访问控件 [" + index + "]「" + control.label + "」所在的应用界面。";
    }

    private void ensureExternalTarget(String packageName) {
        if (getPackageName().equals(packageName)) {
            throw new IllegalStateException("当前活动窗口是古灵自身。请切换到目标应用，再点击系统通知中的执行按钮。");
        }
        if ("com.android.systemui".equals(packageName)) {
            throw new IllegalStateException("当前活动窗口是 Android 系统界面。请关闭通知面板并在目标应用中重试。");
        }
    }

    private void collectVisibleContent(
            AccessibilityNodeInfo node,
            List<String> text,
            List<Control> controls,
            int[] visited,
            int depth) {
        if (node == null || depth > 18 || visited[0] >= 350) return;
        visited[0]++;
        if (node.isVisibleToUser()) {
            CharSequence nodeText = node.getText();
            CharSequence description = node.getContentDescription();
            String textValue = clean(nodeText);
            String descriptionValue = clean(description);
            if (!textValue.isEmpty() && !text.contains(textValue)) text.add(textValue);
            if (!descriptionValue.isEmpty() && !descriptionValue.equals(textValue) && !text.contains(descriptionValue)) {
                text.add(descriptionValue);
            }
            if (node.isClickable()) {
                String label = controlLabel(node, textValue, descriptionValue);
                if (!label.isEmpty() && controls.size() < 80) controls.add(new Control(node, label));
            }
        }
        for (int i = 0; i < node.getChildCount() && visited[0] < 350; i++) {
            collectVisibleContent(node.getChild(i), text, controls, visited, depth + 1);
        }
    }

    private String controlLabel(AccessibilityNodeInfo node, String text, String description) {
        String label = !text.isEmpty() ? text : description;
        if (label.isEmpty()) {
            String resourceId = node.getViewIdResourceName();
            if (resourceId != null) label = resourceId.substring(resourceId.lastIndexOf('/') + 1);
        }
        return label.trim();
    }

    private String clean(CharSequence value) {
        if (value == null) return "";
        String normalized = value.toString().replaceAll("\\s+", " ").trim();
        return normalized.length() > 300 ? normalized.substring(0, 300) : normalized;
    }

    private static final class Control {
        final AccessibilityNodeInfo node;
        final String label;

        Control(AccessibilityNodeInfo node, String label) {
            this.node = node;
            this.label = label;
        }
    }
}
