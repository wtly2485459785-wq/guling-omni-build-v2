package com.guling.omni;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(GulingNativePlugin.class);
        super.onCreate(savedInstanceState);
    }
}
